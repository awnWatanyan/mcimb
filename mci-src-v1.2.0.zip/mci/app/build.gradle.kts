plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt")
    id("com.google.devtools.ksp")
    id("androidx.navigation.safeargs.kotlin")
    id("dagger.hilt.android.plugin")
    id("kotlinx-serialization")
    id("kotlin-parcelize")
}

android {
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aeon.mci"
        minSdk = 28
        targetSdk = 34
        versionCode = 10200
        versionName = "1.2.0"

        setProperty("archivesBaseName", "mci-v$versionName")

        buildConfigField(
            "String",
            "MCI_ACCOUNT_TYPE",
            "\"${project.properties["account_type"] as String}\""
        )
        buildConfigField(
            "String",
            "SERVER_NAMESPACE",
            "\"${project.properties["service_namespace"] as String}\""
        )
        buildConfigField(
            "String",
            "SERVER_BASE_URI",
            "\"${project.properties["service_base_uri"] as String}\""
        )

        resValue("string", "account_type", project.properties["account_type"] as String)

        vectorDrawables.useSupportLibrary = true

        ndk {
            abiFilters.addAll(listOf("armeabi", "armeabi-v7a"))
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            buildConfigField(
                "String",
                "SERVER_HOST_NAME",
                "\"${project.properties["production_service_host_name"] as String}\""
            )
        }
        getByName("debug") {
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            buildConfigField(
                "String",
                "SERVER_HOST_NAME",
                "\"${project.properties["test_service_host_name"] as String}\""
            )
        }
        maybeCreate("staging")
        getByName("staging") {
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            buildConfigField(
                "String",
                "SERVER_HOST_NAME",
                "\"${project.properties["production_service_host_name"] as String}\""
            )
        }
    }

    buildFeatures {
        compose = true
        dataBinding = true
        viewBinding = true
        buildConfig = true
    }

    composeOptions {
        //kotlinCompilerExtensionVersion = Versions.COMPOSE
        kotlinCompilerExtensionVersion = "1.5.4"
    }

    flavorDimensions.add("version")
    productFlavors {
        maybeCreate("exchange").apply {
            dimension = "version"
            applicationIdSuffix = ".ex"
        }
        maybeCreate("bangkok").apply {
            dimension = "version"
            applicationIdSuffix = ".bk"
        }
        maybeCreate("chiangmai").apply {
            dimension = "version"
            applicationIdSuffix = ".cm"
        }
        maybeCreate("hatyai").apply {
            dimension = "version"
            applicationIdSuffix = ".hy"
        }
        maybeCreate("khonkhan").apply {
            dimension = "version"
            applicationIdSuffix = ".kk"
        }
        maybeCreate("sriracha").apply {
            dimension = "version"
            applicationIdSuffix = ".sc"
        }
        maybeCreate("newBangkok").apply {
            dimension = "version"
            applicationIdSuffix = ".newbk"
        }
        create("production").apply {
            dimension = "version"
            applicationIdSuffix = ".prod"
        }
    }

    androidComponents {
        val release = selector().withBuildType("release")
        beforeVariants(release) {
            if (it.name.contains("exchange")) {
                it.enabled = false
            }
        }

        val debug = selector().withBuildType("debug")
        beforeVariants(debug) {
            if (!it.name.contains("exchange")) {
                it.enabled = false
            }
        }

        val staging = selector().withBuildType("staging")
        beforeVariants(staging) {
            if (!it.name.contains("exchange")) {
                it.enabled = false
            }
        }
    }

    signingConfigs {
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    namespace = "com.aeon.mci"
}

dependencies {
    // Include libraries checked into the libs directory.
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))
    // Zebra bluetooth printer library.
    //implementation(files("${projectDir}/third_party/zebra/libs/ZSDK_ANDROID_API.jar"))
    implementation(files("../third_party/zebra/libs/ZSDK_ANDROID_API.jar"))

    // Kotlin
    implementation(libs.kotlin.stdlib)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.datetime)
    implementation(libs.kotlinx.serialization.json)

    // Android support libraries.
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.material)
    implementation(libs.androidx.legacy)
    implementation(libs.androidx.annotation)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.cardview)
    implementation(libs.androidx.vectordrawable)
    implementation(libs.androidx.preference.ktx)
    implementation(libs.androidx.constraintLayout)
    implementation(libs.androidx.fragment.ktx)

    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material3.windowSizeClass)
    implementation(libs.androidx.compose.material.iconsExtended)

    implementation(libs.androidx.lifecycle.livedata.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtimeCompose)
    implementation(libs.androidx.compose.runtime.livedata)

    // Room
    implementation(libs.room.runtime)
    ksp(libs.room.compiler)
    implementation(libs.room.ktx)

    // COMPOSE
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.foundation.layout)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.compose.runtime)
    implementation(libs.androidx.compose.ui.tooling)
    implementation(libs.androidx.compose.material.iconsExtended)

    // Accompanist

    implementation(libs.android.gms.playServiceLocation)

    implementation(libs.volley)

    // OkHttp
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.retrofit.core)
    implementation(libs.retrofit.kotlin.serialization)

    // Hilt
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    kspAndroidTest(libs.hilt.compiler)
    kspTest(libs.hilt.compiler)

    // Date and time API for Java.
    //implementation(libs.threetenabp)
    implementation(libs.timber)

    // Scalable Vector Graphics (SVG) implementation for Android
    // For in-app OR code payment service
    implementation(libs.android.svg)

    // Instrumentation tests

    // Local unit tests
    testImplementation(libs.junit4)

    // Solve conflicts with gson. DataBinding is using an old version.
    implementation(libs.gson)
}