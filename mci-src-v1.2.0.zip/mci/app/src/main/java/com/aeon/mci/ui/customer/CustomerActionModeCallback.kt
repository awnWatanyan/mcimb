package com.aeon.mci.ui.customer

import androidx.appcompat.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import com.aeon.mci.R

class CustomerActionModeCallback(
        private val listener: CustomerActionModeListener
) : ActionMode.Callback {

    private var isRollback = true

    override fun onActionItemClicked(mode: ActionMode, item: MenuItem) = when (item.itemId) {
        R.id.action_reorder_done -> {
            isRollback = false
            listener.saveReorderCustomerList()
            mode.finish()
            true
        }
        else -> false
    }

    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
        mode.run {
            menuInflater.inflate(R.menu.customer_menu, menu)
            setTitle(R.string.customer_list_reorder_title)
        }
        listener.onCreateActionMode()
        return true
    }

    override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
        return false
    }

    override fun onDestroyActionMode(mode: ActionMode?) {
        listener.onDestroyActionMode(isRollback)
    }
}