package com.aeon.mci.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.HandlerThread;
import android.os.Looper;
import androidx.core.app.ActivityCompat;

import timber.log.Timber;

public class LocationUtils {
    private static final String TAG = LocationUtils.class.getSimpleName();

    private static final int ACCEPT_TIME = 1000 * 60 * 3;
    private Context mContext;
    private LocationManager mLocationManager;
    private Location mCurrentBestLocation;
    private OnLocationUpdateListener mListener;
    private HandlerThread mHandler;

    public LocationUtils(Context context, OnLocationUpdateListener listener) {
        mContext = context;
        mListener = listener;
        mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
    }

    public void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Timber.d(TAG, "Start location listener");
        mHandler = new HandlerThread("TrackingForEditResultHandlerThread");
        mHandler.start();
        Looper looper = mHandler.getLooper();
        mLocationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 10000, 0, mGpsLocationListener, looper);
        mLocationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, 10000, 0, mNetworkLocationListener, looper);
//        mLocationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, mGpsLocationListener, looper);
//        mLocationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, mNetworkLocationListener, looper);
    }

    public void stopLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Timber.d(TAG, "Stop location listener");
        mLocationManager.removeUpdates(mGpsLocationListener);
        mLocationManager.removeUpdates(mNetworkLocationListener);
        mHandler.quit();
    }

    private boolean isBetterLocation(Location location, Location currentBestLocation) {
        if (currentBestLocation == null) {
            // A new location is always better than no location
            return true;
        }

        // Check whether the new location fix is newer or older
        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > ACCEPT_TIME;
        boolean isSignificantlyOlder = timeDelta < -ACCEPT_TIME;
        boolean isNewer = timeDelta > 0;

        // If it's been more than three minutes since the current location, use the new location
        // because the user has likely moved
        if (isSignificantlyNewer) {
            return true;
        // If the new location is more than two minutes older, it must be worse
        } else if (isSignificantlyOlder) {
            return false;
        }

        // Check whether the new location fix is more or less accurate
        int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
        boolean isLessAccurate = accuracyDelta > 0;
        boolean isMoreAccurate = accuracyDelta < 0;
        boolean isSignificantlyLessAccurate = accuracyDelta > 200;

        // Check if the old and new location are from the same provider
        boolean isFromSameProvider = isSameProvider(location.getProvider(),
                currentBestLocation.getProvider());

        // Determine location quality using a combination of timeliness and accuracy
        if (isMoreAccurate) {
            return true;
        } else if (isNewer && !isLessAccurate) {
            return true;
        } else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
            return true;
        }
        return false;
    }

    private boolean isSameProvider(String provider1, String provider2) {
        if (provider1 == null) {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }

    private LocationListener mGpsLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            if (isBetterLocation(location, mCurrentBestLocation)) {
                mCurrentBestLocation = location;
                mListener.onLocationUpdate(mCurrentBestLocation);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };

    private LocationListener mNetworkLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            if (isBetterLocation(location, mCurrentBestLocation)) {
                mCurrentBestLocation = location;
                mListener.onLocationUpdate(mCurrentBestLocation);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };

    public interface OnLocationUpdateListener {
        void onLocationUpdate(Location location);
    }
}
