package com.aeon.mci.account

import android.accounts.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.aeon.mci.Config
import com.aeon.mci.ui.signin.SignInActivity

class Authenticator(
        private val context: Context
) : AbstractAccountAuthenticator(context) {

    // Editing properties is not supported
    override fun editProperties(response: AccountAuthenticatorResponse, s: String): Bundle {
        throw UnsupportedOperationException()
    }

    @Throws(NetworkErrorException::class)
    override fun addAccount(
            response: AccountAuthenticatorResponse,
            accountType: String,
            authTokenType: String,
            requiredFeatures: Array<String>,
            bundle: Bundle
    ): Bundle {
        val intent = Intent(context, SignInActivity::class.java).apply {
            putExtra(SignInActivity.ARG_ACCOUNT_TYPE, accountType)
            putExtra(SignInActivity.ARG_AUTH_TYPE, authTokenType)
            putExtra(SignInActivity.ARG_IS_ADDING_NEW_ACCOUNT, true)
            putExtra(AccountManager.KEY_ACCOUNT_AUTHENTICATOR_RESPONSE, response)
        }
        return Bundle().apply { putParcelable(AccountManager.KEY_INTENT, intent) }
    }

    // Ignore attempts to confirm credentials
    @Throws(NetworkErrorException::class)
    override fun confirmCredentials(
            response: AccountAuthenticatorResponse,
            account: Account,
            bundle: Bundle
    ): Bundle? = null

    @Throws(NetworkErrorException::class)
    override fun getAuthToken(
            response: AccountAuthenticatorResponse,
            account: Account,
            authTokenType: String,
            bundle: Bundle
    ): Bundle {
        return when (authTokenType) {
            Config.AUTHTOKEN_TYPE_REFRESH_TOKEN,
            Config.AUTHTOKEN_TYPE_ACCESS_TOKEN -> {
                val accountManager = AccountManager.get(context)
                val authToken = accountManager.peekAuthToken(account, authTokenType)
                if (authToken.isNotEmpty()) {
                    Bundle().apply {
                        putString(AccountManager.KEY_ACCOUNT_NAME, account.name)
                        putString(AccountManager.KEY_ACCOUNT_TYPE, account.type)
                        putString(AccountManager.KEY_AUTHTOKEN, authToken)
                    }
                } else {
                    Bundle().apply {
                        putString(AccountManager.KEY_ERROR_MESSAGE, "Empty authentication token")
                    }
                }
            }
            else -> Bundle().apply {
                putString(AccountManager.KEY_ERROR_MESSAGE, "Invalid authentication token type")
            }
        }
    }

    override fun getAuthTokenLabel(authTokenType: String): String {
        return when (authTokenType) {
            Config.AUTHTOKEN_TYPE_REFRESH_TOKEN -> Config.AUTHTOKEN_TYPE_REFRESH_TOKEN_LABEL
            Config.AUTHTOKEN_TYPE_ACCESS_TOKEN -> Config.AUTHTOKEN_TYPE_ACCESS_TOKEN_LABEL
            else -> "$authTokenType(Label)"
        }
    }

    // Updating user credentials is not supported
    @Throws(NetworkErrorException::class)
    override fun updateCredentials(
            response: AccountAuthenticatorResponse,
            account: Account,
            s: String,
            bundle: Bundle
    ): Bundle {
        throw UnsupportedOperationException()
    }

    // Checking features for the account is not supported
    @Throws(NetworkErrorException::class)
    override fun hasFeatures(
            response: AccountAuthenticatorResponse,
            account: Account,
            strings: Array<String>
    ): Bundle {
        throw UnsupportedOperationException()
    }

}