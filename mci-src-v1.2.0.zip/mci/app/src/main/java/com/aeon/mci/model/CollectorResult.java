package com.aeon.mci.model;

import android.content.Context;
import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.aeon.mci.R;
import com.aeon.mci.provider.OrderContract;

public class CollectorResult implements Parcelable {

    public String code;
    public String name;
    public int type;
    public int receipt;
    public int letter;
    public int money;
    public int max;
    public int min;
    public int remark;

    public CollectorResult() {

    }

    protected CollectorResult(Parcel in) {
        String[] data = new String[9];

        in.readStringArray(data);
        this.code = data[0];
        this.name = data[1];
        this.type = Integer.parseInt(data[2]);
        this.receipt = Integer.parseInt(data[3]);
        this.letter = Integer.parseInt(data[4]);
        this.money = Integer.parseInt(data[5]);
        this.max = Integer.parseInt(data[6]);
        this.min = Integer.parseInt(data[7]);
        this.remark = Integer.parseInt(data[8]);
    }

    public static final Creator<CollectorResult> CREATOR = new Creator<CollectorResult>() {
        @Override
        public CollectorResult createFromParcel(Parcel in) {
            return new CollectorResult(in);
        }

        @Override
        public CollectorResult[] newArray(int size) {
            return new CollectorResult[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringArray(new String[] {
                this.code,
                this.name,
                String.valueOf(this.type),
                String.valueOf(this.receipt),
                String.valueOf(this.letter),
                String.valueOf(this.money),
                String.valueOf(this.max),
                String.valueOf(this.min),
                String.valueOf(this.remark)
        });
    }

    public static CollectorResult fromCursorRow(Cursor cursor) {
        CollectorResult collectorResult = new CollectorResult();
        collectorResult.code = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_CODE));
        collectorResult.name = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_NAME));
        collectorResult.type = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_TYPE));
        collectorResult.receipt = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT));
        collectorResult.letter = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_LETTER));
        collectorResult.money = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_GET_MONEY));
        collectorResult.max = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT));
        collectorResult.min = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT));
        collectorResult.remark = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_REQUIRED_REMARK));
        return collectorResult;
    }

    public static CollectorResult createPromptItem(Context context) {
        CollectorResult c = new CollectorResult();
        c.code = "";
        c.name = context.getString(R.string.edit_result_hint_result_code);
        c.type = -1;
        c.receipt = -1;
        c.letter = -1;
        c.money = -1;
        c.max = -1;
        c.min = -1;
        c.remark = -1;
        return c;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }
}
