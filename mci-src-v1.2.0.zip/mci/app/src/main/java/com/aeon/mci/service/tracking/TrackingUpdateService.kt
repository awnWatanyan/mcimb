package com.aeon.mci.service.tracking

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.os.BatteryManager
import android.os.HandlerThread
import android.os.IBinder
import com.aeon.mci.R
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.util.AccountUtils
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import dagger.hilt.android.AndroidEntryPoint
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

@AndroidEntryPoint
class TrackingUpdateService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback

    private val handleThread: HandlerThread by lazy {
        HandlerThread("flsmobile_tracking_update_service")
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val interval: Duration = 5.seconds
        val fastestInterval: Duration = 1.seconds
        val maxWaitTime: Duration = 10.seconds

        locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, interval.inWholeMilliseconds)
            .setWaitForAccurateLocation(true)
            .setMinUpdateIntervalMillis(fastestInterval.inWholeMilliseconds)
            .setMaxUpdateDelayMillis(maxWaitTime.inWholeMilliseconds)
            .setMaxUpdates(1)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                val lastLocation: Location? = locationResult.lastLocation
                if (lastLocation != null) {
                    val contentText = """
                        Latitude: ${lastLocation.latitude},
                        Longitude: ${lastLocation.longitude},
                        Provider: ${lastLocation.provider}
                    """.trimIndent()
                    saveLocationToDatabase(lastLocation)
                    updateToWebService()
                    updateTrackingNotificationProgress(contentText)
                }
                stopSelf()
            }
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startLocationUpdate()
        // Tells the system to not try to recreate the service after it has been killed.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopLocationUpdate()
        super.onDestroy()
    }

    private fun updateTrackingNotificationProgress(contentText: String) {
        val notification = createTrackingUpdateNotification(contentText)
        val notificationId = TrackingService.TRACKING_NOTIFICATION_ID
        getNotificationManager().notify(notificationId, notification)
    }

    private fun createTrackingUpdateNotification(contentText: String): Notification {
        val channelId = TrackingService.TRACKING_CHANNEL_ID
        return Notification.Builder(this, channelId).apply {
            setContentTitle(getString(R.string.tracking_notification_title))
            setContentText(contentText)
            setSmallIcon(R.drawable.ic_notification_motorcycle)
            setOngoing(true)
            setShowWhen(true)
            setTicker("flsmobile_tracking_service")
        }.build()
    }

    private fun startLocationUpdate() {
        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, handleThread.looper)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    private fun stopLocationUpdate() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        handleThread.quit()
    }

    private fun saveLocationToDatabase(location: Location) {
        val batteryPct: Float? = getBatteryStatus()?.let { intent ->
            val level: Int = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale: Int = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            level * 100 / scale.toFloat()
        }
        val locationBattery = (batteryPct ?: -1F).toInt()
        val employeeCode = AccountUtils.getEmployeeCode(applicationContext)
        val locationTime = (location.time / 1000L).toInt()
        val updatedDate = (System.currentTimeMillis() / 1000L).toInt()

        val value = ContentValues().apply {
            put(OrderContract.SyncColumns.UPDATED_FLAG, 1)
            put(OrderContract.SyncColumns.UPDATED_DATE, updatedDate)
            put(OrderContract.Locations.LOCATION_TIME, locationTime)
            put(OrderContract.Locations.LOCATION_LATITUDE, location.latitude)
            put(OrderContract.Locations.LOCATION_LONGITUDE, location.longitude)
            put(OrderContract.Locations.LOCATION_BATTERY, locationBattery)
            put(OrderContract.Locations.LOCATION_SPEED, location.speed)
            put(OrderContract.Locations.LOCATION_PROVIDER, location.provider)
            put(OrderContract.Locations.LOCATION_EMPLOYEE_CODE, employeeCode)
            put(OrderContract.Locations.ORDER_NO, "")
        }
        contentResolver.insert(OrderContract.Locations.CONTENT_URI, value)
    }

    private fun updateToWebService() {
        val intent = Intent()
        TrackingUpdater.enqueueWork(this, intent)
    }

    private fun getNotificationManager(): NotificationManager {
        return getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    private fun getBatteryStatus(): Intent? {
        return registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }
}