package com.aeon.mci.persistence

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Customer(
        @SerializedName("idCardNo")
        val id: String,
        @SerializedName("customerName")
        val name: String,
        val gender: Int,
        val age: Int,
        val address: String,
        val section: String = "",
        val zipcode: String,
        val phone: String = "",
        val phoneExt: String = "",
        val mobile: String = "",
        @SerializedName("idMaxDel")
        val delinquentStatus: String,
        @SerializedName("idOsBalance")
        val osBalance: String,
        @SerializedName("idTotalBill")
        val totalBill: String,
        @Expose(serialize = false, deserialize = false)
        val totalAgreements: Int,
        @Expose(serialize = false, deserialize = false)
        val totalUrgent: Int,
        @Expose(serialize = false, deserialize = false)
        val totalCancel: Int,
        @Expose(serialize = false, deserialize = false)
        val totalCollectAmount: Double,
        @Expose(serialize = false, deserialize = false)
        val clientNameEn: String = "",
        @Expose(serialize = false, deserialize = false)
        val clientNameTh: String = "",
        @Expose(serialize = false, deserialize = false)
        val clientContactNo: String = "",
        @Expose(serialize = false, deserialize = false)
        val lat: Double = -0.1,
        @Expose(serialize = false, deserialize = false)
        val lon: Double = -0.1,
        @Expose(serialize = false, deserialize = false)
        val surveyType: String = "",
        @Expose(serialize = false, deserialize = false)
        var distance: Double = -0.1,
) : Parcelable {
        override fun hashCode(): Int {
                return super.hashCode()
        }
}