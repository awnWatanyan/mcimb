package com.aeon.mci.syncadapter

import android.accounts.Account
import android.accounts.AccountManager
import android.content.*
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import com.aeon.mci.Config
import com.aeon.mci.ui.signin.SignInActivity
import timber.log.Timber
import java.util.*

/**
 * Handle the transfer of data between a server and an
 * app, using the Android sync adapter framework.
 */
class SyncAdapter @JvmOverloads constructor(
        context: Context,
        autoInitialize: Boolean,
        /**
         * Using a default argument along with @JvmOverloads
         * generates constructor for both method signatures to maintain compatibility
         * with Android 3.0 and later platform versions
         */
        allowParallelSyncs: Boolean = false,
        val accountManager: AccountManager = AccountManager.get(context),
        private val connectivityManager: ConnectivityManager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
) : AbstractThreadedSyncAdapter(context, autoInitialize, allowParallelSyncs) {

    override fun onPerformSync(
            account: Account,
            extras: Bundle,
            authority: String,
            provider: ContentProviderClient,
            syncResult: SyncResult
    ) {
        // Remove account when out of working time.
        val endTime = accountManager.getUserData(account, Config.BUNDLE_ARG_AUTH_WORKING_TIME_END)
        if (endTime.isNotEmpty() && isOutOfWorkingTime(endTime.toInt())) {
            accountManager.removeAccountExplicitly(account)

            val intent = Intent(context, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            return
        }

        if (!isNetworkAvailable()) {
            Timber.d("Not attempting data performSync because device is OFFLINE")
            return
        }

        SyncHelper(context).performSync(syncResult, account, extras)
    }

    private fun isOutOfWorkingTime(endTime: Int): Boolean {
        val calendar = Calendar.getInstance()
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val now = ((calendar.timeInMillis - startOfDay.timeInMillis) / 1000L).toInt()
        return now - endTime > 0
    }

    private fun isNetworkAvailable(): Boolean {
        return connectivityManager.activeNetworkInfo != null
                && connectivityManager.activeNetworkInfo!!.isConnectedOrConnecting
    }

    companion object {
        const val EXTRA_SYNC_FINISHED = "com.aeon.mci.EXTRA_SYNC_FINISHED"
        const val EXTRA_SYNC_ALL_DATA = "com.aeon.mci.EXTRA_SYNC_ALL_DATA"
        const val EXTRA_SYNC_ORDER_DATA_ONLY = "com.aeon.mci.EXTRA_SYNC_ORDER_DATA_ONLY"
        const val EXTRA_SYNC_ORDER_RESULT_DATA = "com.aeon.mci.EXTRA_SYNC_ORDER_RESULT_DATA"
        const val EXTRA_SYNC_RECEIPT_DATA = "com.aeon.mci.EXTRA_SYNC_RECEIPT_DATA"
        const val EXTRA_SYNC_BACKGROUND = "com.aeon.mci.sync_background"
    }

}