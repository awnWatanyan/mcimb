package com.aeon.mci.shared.data.db

interface OrderDao {
    
}