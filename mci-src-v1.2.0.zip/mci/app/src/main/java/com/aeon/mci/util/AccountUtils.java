package com.aeon.mci.util;

import android.accounts.Account;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.aeon.mci.BuildConfig;

public class AccountUtils {
    private static final String TAG = AccountUtils.class.getSimpleName();

    public static final String PREF_USER_NOT_SIGNED_IN = "pref_user_not_signed_in";
    public static final String PREF_ACTIVE_ACCOUNT = "pref_active_account";
    private static final String PREF_EMPLOYEE_CODE = "pref_employee_code";
    private static final String PREF_EMPLOYEE_NAME = "pref_employee_name";
    private static final String PREF_EMPLOYEE_SURNAME = "pref_employee_surname";
    private static final String PREF_DEVICE_NAME = "pref_device_name";
    private static final String PREF_DEVICE_IMEI = "pref_device_imei";
    private static final String PREF_IN_USED_PRINTER_MAC_ADDRESS = "pref_in_used_printer_mac_address";
    private static final String PREF_COLLECTOR_RESULT_MASTER_DATA_HASH = "pref_collector_result_master_data_hash";

    private static SharedPreferences getDefaultSharedPreferences(final Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static String getEmployeeCode(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_EMPLOYEE_CODE, null);
    }

    public static boolean setEmployeeCode(final Context context, final String code) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_EMPLOYEE_CODE, code).apply();
        return true;
    }

    public static String getActiveAccountName(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_ACTIVE_ACCOUNT, null);
    }

    public static Account getActiveAccount(final Context context) {
        String account = getActiveAccountName(context);
        if (account != null) {
            return new Account(account, BuildConfig.MCI_ACCOUNT_TYPE);
        } else {
            return null;
        }
    }

    public static void setActiveAccount(final Context context, final String accountName) {
        Log.d(TAG, "Set active account to: " + accountName);
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_ACTIVE_ACCOUNT, accountName).apply();
    }

    public static void clearActiveAccount(final Context context) {
        Log.d(TAG, "Clear active account");
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().remove(PREF_ACTIVE_ACCOUNT).apply();
    }

    public static String getEmployeeName(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_EMPLOYEE_NAME, null);
    }

    public static boolean setEmployeeName(final Context context, final String name) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_EMPLOYEE_NAME, name).apply();
        return true;
    }

    public static String getEmployeeSurname(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_EMPLOYEE_SURNAME, null);
    }

    public static boolean setEmployeeSurname(final Context context, final String surname) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_EMPLOYEE_SURNAME, surname).apply();
        return true;
    }

    public static String getDeviceName(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_DEVICE_NAME, null);
    }

    public static boolean setDeviceName(final Context context, final String deviceName) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_DEVICE_NAME, deviceName).apply();
        return true;
    }

    public static String getDeviceImei(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_DEVICE_IMEI, null);
    }

    public static boolean setDeviceImei(final Context context, final String deviceImei) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_DEVICE_IMEI, deviceImei).apply();
        return true;
    }

    public static boolean hasUserNotSignedIn(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getBoolean(PREF_USER_NOT_SIGNED_IN, true);
    }

    public static boolean setUserNotSignedIn(final Context context, final boolean newValue) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putBoolean(PREF_USER_NOT_SIGNED_IN, newValue).apply();
        return true;
    }

    public static String getInUsedPrinterMacAddress(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_IN_USED_PRINTER_MAC_ADDRESS, null);
    }

    public static boolean setInUsedPrinterMacAddress(final Context context, final String macAddress) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_IN_USED_PRINTER_MAC_ADDRESS, macAddress).apply();
        return true;
    }

    public static boolean clearAccountInfo(final Context context) {
        Log.d(TAG, "Clearing active account");
        SharedPreferences sp = getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.remove(PREF_EMPLOYEE_CODE);
        editor.remove(PREF_EMPLOYEE_NAME);
        editor.remove(PREF_EMPLOYEE_SURNAME);
        editor.remove(PREF_DEVICE_NAME);
        editor.remove(PREF_COLLECTOR_RESULT_MASTER_DATA_HASH);
        editor.apply();
        return true;
    }

    public static boolean removeInUsedPrinterMacAddress(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().remove(PREF_IN_USED_PRINTER_MAC_ADDRESS).apply();
        return true;
    }

    public static String getCollectorResultMasterDataHash(final Context context) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        return sp.getString(PREF_COLLECTOR_RESULT_MASTER_DATA_HASH, null);
    }

    public static boolean setCollectorResultMasterDataHash(final Context context, final String hash) {
        SharedPreferences sp = getDefaultSharedPreferences(context);
        sp.edit().putString(PREF_COLLECTOR_RESULT_MASTER_DATA_HASH, hash).apply();
        return true;
    }
}
