package com.aeon.mci.ui.signin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TabletAndroid
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aeon.mci.BuildConfig
import com.aeon.mci.R

@Composable
fun SignInScreen(
    modifier: Modifier = Modifier,
    viewModel: SignInViewModel = viewModel(),
) {
    //var username by remember { mutableStateOf("") }
    //var password by remember { mutableStateOf("") }
    //var deviceId by remember { mutableStateOf("") }
    //var passwordVisibility by remember { mutableStateOf(false) }
    //var isDeviceIdEnabled by remember { mutableStateOf(false) }
    //
    //// Validation states
    //var isUsernameValid by remember { mutableStateOf(true) }
    //var isPasswordValid by remember { mutableStateOf(true) }
    //var isDeviceIdValid by remember { mutableStateOf(true) }

    val username by viewModel.username.observeAsState("")
    val password by viewModel.password.observeAsState("")
    val deviceId by viewModel.deviceId.observeAsState("")
    val passwordVisibility by viewModel.passwordVisibility.observeAsState(false)
    val isDeviceIdEnabled by viewModel.isDeviceIdEnabled.observeAsState(false)

    // Validation states
    val isUsernameValid by viewModel.isUsernameValid.observeAsState(true)
    val isPasswordValid by viewModel.isPasswordValid.observeAsState(true)
    val isDeviceIdValid by viewModel.isDeviceIdValid.observeAsState(true)
    val signInUiState by viewModel.signInUiState.observeAsState()

    // Reacting to the UI state updates from the ViewModel
    signInUiState?.let { uiState ->
        when (uiState) {
            is SignInUiState.Success -> {
                // Handle success, such as navigating to another screen
            }
            is SignInUiState.Error -> {
                // Show error message
                Toast.makeText(LocalContext.current, uiState.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colorResource(id = R.color.purple)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        SignInCard(
            username = username,
            onUsernameChange = viewModel::onUsernameChanged,
            password = password,
            onPasswordChange = viewModel::onPasswordChanged,
            passwordVisibility = passwordVisibility,
            onPasswordVisibilityChange = viewModel::onPasswordVisibilityChanged,
            deviceId = deviceId,
            onDeviceIdChange = viewModel::onDeviceIdChanged,
            isDeviceIdEnabled = isDeviceIdEnabled,
            onDeviceIdEnabledChange = viewModel::onDeviceIdEnabledChanged,
            isUsernameValid = isUsernameValid,
            isPasswordValid = isPasswordValid,
            isDeviceIdValid = isDeviceIdValid,
            onSignInClick = viewModel::onSignInClicked,
        )

        Text(
            text = stringResource(id = R.string.version, BuildConfig.VERSION_NAME),
            modifier = Modifier.padding(top = 16.dp)
        )
    }
}

@Composable
private fun SignInCard(
    username: String,
    onUsernameChange: (String) -> Unit,
    password: String,
    onPasswordChange: (String) -> Unit,
    passwordVisibility: Boolean,
    onPasswordVisibilityChange: (Boolean) -> Unit,
    deviceId: String,
    onDeviceIdChange: (String) -> Unit,
    isDeviceIdEnabled: Boolean,
    onDeviceIdEnabledChange: (Boolean) -> Unit,
    isUsernameValid: Boolean,
    isPasswordValid: Boolean,
    isDeviceIdValid: Boolean,
    onSignInClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .width(480.dp)
            .wrapContentHeight()
            .background(color = Color.White)
            .padding(24.dp)
            .clip(shape = MaterialTheme.shapes.large)
            .shadow(24.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(id = R.string.login_title),
                color = MaterialTheme.colorScheme.primary,
                fontSize = 24.sp,
                modifier = Modifier.padding(bottom = 16.dp),
            )

            OutlinedTextField(
                value = username,
                onValueChange = onUsernameChange,
                label = { Text(stringResource(id = R.string.login_prompt_username)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next,
                ),
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = null)
                },
                isError = !isUsernameValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
            )

            PasswordTextField(
                password = password,
                onPasswordChange = onPasswordChange,
                passwordVisibility = passwordVisibility,
                onPasswordVisibilityChange = onPasswordVisibilityChange,
                isPasswordValid = isPasswordValid,
            )

            OutlinedTextField(
                value = deviceId,
                onValueChange = onDeviceIdChange,
                label = { Text(stringResource(id = R.string.login_prompt_device_id)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                leadingIcon = {
                    Icon(Icons.Default.TabletAndroid, contentDescription = null)
                },
                enabled = isDeviceIdEnabled,
                isError = !isDeviceIdValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Switch(
                    checked = isDeviceIdEnabled,
                    onCheckedChange = { onDeviceIdEnabledChange(it) },
                )
                Spacer(modifier = Modifier.padding(start = 8.dp))
                Text(
                    text = stringResource(id = R.string.login_edit_device_id),
                    modifier = Modifier.weight(1f),
                )
            }

            SignInButton(onSignInClick = onSignInClick, modifier = Modifier.padding(bottom = 16.dp))
        }
    }
}

@Composable
private fun PasswordTextField(
    password: String,
    onPasswordChange: (String) -> Unit,
    passwordVisibility: Boolean,
    onPasswordVisibilityChange: (Boolean) -> Unit,
    isPasswordValid: Boolean,
) {
    OutlinedTextField(
        value = password,
        onValueChange = onPasswordChange,
        label = { Text(stringResource(id = R.string.login_prompt_password)) },
        singleLine = true,
        leadingIcon = {
            Icon(Icons.Default.Lock, contentDescription = null)
        },
        trailingIcon = {
            IconButton(
                onClick = { onPasswordVisibilityChange(!passwordVisibility) }
            ) {
                Icon(
                    imageVector = if (passwordVisibility) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = null
                )
            }
        },
        isError = !isPasswordValid,
        keyboardOptions = KeyboardOptions.Default.copy(
            imeAction = ImeAction.Next
        ),
        visualTransformation = if (passwordVisibility) VisualTransformation.None else PasswordVisualTransformation(),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
    )
}

@Composable
private fun SignInButton(
    onSignInClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Button(
        onClick = onSignInClick,
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = stringResource(id = R.string.login_button_label_sign_in),
            color = colorResource(id = R.color.login_button_text)
        )
    }
}
