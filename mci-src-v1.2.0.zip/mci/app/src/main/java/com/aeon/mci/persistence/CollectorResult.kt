package com.aeon.mci.persistence

data class CollectorResult(
        val code: String,
        val name: String,
        val flag: Int,
        val seq: Int,
        val receipt: Int,
        val letter: Int,
        val money: Int,
        val min: Int,
        val max: Int,
        val remark: Int,
        val groupPriority: Int,
        val groupDesc: String
)