package com.aeon.mci.model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import com.aeon.mci.provider.OrderContract;

public class Customer implements Parcelable {
    public String id;
    public String name;
    public String gender;
    public int age;
    public String address;
    public String zipCode;
    public String section;
    public String phone;
    public String phoneExt;
    public String mobile;
    public int totalAgreements;
    public int totalUrgent;
    public int totalCanceled;
    public float totalCollectAmount;
    public int updatedDate;
    public int collectedDate;
    public String autoCallRemark;
    public int delinquentStatus;
    public float totalOsBalance;
    public float totalBill;
    public String surveyType;

    public Customer() {

    }

    public Customer(Parcel in) {
        String[] data = new String[10];

        in.readStringArray(data);
        this.id = data[0];
        this.name = data[1];
        this.gender = data[2];
        this.age = Integer.parseInt(data[3]);
        this.address = data[4];
        this.zipCode = data[5];
        this.section = data[6];
        this.phone = data[7];
        this.phoneExt = data[8];
        this.mobile = data[9];
    }

    public static final Creator<Customer> CREATOR = new Creator<Customer>() {
        @Override
        public Customer createFromParcel(Parcel in) {
            return new Customer(in);
        }

        @Override
        public Customer[] newArray(int size) {
            return new Customer[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeStringArray(new String[] {
                this.id,
                this.name,
                this.gender,
                String.valueOf(this.age),
                this.address,
                this.zipCode,
                this.section,
                this.phone,
                this.phoneExt,
                this.mobile
        });
    }

    public static Customer fromCursorRow(Cursor cursor) {
        Customer customer = new Customer();
        customer.id = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_IDCARD_NO));
        customer.name = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_NAME));
        customer.gender = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_GENDER));
        customer.age = cursor.getInt(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_AGE));
        customer.address = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_ADDRESS));
        customer.zipCode = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_ZIPCODE));
        customer.section = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_SECTION));
        customer.mobile = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_MOBILE));
        customer.phone = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_PHONE));
        customer.phoneExt = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_PHONE_EXT));
        customer.delinquentStatus = cursor.getInt(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_DELN));
        customer.totalOsBalance = cursor.getFloat(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_OS_BALANCE));
        customer.totalBill = cursor.getFloat(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_TOTAL_BILL));
        customer.totalAgreements = cursor.getInt(cursor.getColumnIndex("total_agreements"));
        customer.totalUrgent = cursor.getInt(cursor.getColumnIndex("total_urgent_agreements"));
        customer.totalCanceled = cursor.getInt(cursor.getColumnIndex("total_canceled_agreements"));
        customer.totalCollectAmount = (float) cursor.getInt(cursor.getColumnIndex("total_collect_amount")) / 100;
        customer.updatedDate = cursor.getInt(cursor.getColumnIndex(OrderContract.SyncColumns.UPDATED_DATE));
        customer.collectedDate = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE));
        customer.autoCallRemark = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_AUTOCALL_REMARK));
        return customer;
    }
}