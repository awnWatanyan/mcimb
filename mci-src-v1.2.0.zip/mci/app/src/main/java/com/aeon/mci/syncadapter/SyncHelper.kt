package com.aeon.mci.syncadapter

import android.accounts.Account
import android.accounts.AccountManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.*
import android.content.Context.NOTIFICATION_SERVICE
import android.net.Uri
import android.os.Bundle
import android.os.RemoteException
import android.provider.BaseColumns
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.aeon.mci.BuildConfig
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.persistence.CollectorResult
import com.aeon.mci.persistence.Customer
import com.aeon.mci.persistence.NewCustomer
import com.aeon.mci.persistence.WorkOrder
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.ui.customer.CustomerFragment
import com.aeon.mci.util.AccountUtils
import com.android.volley.AuthFailureError
import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.HttpHeaderParser
import com.android.volley.toolbox.JsonObjectRequest
import com.google.gson.Gson
import okhttp3.internal.toHexString
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import timber.log.Timber
import java.io.StringReader
import java.net.HttpURLConnection
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.CRC32
import javax.inject.Inject

class SyncHelper @Inject constructor(
    private val context: Context,
) {

    private val accountManager: AccountManager by lazy { AccountManager.get(context) }

    private lateinit var imei: String

    fun performSync(syncResult: SyncResult?, account: Account, extras: Bundle): Boolean {
        val dataChanged = true

        val syncAllData = extras.getBoolean(SyncAdapter.EXTRA_SYNC_ALL_DATA, false)
        val syncOrderDataOnly = extras.getBoolean(SyncAdapter.EXTRA_SYNC_ORDER_DATA_ONLY, false)
        val syncOrderResultData = extras.getBoolean(SyncAdapter.EXTRA_SYNC_ORDER_RESULT_DATA, false)
        val syncReceiptData = extras.getBoolean(SyncAdapter.EXTRA_SYNC_RECEIPT_DATA, false)
        val syncBackground = extras.getBoolean(SyncAdapter.EXTRA_SYNC_BACKGROUND, false)

        Timber.d("Performing sync for account: $account")
        val opStart: Long = System.currentTimeMillis()

        val opsToPerform = ArrayList<Int>()
        when {
            syncAllData -> {
                Timber.d("Sync all data.")
                opsToPerform.add(SyncOps.OP_COLLECTOR_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_ORDERS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_ORDER_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_AUTO_CALL_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_RECEIPTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_LOCATION_DATA_SYNC)
            }
            syncOrderDataOnly -> {
                Timber.d("Sync work order and received.")
                opsToPerform.add(SyncOps.OP_ORDERS_DATA_SYNC)
            }
            syncOrderResultData -> {
                Timber.d("Sync received, result and location.")
                opsToPerform.add(SyncOps.OP_RECEIVED_ORDERS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_ORDER_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_AUTO_CALL_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_RECEIPTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_LOCATION_DATA_SYNC)
            }
            syncReceiptData -> {
                Timber.d("Sync receipt.")
                opsToPerform.add(SyncOps.OP_RECEIPTS_DATA_SYNC)
            }
            syncBackground -> {
                Timber.d("Sync background.")
                opsToPerform.add(SyncOps.OP_ORDER_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_AUTO_CALL_RESULTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_RECEIPTS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_LOCATION_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_ORDERS_DATA_SYNC)
                opsToPerform.add(SyncOps.OP_RECEIVED_ORDERS_DATA_SYNC)
            }
            else -> Timber.d("No operation to perform.")
        }

        imei = accountManager.getUserData(account, Config.BUNDLE_ARG_AUTH_DEVICE_IMEI)
        opsToPerform.forEach {
            when (it) {
                SyncOps.OP_COLLECTOR_RESULTS_DATA_SYNC -> requestAccessToken(it)
                SyncOps.OP_ORDERS_DATA_SYNC -> requestAccessToken(it, dataChanged)
                SyncOps.OP_RECEIVED_ORDERS_DATA_SYNC -> requestAccessToken(it)
                SyncOps.OP_ORDER_RESULTS_DATA_SYNC -> requestAccessToken(it)
                SyncOps.OP_AUTO_CALL_RESULTS_DATA_SYNC -> requestAccessToken(it)
                SyncOps.OP_RECEIPTS_DATA_SYNC -> requestAccessToken(it)
                SyncOps.OP_LOCATION_DATA_SYNC -> syncTrackLog()
            }
        }
        val syncDuration: Long = System.currentTimeMillis() - opStart
        Timber.d("Sync finished in $syncDuration")

//        if (dataChanged) {
//
//        }

        val intent = Intent(SyncAdapter.EXTRA_SYNC_FINISHED)
        context.sendBroadcast(intent)
        return dataChanged
    }

    private fun removeAccount() {
        Timber.d(TAG, "Remove accounts when out of working time.")
        val accounts = accountManager.getAccountsByType(BuildConfig.MCI_ACCOUNT_TYPE)
        if (accounts.isNotEmpty()) {
            for (ac in accounts) {
                accountManager.removeAccountExplicitly(ac)
            }
        }
    }

    private fun requestAccessToken(ops: Int, dataChanged: Boolean = false) {
        Timber.d("Request access token.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("auth")
                .appendPath("token")
        val url = builder.build().toString()
        val account = AccountUtils.getActiveAccount(context)
        val refreshToken = accountManager.peekAuthToken(account, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN)
        val params = JSONObject()
        params.put("grant_type", "refresh_token")
        params.put("client_id", imei)
        params.put("refresh_token", refreshToken)
        val request = JsonObjectRequest(
            Request.Method.POST, url, params,
            Response.Listener { response ->
                val accessToken = response.getString("access_token")
                if (accessToken.isNotBlank()) {
                    when (ops) {
                        SyncOps.OP_COLLECTOR_RESULTS_DATA_SYNC -> syncCollectorResult(accessToken)
                        SyncOps.OP_ORDERS_DATA_SYNC -> {
                            syncWorkOrderPagination(accessToken)
                            syncTasks(account.name, imei)
                        }

                        SyncOps.OP_RECEIVED_ORDERS_DATA_SYNC -> syncReceived(
                            accessToken,
                            account.name
                        )

                        SyncOps.OP_ORDER_RESULTS_DATA_SYNC -> syncResult(accessToken)
                        SyncOps.OP_AUTO_CALL_RESULTS_DATA_SYNC -> syncMciGateway(accessToken)
                        SyncOps.OP_RECEIPTS_DATA_SYNC -> syncReceipt(accessToken, account.name)
                    }
                }
            },
            Response.ErrorListener {
                if (it?.networkResponse?.statusCode == 403) {
                    accountManager.invalidateAuthToken(BuildConfig.MCI_ACCOUNT_TYPE, refreshToken)
                    removeAccount()
                }
                createNotification(
                    "MCI Sync Service",
                    "Error when request access token. [code=${it.networkResponse}, time=${it.networkTimeMs} ms]",
                )
            },
        )

        DefaultBackendVolley.getInstance(context).addToRequestQueue(request)
    }

    private fun syncCollectorResult(accessToken: String) {
        Timber.d("Syncing collector results master data.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("collector-result")
                .appendQueryParameter("projection", "tabletCollectorResult")
                .appendQueryParameter("size", "50")
        val url = builder.build().toString()

        val request = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                Log.d(TAG, "Collector Result response: $response")
                try {
                    val jsonObject = response.getJSONObject("_embedded")
                    if (jsonObject.length() > 0) {
                        saveCollectorResult(jsonObject)
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { },
        ) {
            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }
        }

        DefaultBackendVolley.getInstance(context).addToRequestQueue(request, "sync_collector_result")
    }

    private fun saveCollectorResult(response: JSONObject) {
        val batch = ArrayList<ContentProviderOperation>()
        try {
            val jsonArray = response.getJSONArray("collector-result")
            val jsonString = jsonArray.toString()
            val crc = CRC32()
            crc.update(jsonString.toByteArray())
            val hash = crc.value.toHexString()
            val oldHash = AccountUtils.getCollectorResultMasterDataHash(context)
            if (hash != oldHash) {
                context.contentResolver
                        .delete(OrderContract.CollectorResults.CONTENT_URI, null, null)

                val stringReader = StringReader(jsonString)
                val gson = Gson()
                val data = gson.fromJson(stringReader, Array<CollectorResult>::class.java).toList()
                data.forEach {
                    batch.add(
                        ContentProviderOperation
                            .newInsert(OrderContract.CollectorResults.CONTENT_URI)
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_CODE,
                                it.code
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_NAME,
                                it.name
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_TYPE,
                                it.flag
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT,
                                it.receipt
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_LETTER,
                                it.letter
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_GET_MONEY,
                                it.money
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT,
                                it.min
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT,
                                it.max
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_REQUIRED_REMARK,
                                it.remark
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_GROUP_NAME,
                                it.groupDesc
                            )
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_GROUPING_ORDER,
                                it.groupPriority
                            )
                            .withValue(OrderContract.CollectorResults.COLLECTOR_RESULT_STATUS, 1)
                            .withValue(
                                OrderContract.CollectorResults.COLLECTOR_RESULT_IMPORT_HASHCODE,
                                ""
                            )
                            .build(),
                    )
                }
                AccountUtils.setCollectorResultMasterDataHash(context, hash)
            }
        } catch (e: JSONException) {
            Timber.e(e)
        }

        Timber.i("Applying ${batch.size} content provider operations for collector results.")
        try {
            val operations = batch.size
            if (operations > 0) {
                context.contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, batch)
            }
            Timber.i("Successfully applied $operations content provider operations for collector results.")
        } catch (e: RemoteException) {
            Timber.e("RemoteException while applying content provider batch for collector results.")
        } catch (e: OperationApplicationException) {
            Timber.e("OperationApplicationException while applying content provider batch for collector results.")
        }

    }

    private fun syncWorkOrder(accessToken: String) {
        Timber.d("Syncing assignments data.")
        createNotification(SYNC_WO_TITLE, "Start syncing work order data.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("work-order")
                .appendPath("search")
                .appendPath("findForDeviceImei")
                .appendQueryParameter("imei", imei)
                .appendQueryParameter("projection", "tabletWorkOrder")
        val url = builder.build().toString()

        val request = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                try {
                    val jsonObject = response.getJSONObject("_embedded")
                    if (jsonObject.length() > 0) {
                        saveWorkOrder(jsonObject)
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                createNotification(
                    SYNC_WO_TITLE,
                    "Error when sync work order data. [code=${it.networkResponse}, time=${it.networkTimeMs} ms]",
                )
                Timber.e("Error when sync work order.")
                Timber.e("Network response: ${it.networkResponse}, ${it.message}")
            },
        ) {

            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }
        }
//        BackendVolley.init(context)
//        BackendVolley.addToRequestQueue(request, "sync_work_order")
        DefaultBackendVolley.getInstance(context).addToRequestQueue(request, "sync_work_order")
    }

    private fun syncWorkOrderPagination(accessToken: String, size: Int = 0, page: Int = 0) {
        Timber.d("Syncing assignments data.")
        createNotification(SYNC_WO_TITLE, "Start syncing work order data.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("work-order")
                .appendPath("tablet")
                .appendPath(imei)
        if (size > 0) {
            builder.appendQueryParameter("size", size.toString())
        }
        if (page > 0) {
            builder.appendQueryParameter("page", page.toString())
        }
        val url = builder.build().toString()

        val request = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                try {
                    val jsonObject = response.getJSONObject("_embedded")
                    val jsonArray = jsonObject.getJSONArray("work-order")
                    if (jsonArray.length() > 0) {
                        Timber.d("embedded size=${jsonObject.length()}, content=$jsonObject")
                        saveWorkOrder(jsonObject)

                        val pagination = response.getJSONObject("page")
                        if (pagination != null) {
                            val totalPages = pagination.getInt("totalPages")
                            val number = pagination.getInt("number")
                            if (number < totalPages - 1) {
                                Timber.d("Syncing next page [${number + 1}/$totalPages]")
                                syncWorkOrderPagination(
                                    accessToken = accessToken,
                                    page = number + 1
                                )
                            }
                        }
//                            pagination.let {
//                                Log.d(TAG, "Page[" +
//                                        "size=${it.getString("size")}, " +
//                                        "totalElements=${it.getString("totalElements")}, " +
//                                        "totalPages=${it.getString("totalPages")}, " +
//                                        "number=${it.getString("number")}]")
//                            }
                    } else {
                        createNotification(
                            SYNC_WO_TITLE,
                            "Finish sync work order data. No assignment data received."
                        )
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                createNotification(
                    SYNC_WO_TITLE,
                    "Error when sync work order data. [code=${it.networkResponse}, time=${it.networkTimeMs} ms]",
                )
                Timber.e("Error when sync work order.")
                Timber.e("Network response: ${it.networkResponse}, ${it.message}")
            },
        ) {

            @Throws(AuthFailureError::class)
            override fun getHeaders(): Map<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }
        }
//        BackendVolley.init(context)
//        BackendVolley.addToRequestQueue(request, "sync_work_order")
        DefaultBackendVolley.getInstance(context).addToRequestQueue(request, "sync_work_order")
    }

    private fun syncTasks(employeeCode: String, deviceImei: String) {
        Log.d(TAG,"Syncing tasks data.")
        val url = "https://fls-mobile.aeonts.com/plans?employeeCode=$employeeCode&deviceImei=$deviceImei"

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener { response ->
                try {
                    val jsonArray = response.getJSONArray("data")
                    if (jsonArray.length() > 0) {
                        Log.d(TAG, "embedded size=${jsonArray.length()}, content=$jsonArray")
                        saveTasks(jsonArray)
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Log.e(TAG, "Error when sync work order.")
                Log.e(TAG, "Network response: ${it.networkResponse}, ${it.message}")
            },
        )

        DefaultBackendVolley.getInstance(context).addToRequestQueue(jsonObjectRequest, "sync_tasks")
    }

    private fun saveTasks(tasks: JSONArray) {
        try {
            val sr = StringReader(tasks.toString())
            val tasksData = Gson().fromJson(sr, Array<NewCustomer>::class.java).toList()
            Log.d(TAG, "Save tasks from response: $tasksData")

            val customerBatch = ArrayList<ContentProviderOperation>()
            val dateNow = (System.currentTimeMillis() / 1000L).toInt()
            tasksData.forEach { task ->
                //var customerOldHash = ""
                //var cursor = context.contentResolver.query(
                //    OrderContract.Customers.CONTENT_URI,
                //    CustomersQuery.HASHCODE_PROJECTION,
                //    OrderContract.Customers.CUSTOMER_IDCARD_NO + "=?",
                //    arrayOf(task.citizenId), null)
                //if (cursor != null) {
                //    if (cursor.moveToFirst()) {
                //        customerOldHash = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE))
                //    }
                //    cursor.close()
                //}

                val crc = CRC32()
                crc.update(task.toString().toByteArray())
                val hashCode = crc.value.toHexString()

                customerBatch.add(
                    ContentProviderOperation
                        .newInsert(OrderContract.Customers.CONTENT_URI)
                        .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                        .withValue(OrderContract.Customers.CUSTOMER_IDCARD_NO, task.citizenId)
                        .withValue(OrderContract.Customers.CUSTOMER_NAME, task.customerName)
                        .withValue(OrderContract.Customers.CUSTOMER_GENDER, task.sex.toInt())
                        .withValue(OrderContract.Customers.CUSTOMER_AGE, task.age)
                        .withValue(OrderContract.Customers.CUSTOMER_ADDRESS, task.customerAddress)
                        .withValue(OrderContract.Customers.CUSTOMER_ZIPCODE, task.zipcode)
                        .withValue(OrderContract.Customers.CUSTOMER_SECTION, task.section)
                        .withValue(OrderContract.Customers.CUSTOMER_PHONE, task.phone)
                        .withValue(OrderContract.Customers.CUSTOMER_PHONE_EXT, task.phoneExt)
                        .withValue(OrderContract.Customers.CUSTOMER_MOBILE, task.mobile)
                        .withValue(
                            OrderContract.Customers.CUSTOMER_DELN,
                            task.idMaxDelinquentStatus
                        )
                        .withValue(
                            OrderContract.Customers.CUSTOMER_OS_BALANCE,
                            task.idOutstandingBalance
                        )
                        .withValue(OrderContract.Customers.CUSTOMER_TOTAL_BILL, task.idTotalBill)
                        .withValue(OrderContract.Customers.CUSTOMER_LAT, task.lat)
                        .withValue(OrderContract.Customers.CUSTOMER_LON, task.lon)
                        .withValue(OrderContract.Customers.CUSTOMER_SURVEY_TYPE, task.surveyType)
                        .withValue(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE, hashCode)
                        .build(),
                )
            }

            try {
                val operations = customerBatch.size
                if (operations > 0) {
                    context.contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, customerBatch)
                }
                Timber.i("Successfully applied $operations content provider operations for customers.")
            } catch (e: RemoteException) {
                Timber.e("RemoteException while applying content provider batch for customers.")
            } catch (e: OperationApplicationException) {
                Timber.e("OperationApplicationException while applying content provider batch for customers.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e(TAG, "Error when save tasks.")
        }
    }

    private fun saveWorkOrder(response: JSONObject) {
        Timber.i("Save WorkOrder from response: $response")
        val customerBatch = ArrayList<ContentProviderOperation>()
        val orderInsertBatch = ArrayList<ContentProviderOperation>()
        val orderUpdateBatch = ArrayList<ContentProviderOperation>()

        var updateData = 0
        var cancelData = 0

        try {
            val jsonArray = response.getJSONArray("work-order")
            val jsonString = jsonArray.toString()
            val stringReader = StringReader(jsonString)
            val gson = Gson()
            val customerData = gson.fromJson(stringReader, Array<Customer>::class.java).toSet()
            stringReader.reset()
            val workOrderData = gson.fromJson(stringReader, Array<WorkOrder>::class.java).toList()

            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

            var cancel = 0
            var update = 0
            var assign = 0
            workOrderData.forEach {
                when (it.jobStatus) {
                    4 -> {
                        when (it.taskType) {
                            "N" -> assign++
                            "U" -> update++
                        }
                    }
                    in 90..99 -> cancel++
                }
            }
            createNotification(SYNC_WO_TITLE, "Syncing total=${workOrderData.size} [new=$assign, update=$update, cancel=$cancel]")

            workOrderData.forEach {
                var cursor = context.contentResolver.query(
                    OrderContract.Orders.CONTENT_URI,
                    OrdersQuery.HASHCODE_PROJECTION,
                    OrderContract.Orders.ORDER_NO + "=?",
                    arrayOf(it.id.toString()), null,
                )
                var workOrderOldHashcode = ""
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        workOrderOldHashcode = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_IMPORT_HASHCODE))
                    }
                    cursor.close()
                }
                val dateNow = (System.currentTimeMillis() / 1000L).toInt()
                if (workOrderOldHashcode.isEmpty()) {
                    val collectDateTime = it.collectDate.replaceAfter(" ", it.collectTime).trimEnd()
                    val collectDate = (dateFormat.parse(collectDateTime).time / 1000L).toInt()
                    val collectAmount = (it.collectAmount * 100).toInt()
                    val outStandingBalance = (it.outstandingBalance * 100).toInt()
                    val penalty = (it.penalty * 100).toInt()
                    val currentBill = (it.currentBill * 100).toInt()
                    val d1 = (it.d1 * 100).toInt()
                    val d1AddPenalty = (it.d1AddPenalty * 100).toInt()
                    val d2 = (it.d2 * 100).toInt()
                    val d2AddPenalty = (it.d2AddPenalty * 100).toInt()
                    val d3 = (it.d3 * 100).toInt()
                    val d3AddPenalty = (it.d3AddPenalty * 100).toInt()
                    val d4 = (it.d4 * 100).toInt()
                    val d4AddPenalty = (it.d4AddPenalty * 100).toInt()
                    val d5 = (it.d5 * 100).toInt()
                    val d5AddPenalty = (it.d5AddPenalty * 100).toInt()
                    val totalDelinquent = (it.totalDelinquent * 100).toInt()
                    val totalAddPenalty = (it.totalAddPenalty * 100).toInt()
                    val minimumBill = (it.minimumBill * 100).toInt()
                    val fullBill = (it.fullBill * 100).toInt()

                    orderInsertBatch.add(
                        ContentProviderOperation
                            .newInsert(OrderContract.Orders.CONTENT_URI)
                            .withValue(OrderContract.Orders.CUSTOMER_IDCARD_NO, it.customerId)
                            .withValue(OrderContract.Orders.ORDER_NO, it.id)
                            .withValue(OrderContract.Orders.ORDER_PLAN_NO, "")
                            .withValue(OrderContract.Orders.ORDER_PLAN_SEQ_NO, "")
                            .withValue(OrderContract.Orders.ORDER_GUID, it.guid)
                            .withValue(OrderContract.Orders.ORDER_AGREEMENT_NO, it.agreementNo)
                            .withValue(OrderContract.Orders.ORDER_TOKEN, it.token)
                            .withValue(OrderContract.Orders.ORDER_DESCRIPTION, it.agreementDesc)
                            .withValue(OrderContract.Orders.ORDER_SURVEY_CODE, it.surveyTypeCode)
                            .withValue(OrderContract.Orders.ORDER_SURVEY_NAME, it.surveyTypeName)
                            .withValue(OrderContract.Orders.ORDER_SURVEY_PRIORITY, 0)
                            .withValue(OrderContract.Orders.ORDER_PLAN_SEQUENCE, 0)
                            .withValue(OrderContract.Orders.ORDER_COLLECT_DATE, collectDate)
                            .withValue(OrderContract.Orders.ORDER_COLLECT_AMOUNT, collectAmount)
                            .withValue(
                                OrderContract.Orders.ORDER_STATUS,
                                if (it.jobStatus == 4) 5 else it.jobStatus
                            )
                            .withValue(OrderContract.Orders.ORDER_TASK_TYPE, it.taskType)
                            .withValue(OrderContract.Orders.ORDER_PRIORITY, it.priority)
                            .withValue(OrderContract.Orders.ORDER_OPERATOR_NAME, it.operatorName)
                            .withValue(
                                OrderContract.Orders.ORDER_AUTOCALL_REMARK,
                                it.autocallRemark
                            )
                            .withValue(
                                OrderContract.Orders.ORDER_DELINQUENT_STATUS,
                                it.delinquentStatus
                            )
                            .withValue(
                                OrderContract.Orders.ORDER_OUTSTANDING_BALANCE,
                                outStandingBalance
                            )
                            .withValue(OrderContract.Orders.ORDER_PENALTY, penalty)
                            .withValue(OrderContract.Orders.ORDER_CURRENT_BILL, currentBill)
                            .withValue(OrderContract.Orders.ORDER_D1, d1)
                            .withValue(OrderContract.Orders.ORDER_D1_ADD_PENALTY, d1AddPenalty)
                            .withValue(OrderContract.Orders.ORDER_D2, d2)
                            .withValue(OrderContract.Orders.ORDER_D2_ADD_PENALTY, d2AddPenalty)
                            .withValue(OrderContract.Orders.ORDER_D3, d3)
                            .withValue(OrderContract.Orders.ORDER_D3_ADD_PENALTY, d3AddPenalty)
                            .withValue(OrderContract.Orders.ORDER_D4, d4)
                            .withValue(OrderContract.Orders.ORDER_D4_ADD_PENALTY, d4AddPenalty)
                            .withValue(OrderContract.Orders.ORDER_D5, d5)
                            .withValue(OrderContract.Orders.ORDER_D5_ADD_PENALTY, d5AddPenalty)
                            .withValue(OrderContract.Orders.ORDER_TOTAL_DELINQUENT, totalDelinquent)
                            .withValue(
                                OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY,
                                totalAddPenalty
                            )
                            .withValue(OrderContract.Orders.ORDER_PAYMENT_CODE, it.paymentCode)
                            .withValue(OrderContract.Orders.ORDER_MINIMUM_BILL, minimumBill)
                            .withValue(OrderContract.Orders.ORDER_FULL_BILL, fullBill)
                            .withValue(OrderContract.Orders.ORDER_CLIENT_NAME_EN, it.clientNameEn)
                            .withValue(OrderContract.Orders.ORDER_CLIENT_NAME_TH, it.clientNameTh)
                            .withValue(
                                OrderContract.Orders.ORDER_CLIENT_CONTACT_NO,
                                it.clientContactNo
                            )
                            .withValue(OrderContract.Orders.ORDER_RECEIVED_FLAG, 1)
                            .withValue(OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE, dateNow)
                            .withValue(OrderContract.SyncColumns.UPDATED_FLAG, 0)
                            .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                            .withValue(OrderContract.Orders.ORDER_IMPORT_HASHCODE, it.hashCode())
                            .build(),
                    )
                } else {
                    if (it.hashCode().toString() != workOrderOldHashcode) {
                        when (it.jobStatus) {
                            in 90..99 -> {
                                cancelData++
                                orderUpdateBatch.add(
                                    ContentProviderOperation
                                        .newUpdate(OrderContract.Orders.CONTENT_URI)
                                        .withValue(OrderContract.Orders.ORDER_STATUS, it.jobStatus)
                                        .withValue(
                                            OrderContract.Orders.ORDER_TASK_TYPE,
                                            it.taskType
                                        )
                                        .withValue(OrderContract.Orders.ORDER_RECEIVED_FLAG, 1)
                                        .withValue(
                                            OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_IMPORT_HASHCODE,
                                            it.hashCode()
                                        )
                                        .withValue(OrderContract.SyncColumns.UPDATED_FLAG, 0)
                                        .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG,
                                            0
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TRACKING_FLAG,
                                            0
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TRACKING_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
                                            dateNow
                                        )
                                        .withSelection(
                                            OrdersQuery.UPDATE_CANCEL_SELECTION,
                                            arrayOf(it.id.toString(), it.guid)
                                        )
                                        .build(),
                                )
                            }
                            else -> {
                                updateData++
                                val collectDate = (dateFormat.parse(it.collectDate).time / 1000L).toInt()
                                val collectAmount = (it.collectAmount * 100).toInt()
                                val outStandingBalance = (it.outstandingBalance * 100).toInt()
                                val penalty = (it.penalty * 100).toInt()
                                val currentBill = (it.currentBill * 100).toInt()
                                val d1 = (it.d1 * 100).toInt()
                                val d1AddPenalty = (it.d1AddPenalty * 100).toInt()
                                val d2 = (it.d2 * 100).toInt()
                                val d2AddPenalty = (it.d2AddPenalty * 100).toInt()
                                val d3 = (it.d3 * 100).toInt()
                                val d3AddPenalty = (it.d3AddPenalty * 100).toInt()
                                val d4 = (it.d4 * 100).toInt()
                                val d4AddPenalty = (it.d4AddPenalty * 100).toInt()
                                val d5 = (it.d5 * 100).toInt()
                                val d5AddPenalty = (it.d5AddPenalty * 100).toInt()
                                val totalDelinquent = (it.totalDelinquent * 100).toInt()
                                val totalAddPenalty = (it.totalAddPenalty * 100).toInt()
                                val minimumBill = (it.minimumBill * 100).toInt()
                                val fullBill = (it.fullBill * 100).toInt()

                                orderUpdateBatch.add(
                                    ContentProviderOperation
                                        .newUpdate(OrderContract.Orders.CONTENT_URI)
                                        .withValue(
                                            OrderContract.Orders.CUSTOMER_IDCARD_NO,
                                            it.customerId
                                        )
                                        .withValue(OrderContract.Orders.ORDER_NO, it.id)
                                        .withValue(OrderContract.Orders.ORDER_PLAN_NO, "")
                                        .withValue(OrderContract.Orders.ORDER_PLAN_SEQ_NO, "")
                                        .withValue(OrderContract.Orders.ORDER_GUID, it.guid)
                                        .withValue(
                                            OrderContract.Orders.ORDER_AGREEMENT_NO,
                                            it.agreementNo
                                        )
                                        .withValue(OrderContract.Orders.ORDER_TOKEN, it.token)
                                        .withValue(
                                            OrderContract.Orders.ORDER_DESCRIPTION,
                                            it.agreementDesc
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_SURVEY_CODE,
                                            it.surveyTypeCode
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_SURVEY_NAME,
                                            it.surveyTypeName
                                        )
                                        .withValue(OrderContract.Orders.ORDER_SURVEY_PRIORITY, 0)
                                        .withValue(OrderContract.Orders.ORDER_PLAN_SEQUENCE, 0)
                                        .withValue(
                                            OrderContract.Orders.ORDER_COLLECT_DATE,
                                            collectDate
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_COLLECT_AMOUNT,
                                            collectAmount
                                        )
                                        .withValue(OrderContract.Orders.ORDER_STATUS, it.jobStatus)
                                        .withValue(
                                            OrderContract.Orders.ORDER_TASK_TYPE,
                                            it.taskType
                                        )
                                        .withValue(OrderContract.Orders.ORDER_PRIORITY, it.priority)
                                        .withValue(
                                            OrderContract.Orders.ORDER_OPERATOR_NAME,
                                            it.operatorName
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_AUTOCALL_REMARK,
                                            it.autocallRemark
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_DELINQUENT_STATUS,
                                            it.delinquentStatus
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_OUTSTANDING_BALANCE,
                                            outStandingBalance
                                        )
                                        .withValue(OrderContract.Orders.ORDER_PENALTY, penalty)
                                        .withValue(
                                            OrderContract.Orders.ORDER_CURRENT_BILL,
                                            currentBill
                                        )
                                        .withValue(OrderContract.Orders.ORDER_D1, d1)
                                        .withValue(
                                            OrderContract.Orders.ORDER_D1_ADD_PENALTY,
                                            d1AddPenalty
                                        )
                                        .withValue(OrderContract.Orders.ORDER_D2, d2)
                                        .withValue(
                                            OrderContract.Orders.ORDER_D2_ADD_PENALTY,
                                            d2AddPenalty
                                        )
                                        .withValue(OrderContract.Orders.ORDER_D3, d3)
                                        .withValue(
                                            OrderContract.Orders.ORDER_D3_ADD_PENALTY,
                                            d3AddPenalty
                                        )
                                        .withValue(OrderContract.Orders.ORDER_D4, d4)
                                        .withValue(
                                            OrderContract.Orders.ORDER_D4_ADD_PENALTY,
                                            d4AddPenalty
                                        )
                                        .withValue(OrderContract.Orders.ORDER_D5, d5)
                                        .withValue(
                                            OrderContract.Orders.ORDER_D5_ADD_PENALTY,
                                            d5AddPenalty
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_TOTAL_DELINQUENT,
                                            totalDelinquent
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY,
                                            totalAddPenalty
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_PAYMENT_CODE,
                                            it.paymentCode
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_MINIMUM_BILL,
                                            minimumBill
                                        )
                                        .withValue(OrderContract.Orders.ORDER_FULL_BILL, fullBill)
                                        .withValue(OrderContract.Orders.ORDER_RECEIVED_FLAG, 1)
                                        .withValue(
                                            OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_IMPORT_HASHCODE,
                                            it.hashCode()
                                        )
                                        .withValue(OrderContract.SyncColumns.UPDATED_FLAG, 0)
                                        .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG,
                                            0
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TRACKING_FLAG,
                                            0
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_SEND_TRACKING_DATE,
                                            dateNow
                                        )
                                        .withValue(
                                            OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
                                            dateNow
                                        )
                                        .withSelection(
                                            OrdersQuery.UPDATE_SELECTION,
                                            arrayOf(it.agreementNo, it.guid)
                                        )
                                        .build(),
                                )
                            }
                        }
                    }
                }

                //var customerOldHash = ""
                //cursor = context.contentResolver.query(
                //        OrderContract.Customers.CONTENT_URI,
                //        CustomersQuery.HASHCODE_PROJECTION,
                //        OrderContract.Customers.CUSTOMER_IDCARD_NO + "=?",
                //        arrayOf(it.customerId), null)
                //if (cursor != null) {
                //    if (cursor.moveToFirst()) {
                //        customerOldHash = cursor.getString(cursor.getColumnIndex(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE))
                //    }
                //    cursor.close()
                //}
                //if (customerOldHash.isEmpty()) {
                //    customerData.forEach { customer ->
                //        if (customer.id == it.customerId && customer.address == it.address) {
                //            val crc = CRC32()
                //            crc.update(customer.toString().toByteArray())
                //            val hashCode = crc.value.toHexString()
                //
                //            customerBatch.add(ContentProviderOperation
                //                    .newInsert(OrderContract.Customers.CONTENT_URI)
                //                    .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                //                    .withValue(OrderContract.Customers.CUSTOMER_IDCARD_NO, customer.id)
                //                    .withValue(OrderContract.Customers.CUSTOMER_NAME, customer.name)
                //                    .withValue(OrderContract.Customers.CUSTOMER_GENDER, customer.gender)
                //                    .withValue(OrderContract.Customers.CUSTOMER_AGE, customer.age)
                //                    .withValue(OrderContract.Customers.CUSTOMER_ADDRESS, customer.address)
                //                    .withValue(OrderContract.Customers.CUSTOMER_ZIPCODE, customer.zipcode)
                //                    .withValue(OrderContract.Customers.CUSTOMER_SECTION, customer.section)
                //                    .withValue(OrderContract.Customers.CUSTOMER_PHONE, customer.phone)
                //                    .withValue(OrderContract.Customers.CUSTOMER_PHONE_EXT, customer.phoneExt)
                //                    .withValue(OrderContract.Customers.CUSTOMER_MOBILE, customer.mobile)
                //                    .withValue(OrderContract.Customers.CUSTOMER_DELN, customer.delinquentStatus)
                //                    .withValue(OrderContract.Customers.CUSTOMER_OS_BALANCE, customer.osBalance)
                //                    .withValue(OrderContract.Customers.CUSTOMER_TOTAL_BILL, customer.totalBill)
                //                    //.withValue(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE, customer.hashCode())
                //                    .withValue(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE, hashCode)
                //                    .build())
                //        }
                //    }
                //} else {
                //    if (it.jobStatus !in 90..99) {
                //        customerData.forEach { customer ->
                //            if (customer.hashCode().toString() != customerOldHash
                //                    && customer.id == it.customerId) {
                //
                //                val crc = CRC32()
                //                crc.update(customer.toString().toByteArray())
                //                val hashCode = crc.value.toHexString()
                //
                //                customerBatch.add(ContentProviderOperation
                //                        .newInsert(OrderContract.Customers.CONTENT_URI)
                //                        .withValue(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
                //                        .withValue(OrderContract.Customers.CUSTOMER_IDCARD_NO, customer.id)
                //                        .withValue(OrderContract.Customers.CUSTOMER_NAME, customer.name)
                //                        .withValue(OrderContract.Customers.CUSTOMER_GENDER, customer.gender)
                //                        .withValue(OrderContract.Customers.CUSTOMER_AGE, customer.age)
                //                        .withValue(OrderContract.Customers.CUSTOMER_ADDRESS, customer.address)
                //                        .withValue(OrderContract.Customers.CUSTOMER_ZIPCODE, customer.zipcode)
                //                        .withValue(OrderContract.Customers.CUSTOMER_SECTION, customer.section)
                //                        .withValue(OrderContract.Customers.CUSTOMER_PHONE, customer.phone)
                //                        .withValue(OrderContract.Customers.CUSTOMER_PHONE_EXT, customer.phoneExt)
                //                        .withValue(OrderContract.Customers.CUSTOMER_MOBILE, customer.mobile)
                //                        .withValue(OrderContract.Customers.CUSTOMER_DELN, customer.delinquentStatus)
                //                        .withValue(OrderContract.Customers.CUSTOMER_OS_BALANCE, customer.osBalance)
                //                        .withValue(OrderContract.Customers.CUSTOMER_TOTAL_BILL, customer.totalBill)
                //                        //.withValue(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE, customer.hashCode())
                //                        .withValue(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE, hashCode)
                //                        .build())
                //            }
                //        }
                //    }
                //}
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        Timber.i("Applying ${customerBatch.size} content provider operations for customers.")
        try {
            val operations = customerBatch.size
            if (operations > 0) {
                context.contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, customerBatch)
            }
            Timber.i("Successfully applied $operations content provider operations for customers.")
        } catch (e: RemoteException) {
            Timber.e("RemoteException while applying content provider batch for customers.")
        } catch (e: OperationApplicationException) {
            Timber.e("OperationApplicationException while applying content provider batch for customers.")
        }

        Timber.i("Applying ${orderInsertBatch.size} content provider insert operations for orders.")
        Timber.i("Applying ${orderUpdateBatch.size} content provider update operations for orders.")
        try {
            val insertOperations = orderInsertBatch.size
            if (insertOperations > 0) {
                context.contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, orderInsertBatch)
            }
            Timber.i("Successfully applied $insertOperations content provider insert operations for orders.")

            val updateOperations = orderUpdateBatch.size
            if (updateOperations > 0) {
                context.contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, orderUpdateBatch)
            }
            Timber.i("Successfully applied $updateOperations content provider update operations for orders.")

            if (insertOperations > 0 || updateOperations > 0) {
                sendOrdersDataSyncNotification(insertOperations, updateData, cancelData)
                requestAccessToken(SyncOps.OP_RECEIVED_ORDERS_DATA_SYNC)
            }
        } catch (e: RemoteException) {
            Timber.e("RemoteException while applying content provider batch for orders.")
        } catch (e: OperationApplicationException) {
            Timber.e("OperationApplicationException while applying content provider batch for orders.")
        }

    }

    private fun syncReceived(accessToken: String, collectorId: String) {
        Timber.d("Sync received data.")
        val cursor = context.contentResolver.query(
            OrderContract.Orders.CONTENT_URI,
            ReceivedOrdersQuery.UPDATE_RECEIVED_PROJECTION,
            ReceivedOrdersQuery.UPDATE_SEND_RECEIVED_SELECTION, arrayOf("1"),
            OrderContract.Orders.ORDER_NO + " ASC",
        )

        if (cursor != null) {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            while (cursor.moveToNext()) {
                val workOrderId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_NO))
                val receivedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE))
                val key = JSONObject()
                key.put("workOrderId", workOrderId)
                key.put("updateDate", dateFormat.format(Date(receivedDate * 1000L)))
                key.put("jobStatus", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_STATUS)))
                val jsonRequest = JSONObject()
                jsonRequest.put("id", key)
                jsonRequest.put("pdaReceive", 1)
                jsonRequest.put("collectorId", collectorId)
                jsonRequest.put("collectedDate", null)
                jsonRequest.put("collectedTime", null)
                jsonRequest.put("collectedAmount", null)
                jsonRequest.put("collectorResultCode", null)
                jsonRequest.put("promisedDate", null)
                jsonRequest.put("promisedTime", null)
                jsonRequest.put("loopDate", null)
                jsonRequest.put("latitude", null)
                jsonRequest.put("longitude", null)
                jsonRequest.put("signal", null)
                jsonRequest.put("updateFlag", "N")
                jsonRequest.put("newWorkOrderId", null)
                jsonRequest.put("autocallDate", null)
                jsonRequest.put("agreementNo", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_AGREEMENT_NO)))
                jsonRequest.put("guid", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_GUID)))
                Timber.i("Received JsonRequest: $jsonRequest")

                val builder = Uri.Builder()
                builder.scheme("https")
                        .authority(BuildConfig.SERVER_HOST_NAME)
                        .appendPath("mci-core")
                        .appendPath("v1")
                        .appendPath("temp-work-order")
                val url = builder.build().toString()

                val request = object : JsonObjectRequest(
                    Request.Method.POST, url, jsonRequest,
                    Response.Listener {
                        saveReceived(workOrderId)
                    },
                    Response.ErrorListener {
                        Timber.e(TAG, "Error when sync received: ${it?.networkResponse}")
                    },
                ) {

                    @Throws(AuthFailureError::class)
                    override fun getHeaders(): Map<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Authorization"] = "Bearer $accessToken"
                        headers["Content-Type"] = "application/json"
                        return headers
                    }

                    override fun parseNetworkResponse(response: NetworkResponse?): Response<JSONObject> {
                        if (response?.statusCode == HttpURLConnection.HTTP_CREATED && response.data.isEmpty()) {
                            return Response.success(null, HttpHeaderParser.parseCacheHeaders(response))
                        } else {
                            return super.parseNetworkResponse(response)
                        }
                    }
                }
//                BackendVolley.init(context)
//                BackendVolley.addToRequestQueue(request)

                DefaultBackendVolley.getInstance(context).addToRequestQueue(request)
            }
            cursor.close()
        }
    }

    private fun saveReceived(workOrderId: String) {
        val dateNow = (System.currentTimeMillis() / 1000L).toInt()
        val values = ContentValues()
        values.put(OrderContract.Orders.ORDER_RECEIVED_FLAG, 0)
        values.put(OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE, dateNow)
        val count = context.contentResolver.update(
            OrderContract.Orders.CONTENT_URI,
            values,
            OrderContract.Orders.ORDER_NO + "=?",
            arrayOf(workOrderId),
        )
        if (count > 0) {
            Timber.i("Successfully sent received for work order id: $workOrderId")
        }
    }

    private fun syncResult(accessToken: String) {
        Timber.d("Sync result data.")
        val cursor = context.contentResolver.query(
            OrderContract.Orders.CONTENT_URI,
            OrderResultsQuery.PENDING_RESULTS_PROJECTION,
            OrderContract.SyncColumns.UPDATED_FLAG + "=?",
            arrayOf("1"),
            OrderContract.Orders.ORDER_NO + " ASC",
        )

        if (cursor != null) {
//            DatabaseUtils.dumpCursor(cursor)
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
            while (cursor.moveToNext()) {
                val workOrderId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_NO))
                val collectorId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_EMP_CODE))
                val collectedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE))
                val collectedAmount = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT))
                val remark = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_REMARK))
                val latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_LAT))
                val longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_LON))
                val promisedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_PROMISED_DATE))

                val key = JSONObject()
                key.put("workOrderId", workOrderId)
                key.put("updateDate", dateFormat.format(Date(collectedDate * 1000L)))
                key.put("jobStatus", 6)
                val jsonRequest = JSONObject()
                jsonRequest.put("id", key)
                jsonRequest.put("pdaReceive", 1)
                jsonRequest.put("collectorId", collectorId)
                jsonRequest.put("collectedDate", dateFormat.format(Date(collectedDate * 1000L)))
                jsonRequest.put("collectedTime", timeFormat.format(Date(collectedDate * 1000L)))
                jsonRequest.put("collectedAmount", (collectedAmount.toFloat() / 100))
                jsonRequest.put("collectorResultCode", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.COLLECTOR_RESULT_CODE)))
                jsonRequest.put("remark", "$collectorId $remark")
                jsonRequest.put("promisedDate", if (promisedDate == 0) null else dateFormat.format(Date(promisedDate * 1000L)))
                jsonRequest.put("promisedTime", if (promisedDate == 0) null else timeFormat.format(Date(promisedDate * 1000L)))
                jsonRequest.put("loopDate", if (promisedDate == 0) null else dateFormat.format(Date(promisedDate * 1000L)))
                jsonRequest.put("latitude", latitude.toString())
                jsonRequest.put("longitude", longitude.toString())
                jsonRequest.put("signal", cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_SIGNAL)))
                jsonRequest.put("updateFlag", "N")
                jsonRequest.put("newWorkOrderId", null)
                jsonRequest.put("autocallDate", dateFormat.format(Date(collectedDate * 1000L)))
                jsonRequest.put("agreementNo", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_AGREEMENT_NO)))
                jsonRequest.put("guid", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_GUID)))
                Timber.i("Result JsonRequest: $jsonRequest")

                val builder = Uri.Builder()
                builder.scheme("https")
                        .authority(BuildConfig.SERVER_HOST_NAME)
                        .appendPath("mci-core")
                        .appendPath("v1")
                        .appendPath("temp-work-order")
                val url = builder.build().toString()

                val request = object : JsonObjectRequest(
                    Request.Method.POST, url, jsonRequest,
                    Response.Listener {
                        saveResult(workOrderId)
                    },
                    Response.ErrorListener {
                        Timber.e("Error sync result. Response code=${it?.networkResponse}")
                    },
                ) {

                    @Throws(AuthFailureError::class)
                    override fun getHeaders(): Map<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Authorization"] = "Bearer $accessToken"
                        headers["Content-Type"] = "application/json;charset=UTF-8"
                        return headers
                    }

                    override fun parseNetworkResponse(response: NetworkResponse?): Response<JSONObject> {
                        if (response?.statusCode == HttpURLConnection.HTTP_CREATED) {
                            return Response.success(null, HttpHeaderParser.parseCacheHeaders(response))
                        } else {
                            return super.parseNetworkResponse(response)
                        }
                    }
                }
//                BackendVolley.init(context)
//                BackendVolley.addToRequestQueue(request)
                DefaultBackendVolley.getInstance(context).addToRequestQueue(request)
            }
            cursor.close()
        }
    }

    private fun saveResult(workOrderId: String) {
        val dateNow = (System.currentTimeMillis() / 1000L).toInt()
        val values = ContentValues()
        values.put(OrderContract.SyncColumns.UPDATED_FLAG, 0)
        values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
        val count = context.contentResolver.update(
            OrderContract.Orders.CONTENT_URI,
            values,
            OrderContract.Orders.ORDER_NO + "=?",
            arrayOf(workOrderId),
        )
        if (count > 0) {
            Timber.i("Successfully sent result for work order id: $workOrderId")
        }
    }

    private fun syncMciGateway(accessToken: String) {
        Timber.d("Sync mci gateway data.")
        val cursor = context.contentResolver.query(
            OrderContract.Orders.CONTENT_URI_ORDERS_SEND_AUTOCALL,
            AutoCallResultsQuery.PENDING_AUTO_CALL_RESULTS_PROJECTION,
            null, null, null,
        )

        if (cursor != null) {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

            while (cursor.moveToNext()) {
                val workOrderId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_NO))
                val collectorId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_EMP_CODE))
                val collectedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE))
                val collectedAmount = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT))
                val remark = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_REMARK))
                val collectorResultType = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_TYPE))
                val promisedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_PROMISED_DATE))

                val jsonRequest = JSONObject()
                jsonRequest.put("GuId", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_GUID)))
                jsonRequest.put("Collected_Date", dateFormat.format(Date(collectedDate * 1000L)))
                jsonRequest.put("Collected_Time", timeFormat.format(Date(collectedDate * 1000L)))
                jsonRequest.put("Collector_Id", collectorId)
                jsonRequest.put("Customer_Id", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.CUSTOMER_IDCARD_NO)))
                jsonRequest.put("Agreement_No", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_AGREEMENT_NO)))
                jsonRequest.put("Collection_Result_Code", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.COLLECTOR_RESULT_CODE)))
                jsonRequest.put("Collection_Result_Description", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_NAME)))
                jsonRequest.put("Task_Status", collectorResultType.toString())
                jsonRequest.put("Collected_Amount", (collectedAmount.toFloat() / 100).toString())
                jsonRequest.put("Promise_Date", if (collectorResultType == 0) dateFormat.format(Date(promisedDate * 1000L)) else "")
                jsonRequest.put("Promise_Time", if (collectorResultType == 0) timeFormat.format(Date(promisedDate * 1000L)) else "")
                jsonRequest.put("Remark", "$collectorId $remark")
                Timber.i("AutoCall JsonRequest: $jsonRequest")

                val builder = Uri.Builder()
                builder.scheme("https")
                        .authority(BuildConfig.SERVER_HOST_NAME)
                        .appendPath("mci-core")
                        .appendPath("v1")
                        .appendPath("mci-gateway")
                val url = builder.build().toString()

                val request = object : JsonObjectRequest(
                    Request.Method.POST, url, jsonRequest,
                    Response.Listener {
                        Timber.i("Response from mci gateway: $it")
                        saveMciGateway(workOrderId)
                    },
                    Response.ErrorListener {
                        Timber.e("Error sync mci gateway. Response code=${it?.networkResponse}")
                    },
                ) {

                    @Throws(AuthFailureError::class)
                    override fun getHeaders(): Map<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Authorization"] = "Bearer $accessToken"
                        headers["Content-Type"] = "application/json;charset=UTF-8"
                        return headers
                    }

                    override fun parseNetworkResponse(response: NetworkResponse?): Response<JSONObject> {
                        if (response?.statusCode == HttpURLConnection.HTTP_NO_CONTENT) {
                            return Response.success(null, HttpHeaderParser.parseCacheHeaders(response))
                        } else {
                            return super.parseNetworkResponse(response)
                        }
                    }
                }
//                BackendVolley.init(context)
//                BackendVolley.addToRequestQueue(request)
                DefaultBackendVolley.getInstance(context).addToRequestQueue(request)
            }
            cursor.close()
        }
    }

    private fun saveMciGateway(workOrderId: String) {
        val dateNow = (System.currentTimeMillis() / 1000L).toInt()
        val values = ContentValues()
        values.put(OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG, 0)
        values.put(OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_DATE, dateNow)
        val count = context.contentResolver.update(
            OrderContract.Orders.CONTENT_URI,
            values,
            OrderContract.Orders.ORDER_NO + "=?",
            arrayOf(workOrderId),
        )
        if (count > 0) {
            Timber.i("Successfully sent mci gateway result for order no: $workOrderId")
        }
    }

    private fun syncReceipt(accessToken: String, collectorId: String) {
        Timber.d("Sync receipt data.")
        val cursor = context.contentResolver.query(
            OrderContract.Receipts.CONTENT_URI,
            ReceiptsQuery.PENDING_RECEIPTS_PROJECTION,
            OrderContract.SyncColumns.UPDATED_FLAG + " = ?",
            arrayOf("1"),
            OrderContract.Receipts.DATA_SYNC_SORT,
        )

        if (cursor != null) {
//            DatabaseUtils.dumpCursor(cursor)
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            while (cursor.moveToNext()) {
                val receiptNo = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_NO))
                val status = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_STATUS))
                val printDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_PRINTED_DATE))
                val amount = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_AMOUNT))

                val key = JSONObject()
                key.put("agreementNo", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.AGREEMENT_NO)))
                key.put("status", status)
                key.put("printDate", dateFormat.format(Date(printDate * 1000L)))
                val jsonRequest = JSONObject()
                jsonRequest.put("id", key)
                jsonRequest.put("guid", cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.GUID)))
                jsonRequest.put("receiptNo", receiptNo)
                jsonRequest.put("amount", (amount.toFloat() / 100))
                jsonRequest.put("oldReceiptNo", null)
                jsonRequest.put("collectorId", collectorId)
                jsonRequest.put("deviceImei", imei)
                Timber.i("Receipt JsonRequest: $jsonRequest")

                val builder = Uri.Builder()
                builder.scheme("https")
                        .authority(BuildConfig.SERVER_HOST_NAME)
                        .appendPath("mci-core")
                        .appendPath("v1")
                        .appendPath("receipt")
                val url = builder.build().toString()

                val request = object : JsonObjectRequest(
                    Request.Method.POST, url, jsonRequest,
                    Response.Listener {
                        Timber.i("Response: $it")
                        saveReceipt(receiptNo, status, printDate)
                    },
                    Response.ErrorListener {
                        Timber.e("Error sync receipt. Response code=${it?.networkResponse}")
                    },
                ) {

                    @Throws(AuthFailureError::class)
                    override fun getHeaders(): Map<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Authorization"] = "Bearer $accessToken"
                        headers["Content-Type"] = "application/json"
                        return headers
                    }

                    override fun parseNetworkResponse(response: NetworkResponse?): Response<JSONObject> {
                        if (response?.statusCode == HttpURLConnection.HTTP_CREATED && response.data.isEmpty()) {
                            return Response.success(null, HttpHeaderParser.parseCacheHeaders(response))
                        } else {
                            return super.parseNetworkResponse(response)
                        }
                    }
                }
//                BackendVolley.init(context)
//                BackendVolley.addToRequestQueue(request)
                DefaultBackendVolley.getInstance(context).addToRequestQueue(request)
            }
            cursor.close()
        }
    }

    private fun saveReceipt(receiptNo: String, status: String, printDate: Int) {
        val dateNow = (System.currentTimeMillis() / 1000L).toInt()
        val values = ContentValues()
        values.put(OrderContract.SyncColumns.UPDATED_FLAG, 0)
        values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
        val count = context.contentResolver.update(
            OrderContract.Receipts.CONTENT_URI,
            values,
            OrderContract.Receipts.RECEIPT_DATA_SYNC_UPDATE,
            arrayOf(receiptNo, status, printDate.toString()),
        )
        if (count > 0) {
            Timber.i("Successfully sent receipt data: receiptNo=$receiptNo, status=$status, printDate=$printDate")
        }
    }

//    private fun doReceiptDataSync(empCode: String, imei: String) {
//        val receiptsWebServiceDataEx = SparseArrayCompat<Receipt>()
//        val cursor = mContext.contentResolver.query(
//                OrderContract.Receipts.CONTENT_URI,
//                ReceiptsQuery.PENDING_RECEIPTS_PROJECTION,
//                OrderContract.SyncColumns.UPDATED_FLAG + " = ?",
//                arrayOf("1"),
//                OrderContract.Receipts.DATA_SYNC_SORT)
//        if (cursor != null) {
//            while (cursor.moveToNext()) {
//                val receipt = Receipt()
//                receipt.no = cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_NO))
//                receipt.guid = cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.GUID))
//                receipt.agreementNo = cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.AGREEMENT_NO))
//                receipt.amount = cursor.getInt(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_AMOUNT))
//                receipt.printedDate = cursor.getInt(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_PRINTED_DATE))
//                receipt.status = cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_STATUS))
//                receiptsWebServiceDataEx.put(cursor.position, receipt)
//            }
//            cursor.close()
//        }
//        val operations = receiptsWebServiceDataEx.size()
//        var updated = 0
//        val currencyFormat = DecimalFormat("0.00")
//        currencyFormat.isGroupingUsed = false
//        Log.i(TAG, "Sending $operations receipt data.")
//        for (i in 0 until operations) {
//            val receipt = receiptsWebServiceDataEx.get(i)
//            val collectedAmount = receipt.amount.toFloat() / 100
//            val data = receipt.guid + "|" +
//                    receipt.agreementNo + "|" +
//                    receipt.no + "|" +
//                    currencyFormat.format(collectedAmount.toDouble()) + "|" +
//                    receipt.status + "|" +
//                    receipt.printedDate
//
//            val insertDataSuccess = mOrderResultsDataSender
//                    .sendReceiptData(empCode, imei, data)
//            if (insertDataSuccess) {
//                val updatedDate = (System.currentTimeMillis() / 1000L).toInt()
//                val values = ContentValues()
//                values.put(OrderContract.SyncColumns.UPDATED_FLAG, 0)
//                values.put(OrderContract.SyncColumns.UPDATED_DATE, updatedDate)
//                val count = mContext.contentResolver.update(
//                        OrderContract.Receipts.CONTENT_URI,
//                        values,
//                        OrderContract.Receipts.RECEIPT_DATA_SYNC_UPDATE,
//                        arrayOf(receipt.no, receipt.status, receipt.printedDate.toString()))
//                updated += count
//                //                Log.i(TAG, "Successfully sent receipt no: " + receiptNo);
//            }
//        }
//        Log.i(TAG, "Successfully sent $updated receipt data.")
//    }

    private fun syncTrackLog() {
        Timber.d("Requesting manual sync for location now.")
        val trackingSender = Intent(Config.ACTION_TRACKING_SEND)
        trackingSender.putExtra("imei", imei)
        context.sendBroadcast(trackingSender)
    }

    private fun sendOrdersDataSyncNotification(newData: Int, updateData: Int, cancelData: Int) {
        var post = ""
        var hasPost = false
        if (newData > 0) {
            post += "$newData new assignments"
            hasPost = true
        }
        if (updateData > 0) {
            if (hasPost) {
                post += ", "
                hasPost = true
            }
            post += "$updateData update assignments"
        }
        if (cancelData > 0) {
            if (hasPost) {
                post += ", "
            }
            post += "$cancelData canceled assignments"
        }
        val notificationIntent = Intent(context, CustomerFragment::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE,
        )
        val builder = NotificationCompat.Builder(context)
                .setSmallIcon(R.drawable.ic_notification_motorcycle)
                .setContentTitle(context.getString(R.string.sync_notification_title))
                .setContentText(context.getString(R.string.sync_notification_assignment, post))
                .setContentIntent(pendingIntent)
        val notificationManager = context.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(SYNC_WO_FINISH_NOTIFICATION_ID, builder.build())
    }

    private fun createNotification(title: String, content: String) {
        val builder = NotificationCompat.Builder(context, MCI_NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_motorcycle)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
    }

    private interface CustomersQuery {
        companion object {
            val HASHCODE_PROJECTION = arrayOf(OrderContract.Customers.CUSTOMER_IMPORT_HASHCODE)
        }
    }

    private interface OrdersQuery {
        companion object {
            val ORDER_NO_PROJECTION = arrayOf(OrderContract.Orders.ORDER_NO)

            val HASHCODE_PROJECTION = arrayOf(OrderContract.Orders.ORDER_IMPORT_HASHCODE)

            const val UPDATE_SELECTION = (OrderContract.Orders.ORDER_AGREEMENT_NO + " = ? AND "
                    + OrderContract.Orders.ORDER_GUID + " = ?"
                    + " AND " + OrderContract.Orders.COLLECTOR_RESULT_CODE + " IS NULL")

            const val UPDATE_CANCEL_SELECTION = (OrderContract.Orders.ORDER_NO + " = ? AND "
                    + OrderContract.Orders.ORDER_GUID + " = ?"
                    + " AND " + OrderContract.Orders.COLLECTOR_RESULT_CODE + " IS NULL")
        }
    }

    private interface ReceivedOrdersQuery {
        companion object {
            val UPDATE_RECEIVED_PROJECTION = arrayOf(
                BaseColumns._ID,
                OrderContract.Orders.ORDER_NO,
                OrderContract.Orders.ORDER_AGREEMENT_NO,
                OrderContract.Orders.ORDER_GUID,
                OrderContract.Orders.ORDER_STATUS,
                OrderContract.Orders.ORDER_UPDATE_RECEIVED_DATE,
            )

            const val UPDATE_RECEIVED_FLAG_SELECTION = OrderContract.Orders.ORDER_NO + " = ?"

            const val UPDATE_SEND_RECEIVED_SELECTION = OrderContract.Orders.ORDER_RECEIVED_FLAG + " = ?"
        }
    }

    private interface OrderResultsQuery {
        companion object {
            val PENDING_RESULTS_PROJECTION = arrayOf(
                BaseColumns._ID,
                OrderContract.Orders.ORDER_NO,
                OrderContract.Orders.ORDER_AGREEMENT_NO,
                OrderContract.Orders.ORDER_GUID,
                OrderContract.Orders.COLLECTOR_RESULT_CODE,
                OrderContract.Orders.ORDER_RESULT_EMP_CODE,
                OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
                OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT,
                OrderContract.Orders.ORDER_RESULT_REMARK,
                OrderContract.Orders.ORDER_RESULT_PROMISED_DATE,
                OrderContract.Orders.ORDER_RESULT_LAT,
                OrderContract.Orders.ORDER_RESULT_LON,
                OrderContract.Orders.ORDER_RESULT_SIGNAL,
            )
        }
    }

    private interface AutoCallResultsQuery {
        companion object {
            val PENDING_AUTO_CALL_RESULTS_PROJECTION = arrayOf(
                BaseColumns._ID,
                OrderContract.Orders.ORDER_NO,
                OrderContract.Orders.ORDER_AGREEMENT_NO,
                OrderContract.Orders.ORDER_GUID,
                OrderContract.Orders.CUSTOMER_IDCARD_NO,
                OrderContract.Orders.COLLECTOR_RESULT_CODE,
                OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
                OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT,
                OrderContract.Orders.ORDER_RESULT_REMARK,
                OrderContract.Orders.ORDER_RESULT_PROMISED_DATE,
            )
        }
    }

    private interface ReceiptsQuery {
        companion object {
            val PENDING_RECEIPTS_PROJECTION = arrayOf(
                BaseColumns._ID,
                OrderContract.Receipts.GUID,
                OrderContract.Receipts.AGREEMENT_NO,
                OrderContract.Receipts.RECEIPT_NO,
                OrderContract.Receipts.RECEIPT_AMOUNT,
                OrderContract.Receipts.RECEIPT_STATUS,
                OrderContract.Receipts.RECEIPT_PRINTED_DATE,
            )
        }
    }

    companion object {

        private val TAG = SyncHelper::class.java.simpleName

        const val MCI_NOTIFICATION_CHANNEL_ID = "MCI_SYNC"

        const val SYNC_WO_TITLE = "MCI Sync Service"

        const val NOTIFICATION_ID = 1

        const val SYNC_WO_FINISH_NOTIFICATION_ID = 2

        fun requestManualSync(mChosenAccount: Account?, extras: Bundle) {
            if (mChosenAccount != null) {
                Timber.d("Requesting manual sync for account %s", mChosenAccount.name)
                val bundle = Bundle()
                bundle.putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true)
                bundle.putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true)
                val syncOrderDataOnly = extras.getBoolean(SyncAdapter.EXTRA_SYNC_ORDER_DATA_ONLY, false)
                if (syncOrderDataOnly) {
                    bundle.putBoolean(SyncAdapter.EXTRA_SYNC_ORDER_DATA_ONLY, true)
                }
                val syncOrderResultData = extras.getBoolean(SyncAdapter.EXTRA_SYNC_ORDER_RESULT_DATA, false)
                if (syncOrderResultData) {
                    bundle.putBoolean(SyncAdapter.EXTRA_SYNC_ORDER_RESULT_DATA, true)
                }
                val syncReceiptData = extras.getBoolean(SyncAdapter.EXTRA_SYNC_RECEIPT_DATA, false)
                if (syncReceiptData) {
                    bundle.putBoolean(SyncAdapter.EXTRA_SYNC_RECEIPT_DATA, true)
                }
                ContentResolver.setSyncAutomatically(mChosenAccount, OrderContract.CONTENT_AUTHORITY, true)
                ContentResolver.setIsSyncable(mChosenAccount, OrderContract.CONTENT_AUTHORITY, 1)

                val pending = ContentResolver.isSyncPending(mChosenAccount, OrderContract.CONTENT_AUTHORITY)
                if (pending) {
                    Timber.d("Warning: sync is PENDING. Will cancel.")
                }
                val active = ContentResolver.isSyncActive(mChosenAccount, OrderContract.CONTENT_AUTHORITY)
                if (active) {
                    Timber.d("Warning: sync is ACTIVE. Will cancel.")
                }

                if (pending || active) {
                    Timber.d("Cancelling previously pending/active sync.")
                    ContentResolver.cancelSync(mChosenAccount, OrderContract.CONTENT_AUTHORITY)
                }

                Timber.d("Requesting sync now.")
                ContentResolver.requestSync(mChosenAccount, OrderContract.CONTENT_AUTHORITY, bundle)
            } else {
                Timber.d("Can't request manual sync -- no chosen account.")
            }
        }
    }

    object SyncOps {
        const val OP_COLLECTOR_RESULTS_DATA_SYNC = 0
        const val OP_ORDERS_DATA_SYNC = 1
        const val OP_RECEIVED_ORDERS_DATA_SYNC = 2
        const val OP_ORDER_RESULTS_DATA_SYNC = 3
        const val OP_AUTO_CALL_RESULTS_DATA_SYNC = 4
        const val OP_RECEIPTS_DATA_SYNC = 5
        const val OP_LOCATION_DATA_SYNC = 6
    }
}
