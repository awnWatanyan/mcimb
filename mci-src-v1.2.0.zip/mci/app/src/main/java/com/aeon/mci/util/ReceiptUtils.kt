package com.aeon.mci.util

import android.content.ContentResolver
import android.content.ContentValues
import android.provider.BaseColumns
import com.aeon.mci.provider.OrderContract.Receipts
import com.aeon.mci.provider.OrderContract.SyncColumns
import java.text.DecimalFormat
import java.util.*
import javax.inject.Inject

class ReceiptUtils @Inject constructor(
        private val contentResolver: ContentResolver
) {

    private var startTime = 0
    private var endTime = 0

    init {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        startTime = (calendar.time.time / 1000L).toInt()
        calendar.add(Calendar.DATE, 1)
        endTime = (calendar.time.time / 1000L).toInt()
    }

    fun generateReceiptNo(
            employeeCode: String,
            guid: String,
            isReprint: Boolean
    ): String {
        var receiptNo = ""
        if (isReprint) {
            val cursor = contentResolver.query(
                    Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    Receipts.RECEIPT_ITEM_SELECTION,
                    arrayOf(guid, "P", startTime.toString(), endTime.toString()),
                    "${Receipts.RECEIPT_NO} DESC"
            )
            cursor?.run {
                if (moveToFirst()) {
                    receiptNo = getString(getColumnIndex(Receipts.RECEIPT_NO))
                }
                close()
            }
        } else {
            val cursor = contentResolver.query(
                    Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    Receipts.RECEIPT_PRINT_SELECTION,
                    arrayOf(startTime.toString(), endTime.toString()),
                    "${Receipts.RECEIPT_NO} DESC"
            )
            cursor?.run {
                val dateNow = Date((System.currentTimeMillis() / 1000L).toInt() * 1000L)
                val sdf = dateFormatYearFirst()
                val df = DecimalFormat("000")
                receiptNo = "${employeeCode}_${sdf.format(dateNow)}_${df.format(count + 1)}"
                close()
            }
        }
        return receiptNo
    }

    fun getReprintCount(guid: String, agreementNo: String): Int {
        var receiptNo = ""
        var cursor = contentResolver.query(
                Receipts.CONTENT_URI,
                ReceiptQuery.NORMAL_PROJECTION,
                Receipts.RECEIPT_LATEST_BY_GUID_SELECTION,
                arrayOf(guid, agreementNo, startTime.toString(), endTime.toString()),
                "${Receipts.RECEIPT_NO} DESC"
        )
        cursor?.run {
            if (moveToFirst()) {
                receiptNo = getString(getColumnIndex(Receipts.RECEIPT_NO))
            }
            close()
        }

        var reprintCount = 0
        if (receiptNo.isNotEmpty()) {
            cursor = contentResolver.query(
                    Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    Receipts.RECEIPT_ITEM_REPRINT_SELECTION,
                    arrayOf(guid, agreementNo, receiptNo, "R", startTime.toString(), endTime.toString()),
                    null
            )
            cursor?.run {
                reprintCount = count + 1
                close()
            }
        }
        return reprintCount
    }

    fun cancelReceipt(guid: String) {
        val cursor = contentResolver.query(
                Receipts.CONTENT_URI,
                ReceiptQuery.NORMAL_PROJECTION,
                Receipts.RECEIPT_ITEM_SELECTION,
                arrayOf(guid, "P", startTime.toString(), endTime.toString()),
                "${Receipts.RECEIPT_NO} DESC"
        )
        cursor?.run {
            if (moveToFirst()) {
                val contents = ContentValues().apply {
                    val dateNow = (System.currentTimeMillis() / 1000L).toInt()
                    put(Receipts.GUID, getString(getColumnIndex(Receipts.GUID)))
                    put(Receipts.AGREEMENT_NO, getString(getColumnIndex(Receipts.AGREEMENT_NO)))
                    put(Receipts.RECEIPT_NO, getString(getColumnIndex(Receipts.RECEIPT_NO)))
                    put(Receipts.RECEIPT_AMOUNT, getInt(getColumnIndex(Receipts.RECEIPT_AMOUNT)))
                    put(Receipts.RECEIPT_STATUS, "C")
                    put(Receipts.RECEIPT_PRINTED_DATE, dateNow)
                    put(SyncColumns.UPDATED_FLAG, 1)
                    put(SyncColumns.UPDATED_DATE, dateNow)
                }
                contentResolver.insert(Receipts.CONTENT_URI, contents)
            }
            close()
        }
    }
}

interface ReceiptQuery {
    companion object {
        val NORMAL_PROJECTION = arrayOf(
                BaseColumns._ID,
                Receipts.GUID,
                Receipts.AGREEMENT_NO,
                Receipts.RECEIPT_NO,
                Receipts.RECEIPT_AMOUNT,
                Receipts.RECEIPT_STATUS,
                Receipts.RECEIPT_PRINTED_DATE
        )
    }
}