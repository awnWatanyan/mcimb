package com.aeon.mci.persistence

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Receipt(val no: String,
                   val guid: String,
                   val agreementNo: String,
                   val status: String,
                   val amount: Int,
                   val printDate: Int) : Parcelable