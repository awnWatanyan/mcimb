package com.aeon.mci.receiver;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BluetoothPrinterReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
//        if (intent.getAction().equals(BluetoothDevice.ACTION_PAIRING_REQUEST)) {
//            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                device.setPin("1234".getBytes());
//                device.setPairingConfirmation(true);
//            }
//        }
    }
}
