package com.aeon.mci.ui.qrcode

import android.accounts.AccountManager
import android.app.Dialog
import android.graphics.drawable.Drawable
import android.graphics.drawable.PictureDrawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.DialogFragment
import com.aeon.mci.BuildConfig
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.databinding.DialogQrcodeBinding
import com.aeon.mci.syncadapter.DefaultBackendVolley
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.applyTitleStyle
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.caverock.androidsvg.SVG
import org.json.JSONObject
import java.text.DecimalFormat


class QRCodeDialogFragment : DialogFragment() {

    private var _binding: DialogQrcodeBinding? = null
    private val binding get() = _binding!!

    private var token: String? = null
    private var collectorId: String? = null
    private var customerId: String? = null
    private var agreementNo: String? = null
    private var agreementDesc: String? = null
    private var amount: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireNotNull(arguments).apply {
            token = getString(ARG_TOKEN)
            collectorId = getString(ARG_COLLECTOR_ID)
            customerId = getString(ARG_CUSTOMER_ID)
            agreementNo = getString(ARG_AGREEMENT_NO)
            agreementDesc = getString(ARG_AGREEMENT_DESC)
            amount = getInt(ARG_AMOUNT)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        //return inflater.inflate(R.layout.dialog_qrcode, container, false)
        _binding = DialogQrcodeBinding.inflate(inflater, container, false)
        return  binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val df = DecimalFormat("##,###,##0.00")

        binding.closeQrcode.setOnClickListener { dismiss() }
        binding.qrcodeAgreementNo.text = getString(R.string.label_agreement_no_with_value, agreementNo)
        binding.qrcodeAgreementDesc.text = getString(R.string.label_agreement_desc_with_value, agreementDesc)
        binding.qrcodeAmount.text = getString(R.string.label_amount_with_value, df.format(amount.toFloat()/100))

        //view.close_qrcode.setOnClickListener { dismiss() }
        //view.qrcode_agreement_no.text = getString(R.string.label_agreement_no_with_value, agreementNo)
        //view.qrcode_agreement_desc.text = getString(R.string.label_agreement_desc_with_value, agreementDesc)
        //view.qrcode_amount.text = getString(R.string.label_amount_with_value, df.format(amount.toFloat()/100))

//        AuthAccessTokenDataSource(context!!).requestAccessToken()

        requestAccessToken(view)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        retainInstance = true
        return super.onCreateDialog(savedInstanceState).apply {
            setTitle(R.string.title_dialog_qrcode)
            applyTitleStyle()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_TOKEN = "token"
        private const val ARG_COLLECTOR_ID = "collector_id"
        private const val ARG_CUSTOMER_ID = "customer_id"
        private const val ARG_AGREEMENT_NO = "agreement_no"
        private const val ARG_AGREEMENT_DESC = "agreement_desc"
        private const val ARG_AMOUNT = "amount"

        @JvmStatic
        fun newInstance(
                token: String,
                collectorId: String,
                customerId: String,
                agreementNo: String,
                agreementDesc: String,
                amount: Int = 0
        ) =
                QRCodeDialogFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_TOKEN, token)
                        putString(ARG_COLLECTOR_ID, collectorId)
                        putString(ARG_CUSTOMER_ID, customerId)
                        putString(ARG_AGREEMENT_NO, agreementNo)
                        putString(ARG_AGREEMENT_DESC, agreementDesc)
                        putInt(ARG_AMOUNT, amount)
                    }
                }
    }

    private fun requestAccessToken(view: View) {
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("auth")
                .appendPath("token")
        val url = builder.build().toString()
        val accountManager = AccountManager.get(requireActivity().applicationContext)
        val account = AccountUtils.getActiveAccount(requireActivity().applicationContext)
        val refreshToken = accountManager.peekAuthToken(account, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN)
        val imei = accountManager.getUserData(account, Config.BUNDLE_ARG_AUTH_DEVICE_IMEI)
        val params = JSONObject()
        params.put("grant_type", "refresh_token")
        params.put("client_id", imei)
        params.put("refresh_token", refreshToken)
        val request = JsonObjectRequest(Request.Method.POST, url, params,
                Response.Listener { response ->
                    val accessToken = response.getString("access_token")
                    if (accessToken.isNotBlank()) {
                        requestGenerateQRCode(view, accessToken)
                    }
                },
                Response.ErrorListener {

                })

        DefaultBackendVolley.getInstance(requireContext()).addToRequestQueue(request)
    }

    private fun requestGenerateQRCode(view: View, accessToken: String) {
        val uri = Uri.Builder()
                .scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("aeon-qrcode-generate")
                .build()

        val request = object : StringRequest(Method.POST, uri.toString(),
                Response.Listener {
                    if (it.isNullOrEmpty()) {
                        val loading: View = view.findViewById(R.id.qrcode_loading_container)
                        loading.visibility = View.GONE
                        val error: View = view.findViewById(R.id.qrcode_error)
                        error.visibility = View.VISIBLE
                    } else {
                        val qr: ImageView = view.findViewById(R.id.qrcode_image)
                        qr.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

                        val svg: SVG = SVG.getFromString(it)
                        val drawable: Drawable = PictureDrawable(svg.renderToPicture())
                        qr.setImageDrawable(drawable)

                        val loading: View = view.findViewById(R.id.qrcode_loading_container)
                        loading.visibility = View.GONE

                        val details: View = view.findViewById(R.id.qrcode_details_container)
                        details.visibility = View.VISIBLE
                    }
                },
                Response.ErrorListener {

                }) {

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }

            override fun getBodyContentType(): String {
                return "application/x-www-form-urlencoded;"
            }

            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                        "token" to token!!,
                        "customer_id" to customerId!!,
                        "agreementNo" to agreementNo!!,
                        "amount" to amount.toString(),
                        "collector_id" to collectorId!!
                )
            }
        }

        DefaultBackendVolley.getInstance(requireContext()).addToRequestQueue(request)
    }
}
