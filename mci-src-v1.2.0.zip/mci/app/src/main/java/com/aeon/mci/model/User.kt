package com.aeon.mci.model

data class User(
        val name: String,
        val surname: String,
        val deviceName: String,
        val refreshToken: String,
        val startTime: Int,
        val endTime: Int
)