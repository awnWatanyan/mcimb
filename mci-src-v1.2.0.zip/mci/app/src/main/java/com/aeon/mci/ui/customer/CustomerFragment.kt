package com.aeon.mci.ui.customer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.OperationApplicationException
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.database.Cursor
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.RemoteException
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewSwitcher
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.loader.app.LoaderManager
import androidx.loader.content.Loader
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.databinding.FragmentCustomerBinding
import com.aeon.mci.persistence.Customer
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.syncadapter.SyncAdapter
import com.aeon.mci.ui.agreement.AgreementActivity
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.decimalFormatWithCommasExcludeZeros
import com.aeon.mci.util.fromHtml
import com.aeon.mci.util.hide
import com.aeon.mci.util.setStatusBarColor
import com.aeon.mci.util.show
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.bottomnavigation.BottomNavigationView
import dagger.hilt.android.AndroidEntryPoint
import java.text.DecimalFormat
import java.util.Calendar
import java.util.Collections
import kotlin.math.round

@AndroidEntryPoint
class CustomerFragment : Fragment(),
        LoaderManager.LoaderCallbacks<Cursor>,
        CustomerActionsHandler,
        CustomerActionModeListener {

    private val fusedLocationClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(requireContext())
    }

    private val customerViewModel: CustomerViewModel by viewModels()
    private lateinit var binding: FragmentCustomerBinding
    private lateinit var assignedCustomerAdapter: AssignedCustomerAdapter

    private val mCustomers: MutableList<Customer> = ArrayList()
    private var originalCustomerList = mutableListOf<Customer>()
    private var isDragEnabled = false
    private var isNewTask = false
    private var isActionModeEnabled = false

    private lateinit var viewSwitcher: ViewSwitcher
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var customerRecyclerView: RecyclerView
    private lateinit var customerAdapter: CustomCustomerAdapter
    private lateinit var itemTouchHelper: ItemTouchHelper
    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var customerObserver: ContentObserver

    private val syncBroadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (swipeRefreshLayout.isRefreshing) {
                swipeRefreshLayout.isRefreshing = false
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true

        requireNotNull(arguments).apply {
            isNewTask = getBoolean(Config.EXTRAS_INCOMPLETE_TASK)
            if (isNewTask) {
                isDragEnabled = true
                loaderManager.initLoader(QUERY_UNDONE_CUSTOMER, null, this@CustomerFragment)
            } else {
                loaderManager.initLoader(QUERY_DONE_CUSTOMER, null, this@CustomerFragment)
            }
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View {
        container?.clearDisappearingChildren()
        binding = FragmentCustomerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //assignedCustomerAdapter = AssignedCustomerAdapter()
        //binding.recyclerviewCustomer.apply {
        //    adapter = assignedCustomerAdapter
        //    layoutManager = LinearLayoutManager(requireContext())
        //}

        customerViewModel.customers.observe(viewLifecycleOwner) { customers ->
            customerAdapter.submitList(customers)
        }

        // Set action bar subtitle
        with(requireActivity() as AppCompatActivity) {
            supportActionBar?.apply {
                val empName = AccountUtils.getEmployeeName(context)
                val empSurname = AccountUtils.getEmployeeSurname(context)
                val empCode = AccountUtils.getEmployeeCode(context)
                subtitle = "$empName $empSurname ($empCode)"
            }
        }
        // End of set action bar subtitle

        customerViewModel.run {
            isNewTask.value = this@CustomerFragment.isNewTask
        }

        viewSwitcher = view.findViewById(R.id.customer_list_view_switcher)
        viewSwitcher.run {
            inAnimation = null
            outAnimation = null
        }

        val emptyView: TextView = view.findViewById(R.id.customer_list_empty)
        emptyView.apply {
            val hintText = if (isNewTask) R.string.assign_empty else R.string.complete_empty
            text = fromHtml(getString(hintText))
            val hintTextColor = if (isNewTask) R.color.blue else R.color.brown
            setTextColor(ContextCompat.getColor(context, hintTextColor))
        }

        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout)
        swipeRefreshLayout.run {
            isEnabled = isNewTask

            setColorSchemeResources(R.color.assign_light)

            setOnRefreshListener {
                val account = AccountUtils.getActiveAccount(context)
                if (ContentResolver.isSyncActive(account, OrderContract.CONTENT_AUTHORITY)) {
                    return@setOnRefreshListener
                }

                val settingsBundle = Bundle().apply {
                    putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true)
                    putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true)
                    putBoolean(SyncAdapter.EXTRA_SYNC_ORDER_DATA_ONLY, true)
                }
                ContentResolver.requestSync(account, OrderContract.CONTENT_AUTHORITY, settingsBundle)
            }
        }

        val parentActivity = (activity as AppCompatActivity)
        bottomNavigation = parentActivity.findViewById(R.id.bottom_navigation)

        customerAdapter = CustomCustomerAdapter(this, isNewTask)
        customerAdapter.setHasStableIds(true)

        customerRecyclerView = view.findViewById(R.id.recyclerview_customer)
        customerRecyclerView.run {
            adapter = customerAdapter
            (itemAnimator as DefaultItemAnimator).apply {
                supportsChangeAnimations = false
                addDuration = 160L
                moveDuration = 160L
                changeDuration = 160L
                removeDuration = 120L
            }

            val linearLayoutManager = LinearLayoutManager(context)
            layoutManager = linearLayoutManager

            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    if (isNewTask && !isActionModeEnabled) {
                        val first = linearLayoutManager.findFirstCompletelyVisibleItemPosition()
                        swipeRefreshLayout.isEnabled = first == 0
                    }
                }
            })
        }

        itemTouchHelper = ItemTouchHelper(mIthCallback)
        itemTouchHelper.attachToRecyclerView(customerRecyclerView)

        val position = savedInstanceState?.getInt("scroll_to_position") ?: 0
        val lm = customerRecyclerView.layoutManager as LinearLayoutManager
        lm.scrollToPosition(position)
    }

    //override fun onActivityCreated(savedInstanceState: Bundle?) {
    //    super.onActivityCreated(savedInstanceState)
    //
    //    // Set action bar subtitle
    //    with(requireActivity() as AppCompatActivity) {
    //        supportActionBar?.apply {
    //            val empName = AccountUtils.getEmployeeName(context)
    //            val empSurname = AccountUtils.getEmployeeSurname(context)
    //            val empCode = AccountUtils.getEmployeeCode(context)
    //            subtitle = "$empName $empSurname ($empCode)"
    //        }
    //    }
    //
    //    val position = savedInstanceState?.getInt("scroll_to_position") ?: 0
    //    val lm = customerRecyclerView.layoutManager as LinearLayoutManager
    //    lm.scrollToPosition(position)
    //}

    override fun onResume() {
        super.onResume()
        restartLoaderManager()
    }

    override fun onPause() {
        swipeRefreshLayout.isRefreshing = false
        super.onPause()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        context.run {
            registerReceiver(syncBroadcastReceiver, IntentFilter(SyncAdapter.EXTRA_SYNC_FINISHED))
            customerObserver = CustomerObserver(Handler())
            contentResolver.registerContentObserver(
                    OrderContract.Orders.CONTENT_URI,
                    true,
                    customerObserver
            )
        }
    }

    override fun onDetach() {
        if (swipeRefreshLayout.isRefreshing) {
            swipeRefreshLayout.isRefreshing = false
        }
        super.onDetach()
        context?.run {
            unregisterReceiver(syncBroadcastReceiver)
            contentResolver.unregisterContentObserver(customerObserver)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val lm = customerRecyclerView.layoutManager as LinearLayoutManager
        val position = lm.findFirstVisibleItemPosition()
        outState.putInt("scroll_to_position", position)
    }

    /**
     * LoaderCallbacks for the customer list that load new or done jobs.
     */
    override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor> {
        return if (context != null) {
            when (id) {
                QUERY_UNDONE_CUSTOMER -> {
                    androidx.loader.content.CursorLoader(requireContext(),
                            OrderContract.Customers.CONTENT_URI_CUSTOMERS_UNDONE,
                            OrderContract.Customers.NORMAL_PROJECTION,
                            null, null, null)
                }
                QUERY_DONE_CUSTOMER -> {
                    val calendar = Calendar.getInstance()
                    calendar[Calendar.HOUR_OF_DAY] = 0
                    calendar[Calendar.MINUTE] = 0
                    calendar[Calendar.SECOND] = 0
                    val start = (calendar.time.time / 1000L).toInt()
                    calendar.add(Calendar.DATE, 1)
                    val end = (calendar.time.time / 1000L).toInt()
                    androidx.loader.content.CursorLoader(requireContext(),
                            OrderContract.Customers.CONTENT_URI_CUSTOMERS_DONE,
                            OrderContract.Customers.NORMAL_PROJECTION,
                            null, arrayOf(start.toString(), end.toString()),
                            null)
                }
                else -> {
                    throw UnsupportedOperationException("Unknown callbacks id: $id")
                }
            }
        } else {
            throw UnsupportedOperationException("Null context")
        }
    }

    override fun onLoadFinished(loader: Loader<Cursor>, cursor: Cursor) {
        if (cursor.count == 0) {
            if (viewSwitcher.nextView.id == R.id.customer_list_empty) {
                viewSwitcher.showNext()
            }
        } else {
            if (!isActionModeEnabled) {
                readDataFromCustomerCursor(cursor)
                calculateDistance()
                if (viewSwitcher.nextView.id == R.id.recyclerview_customer) {
                    viewSwitcher.showNext()

                    customerRecyclerView.run {
                        adapter!!.notifyDataSetChanged()
                        scheduleLayoutAnimation()
                    }
                }
            }
        }

        setActionBarTitle()
    }

    override fun onLoaderReset(loader: Loader<Cursor>) {
        // No operation.
    }

    override fun onCreateActionMode() {
        customerViewModel.isActionModeEnabled.value = true
        isActionModeEnabled = true
        setStatusBarColor(R.color.actionbar_primary_dark)

        customerViewModel.showReorder.value = true

        // Hide bottom navigation
        bottomNavigation.hide()
        // Disable refresh customer list
        swipeRefreshLayout.isEnabled = false
        // Backup customer list before reorder
        originalCustomerList.clear()
        originalCustomerList.addAll(customerAdapter.customers)
        // Notify adapter to show reorder icon
        customerAdapter.notifyDataSetChanged()
    }

    override fun onDestroyActionMode(isRollback: Boolean) {
        if (isRollback) {
            customerRecyclerView.apply {
                val lm = layoutManager as LinearLayoutManager
                val scrollPosition = lm.findFirstVisibleItemPosition()
                (adapter as CustomCustomerAdapter).submitList(originalCustomerList)
                lm.scrollToPosition(scrollPosition)
            }
        }
        customerViewModel.isActionModeEnabled.value = false
        isActionModeEnabled = false
        customerViewModel.showReorder.value = false
        bottomNavigation.show()
        swipeRefreshLayout.isEnabled = true
        setStatusBarColor(R.color.assign_dark)
    }

    override fun saveReorderCustomerList() {
        val batch = ArrayList<ContentProviderOperation>()
        batch.add(ContentProviderOperation.newDelete(OrderContract.CustomersIndices.CONTENT_URI).build())
        customerAdapter.customers.forEachIndexed { index, customer ->
            if (originalCustomerList.contains(customer)) {
                batch.add(ContentProviderOperation.newInsert(OrderContract.CustomersIndices.CONTENT_URI)
                        .withValue(OrderContract.CustomersIndices.CUSTOMERS_INDICES_CUSTOMER_ID, customer.id)
                        .withValue(OrderContract.CustomersIndices.CUSTOMERS_INDICES_NO, index + 1)
                        .build())
            }
        }
        try {
            val operations = batch.size
            if (operations > 0) {
                context?.contentResolver?.applyBatch(OrderContract.CONTENT_AUTHORITY, batch)
            }

            customerAdapter.notifyDataSetChanged()
            Toast.makeText(context, R.string.customer_reorder_success, Toast.LENGTH_LONG).show()
        } catch (e: RemoteException) {
            Toast.makeText(context, R.string.customer_reorder_error, Toast.LENGTH_LONG).show()
        } catch (e: OperationApplicationException) {
            Toast.makeText(context, R.string.customer_reorder_error, Toast.LENGTH_LONG).show()
        }
    }

    override fun openCustomerDetail(customer: Customer) {
        if (isActionModeEnabled) return

        val extras = Bundle().apply {
            putBoolean(Config.EXTRAS_INCOMPLETE_TASK, isNewTask)
            putBoolean(Config.EXTRAS_FINISH_ACTIVITY_AFTER_PRINT, false)
            putParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER, customer)
        }
        val intent = Intent(context, AgreementActivity::class.java)
        intent.putExtra(Config.EXTRAS_BUNDLE, extras)
        intent.putExtras(extras)
        startActivity(intent)
    }

    override fun startActionMode(): Boolean {
        if (!isNewTask or isActionModeEnabled) return false

        val callback = CustomerActionModeCallback(this)
        (activity as AppCompatActivity).startSupportActionMode(callback)
        return true
    }

    override fun startDragCustomer(holder: RecyclerView.ViewHolder) {
        itemTouchHelper.startDrag(holder)
    }

    private fun setActionBarTitle() {
        (activity as AppCompatActivity).supportActionBar?.run {
            customerAdapter.apply {
                val totalAmount = customers.sumOf { it.totalCollectAmount }.toFloat() / 100
                val currencyFormat = DecimalFormat("##,###,##0.##")
                if (isNewTask) {
                    if (itemCount > 0) {
                        title = getString(R.string.customer_list_undone_actionbar_title, itemCount, currencyFormat.format(totalAmount))
                    } else {
                        setTitle(R.string.navigation_assignment)
                    }
                } else {
                    if (itemCount > 0) {
                        title = getString(R.string.customer_list_done_actionbar_title, itemCount, currencyFormat.format(totalAmount))
                    } else {
                        setTitle(R.string.navigation_done_assignment)
                    }
                }
            }
        }
    }

    private fun restartLoaderManager() {
        if (isNewTask) {
            loaderManager.restartLoader(QUERY_UNDONE_CUSTOMER, null, this)
        } else {
            loaderManager.restartLoader(QUERY_DONE_CUSTOMER, null, this)
        }
    }

    private fun readDataFromCustomerCursor(cursor: Cursor) {
        mCustomers.clear()

        cursor.run {
            while (moveToNext()) {
                val customer = Customer(
                    getStringValue(OrderContract.Customers.CUSTOMER_IDCARD_NO),
                    getStringValue(OrderContract.Customers.CUSTOMER_NAME),
                    getIntValue(OrderContract.Customers.CUSTOMER_GENDER),
                    getIntValue(OrderContract.Customers.CUSTOMER_AGE),
                    getStringValue(OrderContract.Customers.CUSTOMER_ADDRESS),
                    getStringValue(OrderContract.Customers.CUSTOMER_SECTION),
                    getStringValue(OrderContract.Customers.CUSTOMER_ZIPCODE),
                    getStringValue(OrderContract.Customers.CUSTOMER_PHONE),
                    getStringValue(OrderContract.Customers.CUSTOMER_PHONE_EXT),
                    getStringValue(OrderContract.Customers.CUSTOMER_MOBILE),
                    getStringValue(OrderContract.Customers.CUSTOMER_DELN),
                    getStringValue(OrderContract.Customers.CUSTOMER_OS_BALANCE),
                    getStringValue(OrderContract.Customers.CUSTOMER_TOTAL_BILL),
                    getIntValue(OrderContract.Customers.CUSTOMER_TOTAL_AGREEMENTS),
                    getIntValue(OrderContract.Customers.CUSTOMER_TOTAL_URGENT_AGREEMENTS),
                    getIntValue(OrderContract.Customers.CUSTOMER_TOTAL_CANCELED_AGREEMENTS),
                    getDoubleValue(OrderContract.Customers.CUSTOMER_TOTAL_COLLECT_AMOUNT),
                    getStringValue(OrderContract.Orders.ORDER_CLIENT_NAME_EN),
                    getStringValue(OrderContract.Orders.ORDER_CLIENT_NAME_TH),
                    getStringValue(OrderContract.Orders.ORDER_CLIENT_CONTACT_NO),
                    lat = getDoubleValue(OrderContract.Customers.CUSTOMER_LAT, -0.1),
                    lon = getDoubleValue(OrderContract.Customers.CUSTOMER_LON, -0.1),
                    surveyType = getStringValue(OrderContract.Customers.CUSTOMER_SURVEY_TYPE),
                )
                mCustomers.add(customer)
            }
        }
        customerAdapter.submitList(mCustomers)
        //assignedCustomerAdapter.submitList(mCustomers)
    }

    private fun Cursor.getStringValue(columnName: String, defaultValue: String = ""): String {
        return if (isNull(getColumnIndexOrThrow(columnName))) defaultValue else getString(getColumnIndexOrThrow(columnName))
    }

    private fun Cursor.getIntValue(columnName: String, defaultValue: Int = 0): Int {
        return if (isNull(getColumnIndexOrThrow(columnName))) defaultValue else getInt(getColumnIndexOrThrow(columnName))
    }

    private fun Cursor.getDoubleValue(columnName: String, defaultValue: Double = 0.0): Double {
        return if (isNull(getColumnIndexOrThrow(columnName))) defaultValue else getDouble(getColumnIndexOrThrow(columnName))
    }

    private fun calculateDistance() {
        if (mCustomers.isEmpty()) return

        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Request permissions if not already granted
            shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener(requireActivity()) { currentLocation ->
                if (currentLocation != null) {
                    mCustomers.forEach { customer ->
                        if (customer.lat == -0.1 || customer.lon == -0.1) return@forEach

                        val destinationLocation = Location("")
                        destinationLocation.latitude = customer.lat
                        destinationLocation.longitude = customer.lon

                        val distanceInMeters = currentLocation.distanceTo(destinationLocation)
                        val distanceInKilometers = distanceInMeters / 1000
                        val distanceInKilometersWithThreeDecimal = distanceInKilometers.toDouble().round(3)
                        val distanceInKilometersWithTwoDecimal = distanceInKilometersWithThreeDecimal.round(2)
                        val distanceInKilometersWithOneDecimal = distanceInKilometersWithTwoDecimal.round(1)

                        customer.distance = distanceInKilometersWithOneDecimal.toDouble()
                    }
                    customerAdapter.notifyDataSetChanged()
                }
            }
    }

    private fun Double.round(decimals: Int = 2): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return round(this * multiplier) / multiplier
    }

    private inner class CustomerObserver(handler: Handler?) : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            restartLoaderManager()
        }
    }

    private val mIthCallback: ItemTouchHelper.Callback = object : ItemTouchHelper.Callback() {

        override fun isLongPressDragEnabled(): Boolean {
            return isDragEnabled
        }

        override fun isItemViewSwipeEnabled(): Boolean {
            return false
        }

        override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
        ): Int {
            val dragFlags = ItemTouchHelper.UP or ItemTouchHelper.DOWN
            val swipeFlags = 0
            return makeMovementFlags(dragFlags, swipeFlags)
        }

        override fun onMove(
                recyclerView: RecyclerView,
                source: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
        ): Boolean {
            if (source.itemViewType != target.itemViewType) {
                return false
            }
            val fromPosition = source.adapterPosition
            val toPosition = target.adapterPosition
            val adapter = recyclerView.adapter as CustomCustomerAdapter
            val items = adapter.customers
            if (fromPosition < toPosition) {
                for (i in fromPosition until toPosition) {
                    Collections.swap(items, i, i + 1)
                }
            } else {
                for (i in fromPosition downTo toPosition + 1) {
                    Collections.swap(items, i, i - 1)
                }
            }
            adapter.notifyItemMoved(fromPosition, toPosition)
            return true
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
    }

    private inner class CustomCustomerAdapter internal constructor(
            private val actionsHandler: CustomerActionsHandler,
            incomplete: Boolean
    ) : RecyclerView.Adapter<CustomCustomerCardViewHolder>() {

        var customers = mutableListOf<Customer>()
        private val mIncompleteTask: Boolean = incomplete

        fun submitList(newItems: List<Customer>) {
            customers = newItems.toMutableList()
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomCustomerCardViewHolder {
            return CustomCustomerCardViewHolder(
                    LayoutInflater.from(parent.context).inflate(R.layout.item_customer, parent, false)
            )
        }

        override fun onBindViewHolder(holder: CustomCustomerCardViewHolder, position: Int) {
            val customer = customers[position]
            Log.d("CustomerFragment", "onBindViewHolder: $customer")

            holder.surveyType.text = customer.surveyType
            holder.surveyType.setBackgroundResource(R.drawable.circle_shape)

            if (customer.totalUrgent > 0) {
                holder.surveyType.setBackgroundResource(R.drawable.bg_urgent)
            }

            if (customer.totalCancel > 0) {
                holder.surveyType.setBackgroundResource(R.drawable.bg_canceled)
            }

            holder.name.run {
                val name = customer.name.split("/").first()
                text = if (isNewTask) {
                    getString(
                        R.string.customer_name_with_distance,
                        position + 1,
                        name,
                        customer.distance.toString()
                    )
                } else {
                    name
                }
            }

            var customerAddress = customer.address
            customerAddress = customerAddress.trim()
            customerAddress = customerAddress.replace("S._", "")
            customerAddress = customerAddress.replace("S.", "")
            customerAddress = customerAddress + " " + customer.zipcode
            holder.address.text = customerAddress

            val textTotalAgreements = getString(R.string.customer_list_item_total_agreements, customer.totalAgreements)
            val customerInfo = mutableListOf(textTotalAgreements)
            if (customer.totalCollectAmount > 0.0) {
                val totalCollectAmount = customer.totalCollectAmount / 100
                val textTotalCollectAmount = getString(
                        R.string.customer_list_item_total_collect_amount,
                        decimalFormatWithCommasExcludeZeros().format(totalCollectAmount))
                customerInfo.add(textTotalCollectAmount)
            }
            if (customer.delinquentStatus.isNotEmpty()) {
                val textDelinquentStatus = "D%s".format(customer.delinquentStatus)
                customerInfo.add(textDelinquentStatus)
            }
            if (customer.osBalance.isNotEmpty()) {
                val textTotalOsBalance = getString(
                        R.string.customer_list_total_os_balance,
                        decimalFormatWithCommasExcludeZeros().format(customer.osBalance.toDouble()))
                customerInfo.add(textTotalOsBalance)
            }
            if (customer.totalBill.isNotEmpty()) {
                val textTotalBilling = getString(
                        R.string.customer_list_total_billing,
                        decimalFormatWithCommasExcludeZeros().format(customer.totalBill.toDouble()))
                customerInfo.add(textTotalBilling)
            }
            val isOutsourceJob = customer.delinquentStatus.isEmpty() or customer.osBalance.isEmpty() or customer.totalBill.isEmpty()
            if (isOutsourceJob && customer.clientNameTh.isNotEmpty()) {
                customerInfo.add(customer.clientNameTh)
            }
            holder.info.text = customerInfo.joinToString(" / ")

            holder.card.run {
                setOnClickListener { actionsHandler.openCustomerDetail(customer) }
                setOnLongClickListener {
                    actionsHandler.startActionMode()
                }
            }

            holder.reorder.run {
                visibility = if (isActionModeEnabled) View.VISIBLE else View.GONE

                setOnTouchListener { _, event ->
                    if (event.action == MotionEvent.ACTION_DOWN) {
                        actionsHandler.startDragCustomer(holder)
                    }
                    false
                }
            }
        }

        override fun getItemCount() = customers.size

        override fun getItemId(position: Int) = customers[position].hashCode().toLong()
    }

    private class CustomCustomerCardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val card: CardView = itemView as CardView
        val surveyType: TextView = card.findViewById(R.id.initials_placeholder)
        val name: TextView = card.findViewById(R.id.customer_name)
        val address: TextView = card.findViewById(R.id.customer_address)
        val info: TextView = card.findViewById(R.id.customer_info)
        val reorder: ImageView = card.findViewById(R.id.drag_handle_icon)
    }

    companion object {

        private const val QUERY_UNDONE_CUSTOMER = 0x1
        private const val QUERY_DONE_CUSTOMER = 0x2

        fun newInstance(incomplete: Boolean): CustomerFragment {
            val arguments = Bundle()
            arguments.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, incomplete)
            val fragment = CustomerFragment()
            fragment.arguments = arguments
            return fragment
        }
    }
}