package com.aeon.mci.ui.agreement

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.provider.BaseColumns
import com.google.android.material.floatingactionbutton.FloatingActionButton
import androidx.fragment.app.Fragment
import androidx.loader.app.LoaderManager
import androidx.core.content.ContextCompat
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ActionMode
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.text.Html
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import android.widget.ViewSwitcher
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.model.Order
import com.aeon.mci.persistence.Customer
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.ui.PrintActivity
import com.aeon.mci.ui.order.OrderActivity
import com.aeon.mci.ui.result.EditResultDialogFragment.Companion.newInstance
import com.aeon.mci.ui.result.EditResultDialogFragment.EditResultDialogListener
import com.aeon.mci.util.setStatusBarColor
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class AgreementFragment : Fragment(), EditResultDialogListener {

    private lateinit var mFab: FloatingActionButton
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var mRecyclerViewAdapter: AgreementAdapter
    private lateinit var mObserver: ContentObserver
    private var mActionMode: ActionMode? = null
    private var mViewSwitcher: ViewSwitcher? = null
    private val mOrders = ArrayList<Order>()
    private var mIncompleteTask = false
    private var mCustomer: Customer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true

        arguments?.run {
            mIncompleteTask = getBoolean(Config.EXTRAS_INCOMPLETE_TASK)
            mCustomer = getParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER)
        }

        if (mIncompleteTask) {
            Timber.d("init loader for undone order")
            loaderManager.initLoader(QUERY_UNDONE_ORDER, null, mAgreementLoader)
        } else {
            Timber.d("init loader for done order")
            loaderManager.initLoader(QUERY_DONE_ORDER, null, mAgreementLoader)
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_agreement, container, false)

        if (mIncompleteTask) {
            mFab = requireActivity().findViewById(R.id.fab)
            mFab.setOnClickListener {
                val selected = ArrayList<Order>()
                for (i in 0 until mRecyclerViewAdapter.itemCount) {
                    val holder = mRecyclerView.findViewHolderForAdapterPosition(i) as AgreementCardViewHolder
                    if (holder.checkBox.isChecked) {
                        selected.add(mOrders[i])
                    }
                }
                showEditResultDialog(selected)
            }
        }
        mViewSwitcher = view.findViewById(R.id.agreement_list_view_switcher)

        // Set empty view text
        val emptyView: TextView = view.findViewById(R.id.agreement_list_empty)
        emptyView.text = Html.fromHtml(getString(R.string.agreement_list_empty))

        // Set the adapter
//        val context = view.context
        mRecyclerView = view.findViewById(R.id.agreement_list)
        mRecyclerView.setLayoutManager(LinearLayoutManager(context))
        mRecyclerViewAdapter = AgreementAdapter(requireActivity(), mOrders)
        mRecyclerView.setAdapter(mRecyclerViewAdapter)
        return view
    }

    override fun onResume() {
        super.onResume()
        restartLoader()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        mObserver = AgreementObserver(Handler())
        activity?.applicationContext?.contentResolver?.run {
            registerContentObserver(OrderContract.Orders.CONTENT_URI, true, mObserver)
        }
    }

    override fun onDetach() {
        super.onDetach()
        activity?.applicationContext?.contentResolver?.unregisterContentObserver(mObserver)
    }

    private fun showEditResultDialog(selected: ArrayList<Order>) {
        val bundle = Bundle()
        bundle.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, mIncompleteTask)
        bundle.putParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS, selected)
        if (activity != null) {
            val fragmentManager = requireActivity().supportFragmentManager
            val dialog = newInstance(this)
            dialog.arguments = bundle
            dialog.isCancelable = false
            dialog.setTargetFragment(this, AGREEMENT_FRAGMENT)
            dialog.show(fragmentManager, "fragment_edit_result")
        }
    }

    override fun onFinishEditResult(data: Intent) {
        if (mActionMode != null) {
            mActionMode!!.finish()
        }

        val extras = data.extras
        if (extras != null) {
            val activity: Activity? = activity
            if (activity is PrintActivity) {
                activity.saveResult(extras)
            }
        }
    }

    private fun restartLoader() {
        if (mIncompleteTask) {
            loaderManager.restartLoader(QUERY_UNDONE_ORDER, null, mAgreementLoader)
        } else {
            loaderManager.restartLoader(QUERY_DONE_ORDER, null, mAgreementLoader)
        }
    }

    private val mActionModeCallback: ActionMode.Callback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            val inflater = mode.menuInflater
            inflater.inflate(R.menu.context_agreement, menu)
            setStatusBarColor(R.color.actionbar_primary_dark)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            mFab.visibility = View.VISIBLE
            return false
        }

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            return when (item.itemId) {
                R.id.action_select_all -> {
                    toggleAllItems(true)
                    true
                }
                else -> {
                    false
                }
            }
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            toggleAllItems(false)
            mActionMode = null
            mFab.visibility = View.GONE
            setStatusBarColor(R.color.assign_dark)
        }
    }

    private fun toggleAllItems(checkedAll: Boolean) {
        for (i in 0 until mRecyclerViewAdapter.itemCount) {
            val holder = mRecyclerView.findViewHolderForAdapterPosition(i) as AgreementCardViewHolder
            if (checkedAll) {
                if (!holder.checkBox.isChecked) {
                    holder.checkBox.toggle()
                }
            } else {
                holder.checkBox.isChecked = false
            }
        }
    }

    //    @Override
    //    public Loader<Cursor> onCreateLoader(int id, Bundle bundle) {
    //        switch (id) {
    //            case QUERY_UNDONE_ORDER: {
    //                return new CursorLoader(getActivity(),
    //                        OrderContract.Orders.CONTENT_URI_ORDERS_UNDONE,
    //                        OrdersQuery.UNDONE_PROJECTION,
    //                        null, new String[]{mCustomer.id}, null);
    //            }
    //            case QUERY_DONE_ORDER: {
    //                Calendar calendar = Calendar.getInstance();
    //                calendar.set(Calendar.HOUR_OF_DAY, 0);
    //                calendar.set(Calendar.MINUTE, 0);
    //                calendar.set(Calendar.SECOND, 0);
    //                int start = (int) (calendar.getTime().getTime() / 1000L);
    //                calendar.add(Calendar.DATE, 1);
    //                int end = (int) (calendar.getTime().getTime() / 1000L);
    //
    //                return new CursorLoader(getActivity(),
    //                        OrderContract.Orders.CONTENT_URI_ORDERS_DONE,
    //                        OrdersQuery.DONE_PROJECTION,
    //                        null,
    //                        new String[]{mCustomer.id, String.valueOf(start), String.valueOf(end)},
    //                        null);
    //            }
    //            default: {
    //                throw new UnsupportedOperationException("Unknown callbacks id: " + id);
    //            }
    //        }
    //    }
    //
    //    @Override
    //    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
    //        if (cursor.getCount() > 0 && mActionMode == null) {
    //            readDataFromOrderCursor(cursor);
    //            mRecyclerViewAdapter.update(mOrders);
    //            if (mViewSwitcher.getNextView().getId() == R.id.agreement_list) {
    //                mViewSwitcher.showNext();
    //                runLayoutAnimation(mRecyclerView);
    //            }
    //        } else if (cursor.getCount() == 0) {
    //            if (mViewSwitcher.getNextView().getId() == R.id.agreement_list_empty) {
    //                mViewSwitcher.showNext();
    //            }
    //        }
    //    }
    //
    //    @Override
    //    public void onLoaderReset(Loader<Cursor> loader) {
    //        // no op
    //    }

    private inner class AgreementObserver(handler: Handler?) : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
        }

        override fun onChange(selfChange: Boolean, uri: Uri?) {
            restartLoader()
        }
    }

    /**
     * LoaderCallbacks for the agreement list that load new or done jobs.
     */
    private val mAgreementLoader: LoaderManager.LoaderCallbacks<Cursor> = object : LoaderManager.LoaderCallbacks<Cursor> {
        override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor> {
            return when (id) {
                QUERY_UNDONE_ORDER -> {
                    CursorLoader(activity!!,
                            OrderContract.Orders.CONTENT_URI_ORDERS_UNDONE,
                            OrdersQuery.UNDONE_PROJECTION,
                            null, arrayOf(mCustomer!!.id), null)
                }
                QUERY_DONE_ORDER -> {
                    val calendar = Calendar.getInstance()
                    calendar[Calendar.HOUR_OF_DAY] = 0
                    calendar[Calendar.MINUTE] = 0
                    calendar[Calendar.SECOND] = 0
                    val start = (calendar.time.time / 1000L).toInt()
                    calendar.add(Calendar.DATE, 1)
                    val end = (calendar.time.time / 1000L).toInt()
                    Timber.d("loader from customer id: %s", mCustomer!!.id)
                    CursorLoader(activity!!,
                            OrderContract.Orders.CONTENT_URI_ORDERS_DONE,
                            OrdersQuery.DONE_PROJECTION,
                            null, arrayOf(mCustomer!!.id, start.toString(), end.toString()),
                            null)
                }
                else -> {
                    throw UnsupportedOperationException("Unknown callbacks id: $id")
                }
            }
        }

        override fun onLoadFinished(loader: Loader<Cursor>, cursor: Cursor) {
            if (cursor.count > 0 && mActionMode == null) {
                readDataFromOrderCursor(cursor)
                mRecyclerViewAdapter.update(mOrders)
                if (mViewSwitcher!!.nextView.id == R.id.agreement_list) {
                    mViewSwitcher!!.showNext()
                    runLayoutAnimation(mRecyclerView)
                }
            } else if (cursor.count == 0) {
                if (mViewSwitcher!!.nextView.id == R.id.agreement_list_empty) {
                    mViewSwitcher!!.showNext()
                }
            }
        }

        override fun onLoaderReset(loader: Loader<Cursor>) {
            // no op
        }
    }

    private fun runLayoutAnimation(recyclerView: RecyclerView?) {
        val context = recyclerView!!.context
        val controller = AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_fall_down)
        recyclerView.layoutAnimation = controller
        recyclerView.adapter!!.notifyDataSetChanged()
        recyclerView.scheduleLayoutAnimation()
    }

    private fun readDataFromOrderCursor(cursor: Cursor?) {
        mOrders.clear()
        if (cursor != null && cursor.moveToFirst()) {
            do {
                val order = Order.fromCursorRow(cursor)
                if (order != null) {
                    mOrders.add(order)
                }
            } while (cursor.moveToNext())
        }
    }

    private inner class AgreementAdapter internal constructor(
            private val mHost: Activity,
            data: ArrayList<Order>
    ) : RecyclerView.Adapter<AgreementCardViewHolder>() {

        private val mInflater: LayoutInflater
        private var mItems: List<Order>
        private var mCheckedCount = 0

        fun update(newItems: ArrayList<Order>) {
            mItems = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AgreementCardViewHolder {
            return AgreementCardViewHolder(
                    mInflater.inflate(R.layout.item_agreement, parent, false))
        }

        override fun onBindViewHolder(holder: AgreementCardViewHolder, position: Int) {
            val order = mItems[position]
            var agreementNo = order.agreementNo
            if (agreementNo.length == 16) {
                agreementNo = agreementNo.replace(agreementNo.substring(6, 12), "XXXXXX")
            }
            holder.agreementDesc.text = order.description
            holder.agreementNo.text = agreementNo
            holder.operator.text = order.operatorName
            //            holder.surveyType.setText(order.surveyName);
            holder.card.setOnClickListener { v: View ->
                if (mIncompleteTask) {
                    if (mActionMode != null) {
                        holder.checkBox.toggle()
                        return@setOnClickListener
                    }
                }
                val extras = Bundle()
                extras.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, mIncompleteTask)
                extras.putParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER, mCustomer)
                extras.putParcelable(Config.BUNDLE_ARG_MODEL_ORDER, order)
                extras.putBoolean(Config.EXTRAS_FINISH_ACTIVITY_AFTER_PRINT, true)
                val intent = Intent(v.context.applicationContext, OrderActivity::class.java)
                intent.putExtras(extras)
                intent.putExtra(Config.EXTRAS_BUNDLE, extras)
                startActivity(intent)
//                OrderActivity.starterIntent(context!!, order.id, mCustomer!!, !mIncompleteTask)
            }
            holder.card.setOnLongClickListener { v: View? ->
                if (mIncompleteTask) {
                    if (mActionMode == null) {
                        holder.checkBox.toggle()
                        return@setOnLongClickListener true
                    }
                }
                false
            }
            holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean ->
                if (isChecked) {
                    mCheckedCount++
                    if (mActionMode == null) {
                        mActionMode = (mHost as AppCompatActivity).startSupportActionMode(mActionModeCallback)
                    }
                } else {
                    mCheckedCount--
                    if (mCheckedCount == 0) {
                        mActionMode!!.finish()
                    }
                }
                if (mCheckedCount > 0) {
                    val title = getString(R.string.agreement_list_cab_selected_title, mCheckedCount)
                    mActionMode!!.title = title
                }
            }
            holder.checkBox.visibility = if (mIncompleteTask) View.VISIBLE else View.GONE
            val currencyFormat = DecimalFormat("##,###,##0.##")
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
            if (mIncompleteTask) {
                val amount = order.collectAmount.toFloat() / 100
                //                holder.amount.setText(mHost.getString(
//                        R.string.agreement_list_amount, currencyFormat.format(amount)));
                if (amount == 0f) {
                    holder.surveyType.text = order.surveyName
                    //                    holder.amount.setVisibility(View.GONE);
                } else {
                    holder.surveyType.text = order.surveyName + ": " + mHost.getString(
                            R.string.agreement_list_amount, currencyFormat.format(amount.toDouble()))
                    //                    holder.amount.setVisibility(View.VISIBLE);
                }
                val dateTimestamp = order.collectDate * 1000L
                val date = Date(dateTimestamp)
                holder.date.text = dateFormat.format(date)
                holder.surveyType.setTextColor(ContextCompat.getColor(mHost, R.color.blue))
                holder.operator.visibility = View.VISIBLE
                //                holder.amount.setTextColor(
//                        ContextCompat.getColor(mHost, R.color.color_new_assignment_primary_dark));
            } else {
                when (order.jobStatus) {
                    "89", "97", "98", "99" -> holder.surveyType.setText(R.string.agreement_item_canceled)
                    else -> {
                        val amount = order.resultCollectedAmount.toFloat() / 100
                        if (amount == 0f) {
                            holder.surveyType.text = order.resultName
                        } else {
                            holder.surveyType.text = order.resultName + ": " + mHost.getString(
                                    R.string.agreement_list_amount, currencyFormat.format(amount.toDouble()))
                        }
                    }
                }

//                if (TextUtils.equals(order.taskType, "C")) {
//                    holder.surveyType.setText(R.string.agreement_item_canceled);
//                } else {
//                    float amount = (float) order.resultCollectedAmount / 100;
//                    if (amount == 0) {
//                        holder.surveyType.setText(order.resultName);
//                    } else {
//                        holder.surveyType.setText(order.resultName + ": " + mHost.getString(
//                                R.string.agreement_list_amount, currencyFormat.format(amount)));
//                    }
//                }
                holder.date.text = dateFormat.format(Date(order.resultCollectedDate * 1000L))
                holder.operator.text = null
                holder.operator.visibility = View.GONE
                //                holder.operator.setText(dateFormat.format(new Date(order.collectDate * 1000L)));
                holder.surveyType.setTextColor(ContextCompat.getColor(mHost, R.color.green))
                //                holder.amount.setTextColor(
//                        ContextCompat.getColor(mHost, R.color.color_done_assignment_primary_dark));
            }
        }

        override fun getItemCount(): Int {
            return mItems.size
        }

        init {
            mItems = data
            mInflater = LayoutInflater.from(mHost)
        }
    }

    private class AgreementCardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val card: CardView
        val checkBox: CheckBox
        val urgentTag: TextView
        val pendingTag: TextView
        val canceledTag: TextView
        val agreementDesc: TextView
        val agreementNo: TextView
        val operator: TextView
        val amount: TextView
        val surveyType: TextView
        val date: TextView

        init {
            card = itemView as CardView
            checkBox = card.findViewById(R.id.agreement_checkbox)
            urgentTag = card.findViewById(R.id.agreement_tag_urgent)
            pendingTag = card.findViewById(R.id.agreement_tag_pending)
            canceledTag = card.findViewById(R.id.agreement_tag_canceled)
            agreementDesc = card.findViewById(R.id.agreement_description)
            agreementNo = card.findViewById(R.id.agreement_no)
            operator = card.findViewById(R.id.agreement_operator)
            amount = card.findViewById(R.id.agreement_amount)
            surveyType = card.findViewById(R.id.agreement_survey_type_name)
            date = card.findViewById(R.id.agreement_date)
        }
    }

    companion object {
        private const val AGREEMENT_FRAGMENT = 0x1
        private const val QUERY_UNDONE_ORDER = 0x3
        private const val QUERY_DONE_ORDER = 0x4

        fun newInstance(customer: Customer?, incomplete: Boolean): AgreementFragment {
            val arguments = Bundle()
            arguments.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, incomplete)
            arguments.putParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER, customer)
            val fragment = AgreementFragment()
            fragment.arguments = arguments
            return fragment
        }
    }
}

object OrdersQuery {
    val UNDONE_PROJECTION = arrayOf(
            BaseColumns._ID,
            OrderContract.Orders.ORDER_NO,
            OrderContract.Orders.CUSTOMER_IDCARD_NO,
            OrderContract.Orders.ORDER_AGREEMENT_NO,
            OrderContract.Orders.ORDER_GUID,
            OrderContract.Orders.ORDER_DESCRIPTION,
            OrderContract.Orders.ORDER_SURVEY_NAME,
            OrderContract.Orders.ORDER_SURVEY_PRIORITY,
            OrderContract.Orders.ORDER_COLLECT_DATE,
            OrderContract.Orders.ORDER_COLLECT_AMOUNT,
            OrderContract.Orders.ORDER_STATUS,
            OrderContract.Orders.ORDER_PRIORITY,
            OrderContract.Orders.ORDER_OPERATOR_NAME,
            OrderContract.Orders.ORDER_AUTOCALL_REMARK,
            OrderContract.Orders.ORDER_DELINQUENT_STATUS,
            OrderContract.Orders.ORDER_OUTSTANDING_BALANCE,
            OrderContract.Orders.ORDER_PENALTY,
            OrderContract.Orders.ORDER_CURRENT_BILL,
            OrderContract.Orders.ORDER_D1,
            OrderContract.Orders.ORDER_D1_ADD_PENALTY,
            OrderContract.Orders.ORDER_D2,
            OrderContract.Orders.ORDER_D2_ADD_PENALTY,
            OrderContract.Orders.ORDER_D3,
            OrderContract.Orders.ORDER_D3_ADD_PENALTY,
            OrderContract.Orders.ORDER_D4,
            OrderContract.Orders.ORDER_D4_ADD_PENALTY,
            OrderContract.Orders.ORDER_D5,
            OrderContract.Orders.ORDER_D5_ADD_PENALTY,
            OrderContract.Orders.ORDER_TOTAL_DELINQUENT,
            OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY,
            OrderContract.Orders.ORDER_MINIMUM_BILL,
            OrderContract.Orders.ORDER_FULL_BILL,
            OrderContract.Orders.COLLECTOR_RESULT_CODE,
            OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
            OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT,
            OrderContract.Orders.ORDER_RESULT_PROMISED_DATE,
            OrderContract.Orders.ORDER_RESULT_REMARK,
            OrderContract.SyncColumns.UPDATED_FLAG,
            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG,
            OrderContract.Orders.ORDER_TOKEN,
            OrderContract.Orders.ORDER_CLIENT_NAME_EN,
            OrderContract.Orders.ORDER_CLIENT_NAME_TH,
            OrderContract.Orders.ORDER_CLIENT_CONTACT_NO
    )
    val DONE_PROJECTION = arrayOf(
            BaseColumns._ID,
            OrderContract.Orders.ORDER_NO,
            OrderContract.Orders.CUSTOMER_IDCARD_NO,
            OrderContract.Orders.ORDER_AGREEMENT_NO,
            OrderContract.Orders.ORDER_GUID,
            OrderContract.Orders.ORDER_DESCRIPTION,
            OrderContract.Orders.ORDER_SURVEY_NAME,
            OrderContract.Orders.ORDER_COLLECT_DATE,
            OrderContract.Orders.ORDER_COLLECT_AMOUNT,
            OrderContract.Orders.ORDER_STATUS,
            OrderContract.Orders.ORDER_TASK_TYPE,
            OrderContract.Orders.ORDER_OPERATOR_NAME,
            OrderContract.Orders.ORDER_AUTOCALL_REMARK,
            OrderContract.Orders.ORDER_DELINQUENT_STATUS,
            OrderContract.Orders.ORDER_OUTSTANDING_BALANCE,
            OrderContract.Orders.ORDER_PENALTY,
            OrderContract.Orders.ORDER_CURRENT_BILL,
            OrderContract.Orders.ORDER_D1,
            OrderContract.Orders.ORDER_D1_ADD_PENALTY,
            OrderContract.Orders.ORDER_D2,
            OrderContract.Orders.ORDER_D2_ADD_PENALTY,
            OrderContract.Orders.ORDER_D3,
            OrderContract.Orders.ORDER_D3_ADD_PENALTY,
            OrderContract.Orders.ORDER_D4,
            OrderContract.Orders.ORDER_D4_ADD_PENALTY,
            OrderContract.Orders.ORDER_D5,
            OrderContract.Orders.ORDER_D5_ADD_PENALTY,
            OrderContract.Orders.ORDER_TOTAL_DELINQUENT,
            OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY,
            OrderContract.Orders.ORDER_MINIMUM_BILL,
            OrderContract.Orders.ORDER_FULL_BILL,
            OrderContract.Orders.COLLECTOR_RESULT_CODE,
            OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE,
            OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT,
            OrderContract.Orders.ORDER_RESULT_PROMISED_DATE,
            OrderContract.Orders.ORDER_RESULT_REMARK,
            OrderContract.SyncColumns.UPDATED_FLAG,
            OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG,
            OrderContract.Orders.ORDER_TOKEN,
            OrderContract.Orders.ORDER_CLIENT_NAME_EN,
            OrderContract.Orders.ORDER_CLIENT_NAME_TH,
            OrderContract.Orders.ORDER_CLIENT_CONTACT_NO
    )
}