package com.aeon.mci.persistence

import com.google.gson.annotations.SerializedName

data class WorkOrder(
        val id: Long,
        val sentDate: String = "",
        val guid: String,
        val agreementNo: String,
        val agreementDesc: String,
        @SerializedName("agreementNoToken")
        val token: String,
        @SerializedName("idCardNo")
        val customerId: String,
        val taskType: String,
        val priority: String,
        val jobStatus: Int,
        @SerializedName("surveyCode")
        val surveyTypeCode: String,
        @SerializedName("surveyName")
        val surveyTypeName: String,
        val collectDate: String,
        val collectTime: String,
        val collectAmount: Double,
        val operatorName: String,
        @SerializedName("remark")
        val autocallRemark: String,
        val delinquentStatus: Int,
        val outstandingBalance: Double,
        val penalty: Double,
        val currentBill: Double,
        val d1: Double,
        val d1AddPenalty: Double,
        val d2: Double,
        val d2AddPenalty: Double,
        val d3: Double,
        val d3AddPenalty: Double,
        val d4: Double,
        val d4AddPenalty: Double,
        val d5: Double,
        val d5AddPenalty: Double,
        val totalDelinquent: Double,
        val totalAddPenalty: Double,
        val minimumBill: Double,
        val fullBill: Double,
        val paymentCode: String,
        val clientNameTh: String,
        val clientNameEn: String,
        val clientContactNo: String,
        @SerializedName("customerName")
        val name: String,
        val gender: Int,
        val age: Int,
        val address: String,
        val section: String,
        val zipcode: String,
        val phone: String,
        val phoneExt: String,
        val mobile: String,
        @SerializedName("idMaxDel")
        val idDelinquentStatus: String,
        @SerializedName("idOsBalance")
        val idOsBalance: String,
        @SerializedName("idTotalBill")
        val idTotalBill: String
)