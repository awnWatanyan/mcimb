package com.aeon.mci.service.tracking

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import com.aeon.mci.R
import dagger.hilt.android.AndroidEntryPoint
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

@AndroidEntryPoint
class TrackingService : Service() {

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundService()
    }

    override fun onDestroy() {
        clearNotification()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createTrackingUpdateServiceAlarm()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        val importance = NotificationManager.IMPORTANCE_LOW
        val channel = NotificationChannel(TRACKING_CHANNEL_ID, TRACKING_CHANNEL_NAME, importance).apply {
            setShowBadge(false)
            enableVibration(false)
            enableLights(false)
        }
        getNotificationManager().createNotificationChannel(channel)
    }

    private fun startForegroundService() {
        val notification: Notification = Notification.Builder(this, TRACKING_CHANNEL_ID).apply {
            setContentTitle(getString(R.string.tracking_notification_title))
            setContentText(getString(R.string.tracking_notification_content))
            setSmallIcon(R.drawable.ic_notification_motorcycle)
            setOngoing(true)
            setShowWhen(true)
            setTicker("flsmobile_tracking_service")
        }.build()
        startForeground(TRACKING_NOTIFICATION_ID, notification)
    }

    private fun createTrackingUpdateServiceAlarm() {
        val intent = Intent(this, TrackingUpdateService::class.java)
        val pendingIntent = PendingIntent.getService(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        val typeOfAlarm = AlarmManager.ELAPSED_REALTIME_WAKEUP
        val triggerAt = SystemClock.elapsedRealtime()
        val threeMinutes: Duration = 3.minutes
        val interval = threeMinutes.inWholeMilliseconds
        getAlarmManager().setRepeating(typeOfAlarm, triggerAt, interval, pendingIntent)
    }

    private fun clearNotification() {
        getNotificationManager().cancel(TRACKING_NOTIFICATION_ID)
    }

    private fun getNotificationManager(): NotificationManager {
        return getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    private fun getAlarmManager(): AlarmManager {
        return getSystemService(Context.ALARM_SERVICE) as AlarmManager
    }

    companion object {
        const val TRACKING_NOTIFICATION_ID = 1
        const val TRACKING_CHANNEL_ID = "flsmobile_tracking_channel_id"
        const val TRACKING_CHANNEL_NAME = "flsmobile_tracking_channel_name"
    }
}