package com.aeon.mci.ui.signin

import android.accounts.Account
import android.accounts.AccountManager
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.aeon.mci.BuildConfig
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.databinding.ActivitySignInBinding
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.syncadapter.DefaultBackendVolley
import com.aeon.mci.syncadapter.SyncAdapter
import com.aeon.mci.syncadapter.SyncHelper
import com.aeon.mci.util.*
import com.aeon.mci.widget.helper.RemoveErrorTextWatcher
import com.android.volley.AuthFailureError
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONException
import org.json.JSONObject
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class SignInActivity : AppCompatActivity() {

    @Inject
    lateinit var accountManager: AccountManager

    private lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!BuildConfig.DEBUG) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        //setContent {
        //    Scaffold { innerPadding ->
        //        Surface(
        //            modifier = Modifier
        //                .fillMaxSize()
        //                .padding(innerPadding),
        //            color = MaterialTheme.colorScheme.primary,
        //        ) {
        //            SignInScreen()
        //        }
        //    }
        //
        //}

        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginAppVersion.apply {
            text = getString(R.string.version, BuildConfig.VERSION_NAME)
        }

        // Set up the login form.
        binding.loginUsername.apply {
            editText?.addTextChangedListener(RemoveErrorTextWatcher(this))
        }

        binding.loginPassword.apply {
            editText?.run {
                //setOnEditorActionListener { _, id, _ ->
                //    when (id) {
                //        R.id.login, EditorInfo.IME_NULL -> {
                //            attemptLogin()
                //            return@setOnEditorActionListener true
                //        }
                //        else -> return@setOnEditorActionListener false
                //    }
                //}
                setOnFocusChangeListener { view, hasFocus ->
                    if (!hasFocus) {
                        (view as EditText).transformationMethod = PasswordTransformationMethod.getInstance()
                    }
                }
                addTextChangedListener(RemoveErrorTextWatcher(this@apply))
            }
        }

        binding.loginDeviceId.apply {
            val deviceId = AccountUtils.getDeviceImei(this@SignInActivity)
            val deviceIdEnabled = deviceId.isNullOrEmpty()
            editText?.setText(deviceId)
            isEnabled = deviceIdEnabled
            editText?.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val newDeviceId = editText?.text.toString()
                    AccountUtils.setDeviceImei(applicationContext, newDeviceId)
                    isEnabled = false
                }
            }
        }

        //binding.loginEditDeviceId.setOnClickListener {
        //    val enabledLoginDeviceId = binding.loginDeviceId.isEnabled
        //    binding.loginDeviceId.isEnabled = !enabledLoginDeviceId
        //}

        binding.loginDeviceIdSwitch.setOnCheckedChangeListener { _, isChecked ->
            binding.loginDeviceId.isEnabled = isChecked
        }

        binding.loginSignInButton.setOnClickListener {
            // Clear focus from all EditTexts
            binding.loginUsername.clearFocus()
            binding.loginPassword.clearFocus()
            binding.loginDeviceId.clearFocus()

            // Hide the keyboard if it's visible
            val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(binding.root.windowToken, 0)

            attemptLogin()
        }

        setTaskDescription()
        setStatusBarColor(R.color.purple_dark)

        onBackPressedDispatcher.addCallback(this) {
            // Prevent move back to the MainActivity
            moveTaskToBack(true)
        }
    }

    override fun onResume() {
        super.onResume()
        val accounts = accountManager.getAccountsByType(BuildConfig.MCI_ACCOUNT_TYPE)
        if (accounts.isNotEmpty()) {
            finish()
        }
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private fun attemptLogin() {
        // Reset errors.
        binding.loginUsername.resetError()
        binding.loginPassword.resetError()

        // Store values at the time of the login attempt.
        var username: String? = null
        if (binding.loginUsername.editText != null) {
            username = binding.loginUsername.editText!!.text.toString()
        }
        var password: String? = null
        if (binding.loginPassword.editText != null) {
            password = binding.loginPassword.editText!!.text.toString()
        }
        var deviceId: String? = null
        if (binding.loginDeviceId.editText != null) {
            deviceId = binding.loginDeviceId.editText!!.text.toString()
        }

        var cancel = false
        var focusView: View? = null

        // Check for a valid username.
        if (TextUtils.isEmpty(username)) {
            binding.loginUsername.setError(R.string.login_error_empty_username)
            focusView = binding.loginUsername.editText
            cancel = true
        } else {
            if (username!!.indexOf(' ') >= 0) {
                binding.loginUsername.setError(R.string.login_error_invalid_username)
                focusView = binding.loginUsername.editText
                cancel = true
            }
        }

        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(password) && !cancel) {
            binding.loginPassword.setError(R.string.login_error_empty_password)
            focusView = binding.loginPassword.editText
            cancel = true
        }

        if (TextUtils.isEmpty(deviceId) && !cancel) {
            cancel = true
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView?.requestFocus()
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            showProgress(true)
            val imei = AccountUtils.getDeviceImei(this)

//            SignInUserDataSource.login(username!!, password!!, imei)
            emitSignInRequest(username!!, password!!, imei)
        }
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    private fun showProgress(show: Boolean) {
        val shortAnimTime = resources.getInteger(android.R.integer.config_shortAnimTime)

        binding.loginSignInButton.apply {
            visibility = if (show) View.GONE else View.VISIBLE
            animate().run {
                duration = shortAnimTime.toLong()
                alpha = if (show) 0f else 1f
                setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        this@apply.visibility = if (show) View.GONE else View.VISIBLE
                    }
                })
            }
        }

        binding.loginProgress.apply {
            visibility = if (show) View.VISIBLE else View.GONE
            animate().run {
                duration = shortAnimTime.toLong()
                alpha = if (show) 1f else 0f
                setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        this@apply.visibility = if (show) View.VISIBLE else View.GONE
                    }
                })
            }
        }
    }

    private fun onSignInSuccess(username: String, imei: String, response: String) {
        showProgress(false)

        try {
            val json = JSONObject(response)
            val extras = Bundle().apply {
                putString(AccountManager.KEY_ACCOUNT_NAME, username)
                putString(AccountManager.KEY_ACCOUNT_TYPE, BuildConfig.MCI_ACCOUNT_TYPE)
                putString(AccountManager.KEY_AUTHTOKEN, json.getString(Config.AUTHTOKEN_TYPE_REFRESH_TOKEN))
                putString("access_token", json.getString("access_token"))
                putString(Config.BUNDLE_ARG_AUTH_EMPLOYEE_NAME, json.getString("name"))
                putString(Config.BUNDLE_ARG_AUTH_EMPLOYEE_SURNAME, json.getString("surname"))
                putString(Config.BUNDLE_ARG_AUTH_DEVICE_NAME, json.getString("device"))
                putString(Config.BUNDLE_ARG_AUTH_DEVICE_IMEI, imei)
                putInt(Config.BUNDLE_ARG_AUTH_WORKING_TIME_START, json.getInt("start_time"))
                putInt(Config.BUNDLE_ARG_AUTH_WORKING_TIME_END, json.getInt("end_time"))
            }
            val intent = Intent().apply { putExtras(extras) }
            finishLogin(intent)
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    private fun onSignInError(error: VolleyError) {
        showProgress(false)

        if (error.networkResponse == null) {
            showSignInErrorDialog(
                    getString(R.string.signin),
                    getString(R.string.signin_error)
            )
            return
        }

        if (error.networkResponse.statusCode == 401) {
            val body = String(error.networkResponse.data)
            try {
                val jsonObject = JSONObject(body)
                when (val errorType = jsonObject.getString("error")) {
                    "working_time" -> {
                        val startTime = jsonObject.getString("start_time")
                        val endTime = jsonObject.getString("end_time")
                        showSignInErrorDialog(
                                getString(R.string.login_dialog_title_error_working_time),
                                getString(R.string.login_dialog_content_error_working_time, startTime, endTime)
                        )
                    }
                    "unsuccessful_authentication" -> {
                        binding.loginPassword.apply {
                            isErrorEnabled = true
                            setError(getString(R.string.login_error_incorrect_password))
                            editText?.requestFocus()
                        }
                    }
                    else -> {
                        showSignInErrorDialog(errorType, jsonObject.getString("error_description"))
                    }
                }
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        } else {
            showSignInErrorDialog(
                    title = "Status: " + error.networkResponse.statusCode,
                    message = "Message: " + error.networkResponse.toString()
            )
        }
    }

    private fun showSignInErrorDialog(title: String, message: String) {
        AlertDialog.Builder(binding.root.context, R.style.AppTheme_Dialog).apply {
            setTitle(title)
            setMessage(message)
        }.also {
            it.create().show()
        }
    }

    private fun emitSignInRequest(username: String, password: String, imei: String) {
        //lifecycleScope.launch {
        //    try {
        //        val response = network.login(username, password, imei)
        //        Log.d("SignInActivity", "response: $response")
        //        onSignInSuccess(username, imei, response.toString())
        //    } catch (e: Exception) {
        //        onSignInError(VolleyError(e))
        //    }
        //}

        DefaultBackendVolley.getInstance(this)
                .addToRequestQueue(object : StringRequest(
                        Method.POST,
                        LOGIN_URL,
                        Response.Listener { response ->  onSignInSuccess(username, imei, response) },
                        Response.ErrorListener { error ->  onSignInError(error) }
                ) {
                    override fun getBodyContentType(): String {
                        return "application/x-www-form-urlencoded"
                    }

                    @Throws(AuthFailureError::class)
                    override fun getParams(): Map<String, String> {
                        val params = HashMap<String, String>()
                        params["grant_type"] = "password"
                        params["username"] = username
                        params["password"] = password
                        params["client_id"] = imei
                        return params
                    }
                })
    }

    private fun finishLogin(intent: Intent) {
        val deviceImei = intent.getStringExtra(Config.BUNDLE_ARG_AUTH_DEVICE_IMEI)
        val deviceName = intent.getStringExtra(Config.BUNDLE_ARG_AUTH_DEVICE_NAME)
        val startTime = intent.getIntExtra(Config.BUNDLE_ARG_AUTH_WORKING_TIME_START, 0)
        val endTime = intent.getIntExtra(Config.BUNDLE_ARG_AUTH_WORKING_TIME_END, 0)

        val calendar = Calendar.getInstance()
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val now = ((calendar.timeInMillis - startOfDay.timeInMillis) / 1000L).toInt()

        val userData = Bundle().apply {
            putString(Config.BUNDLE_ARG_AUTH_DEVICE_IMEI, deviceImei)
            putString(Config.BUNDLE_ARG_AUTH_DEVICE_NAME, deviceName)
            putString(Config.BUNDLE_ARG_AUTH_WORKING_TIME_END, endTime.toString())
        }
        val accountName = intent.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
        val employeeName = intent.getStringExtra(Config.BUNDLE_ARG_AUTH_EMPLOYEE_NAME)
        val employeeLastname = intent.getStringExtra(Config.BUNDLE_ARG_AUTH_EMPLOYEE_SURNAME)
        val refreshToken = intent.getStringExtra(AccountManager.KEY_AUTHTOKEN)

        val signedInAccount = Account(accountName, BuildConfig.MCI_ACCOUNT_TYPE)
        val isAddAccountSuccess = accountManager.addAccountExplicitly(signedInAccount, null, userData)
        if (isAddAccountSuccess) {
            AccountUtils.setActiveAccount(this, accountName)
            AccountUtils.setEmployeeCode(this, accountName)
            AccountUtils.setEmployeeName(this, employeeName)
            AccountUtils.setEmployeeSurname(this, employeeLastname)
            AccountUtils.setDeviceName(this, deviceName)
            AccountUtils.setUserNotSignedIn(this, false)

            accountManager.setAuthToken(signedInAccount, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN, refreshToken)

            if (!ContentResolver.getSyncAutomatically(signedInAccount, OrderContract.CONTENT_AUTHORITY)) {
                val extras = Bundle().apply {
                    putBoolean(SyncAdapter.EXTRA_SYNC_BACKGROUND, true)
                }
                ContentResolver.addPeriodicSync(
                        signedInAccount,
                        OrderContract.CONTENT_AUTHORITY,
                        extras,
                        SYNC_INTERVAL,
                )
                ContentResolver.setSyncAutomatically(signedInAccount, OrderContract.CONTENT_AUTHORITY, true)
                Log.d("SignInActivity", "setSyncAutomatically")
            }

            val bundle = Bundle().apply {
                putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true)
                putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true)
                putBoolean(SyncAdapter.EXTRA_SYNC_ALL_DATA, true)
            }
            ContentResolver.requestSync(signedInAccount, OrderContract.CONTENT_AUTHORITY, bundle)
            val syncHelper = SyncHelper(this)
            syncHelper.performSync(null, signedInAccount, bundle)
            Log.d("SignInActivity", "requestSync")

            setResult(Activity.RESULT_OK)
        } else {
            /*
             * The account exists or some other error occurred. Log this, report it,
             * or handle it internally.
             */
            Log.e("SignInActivity", "Account exists or some other error occurred.")
            accountManager.removeAccountExplicitly(signedInAccount)
            setResult(Activity.RESULT_CANCELED)
        }

        finish()

        //val account = Account(accountName, BuildConfig.MCI_ACCOUNT_TYPE).also { newAccount ->
        //    if (accountManager.addAccountExplicitly(newAccount, null, userData)) {
        //        /*
        //         * If you don't set android:syncable="true" in
        //         * in your <provider> element in the manifest,
        //         * then call context.setIsSyncable(account, AUTHORITY, 1)
        //         * here.
        //         */
        //        val authToken = intent.getStringExtra(AccountManager.KEY_AUTHTOKEN)
        //        accountManager.setAuthToken(newAccount, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN, authToken)
        //        val periodicSettings = Bundle().apply {
        //            putBoolean(SyncAdapter.EXTRA_SYNC_BACKGROUND, true)
        //        }
        //        ContentResolver.addPeriodicSync(
        //                newAccount,
        //                OrderContract.CONTENT_AUTHORITY,
        //                periodicSettings,
        //                SYNC_INTERVAL)
        //        ContentResolver.setSyncAutomatically(newAccount, OrderContract.CONTENT_AUTHORITY, true)
        //
        //        val requestSettings = Bundle().apply {
        //            putBoolean(SyncAdapter.EXTRA_SYNC_ALL_DATA, true)
        //        }
        //        ContentResolver.requestSync(newAccount, OrderContract.CONTENT_AUTHORITY, requestSettings)
        //
        //        AccountUtils.setActiveAccount(this, accountName)
        //        AccountUtils.setEmployeeCode(this, accountName)
        //        AccountUtils.setEmployeeName(this, intent.getStringExtra(Config.BUNDLE_ARG_AUTH_EMPLOYEE_NAME))
        //        AccountUtils.setEmployeeSurname(this, intent.getStringExtra(Config.BUNDLE_ARG_AUTH_EMPLOYEE_SURNAME))
        //        AccountUtils.setDeviceName(this, deviceName)
        //        AccountUtils.setUserNotSignedIn(this, false)
        //
        //        setResult(Activity.RESULT_OK)
        //        finish()
        //    } else {
        //        /*
        //         * The account exists or some other error occurred. Log this, report it,
        //         * or handle it internally.
        //         */
        //        accountManager.removeAccountExplicitly(newAccount)
        //    }
        //}
    }

    companion object {

        private const val LOGIN_URL = "https://${BuildConfig.SERVER_HOST_NAME}/mci-core/v1/login"

        const val REQUEST_LOGIN = 1

        const val ARG_ACCOUNT_TYPE = "ACCOUNT_TYPE"
        const val ARG_AUTH_TYPE = "AUTH_TYPE"
        const val ARG_ACCOUNT_NAME = "ACCOUNT_NAME"
        const val ARG_IS_ADDING_NEW_ACCOUNT = "IS_ADDING_ACCOUNT"

        private val SYNC_INTERVAL = TimeUnit.MINUTES.toSeconds(3)

        fun starterIntent(context: Context): Intent {
            return Intent(context, SignInActivity::class.java)
        }
    }
}