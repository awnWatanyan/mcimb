package com.aeon.mci.ui.signin

import android.accounts.AccountManager
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class SignInViewModel @Inject constructor(
) : ViewModel() {

    private val _username = MutableLiveData<String>()
    val username: LiveData<String> = _username

    private val _password = MutableLiveData<String>()
    val password: LiveData<String> = _password

    private val _deviceId = MutableLiveData<String>()
    val deviceId: LiveData<String> = _deviceId

    private val _passwordVisibility = MutableLiveData<Boolean>()
    val passwordVisibility: LiveData<Boolean> = _passwordVisibility

    private val _isDeviceIdEnabled = MutableLiveData<Boolean>()
    val isDeviceIdEnabled: LiveData<Boolean> = _isDeviceIdEnabled

    private val _isUsernameValid = MutableLiveData<Boolean>()
    val isUsernameValid: LiveData<Boolean> = _isUsernameValid

    private val _isPasswordValid = MutableLiveData<Boolean>()
    val isPasswordValid: LiveData<Boolean> = _isPasswordValid

    private val _isDeviceIdValid = MutableLiveData<Boolean>()
    val isDeviceIdValid: LiveData<Boolean> = _isDeviceIdValid

    private val _signInUiState = MutableLiveData<SignInUiState>()
    val signInUiState: LiveData<SignInUiState> = _signInUiState

    init {
        _isUsernameValid.value = true
        _isPasswordValid.value = true
        _isDeviceIdValid.value = true
        _isDeviceIdEnabled.value = false // Default to disabled
    }

    fun onUsernameChanged(newUsername: String) {
        _username.value = newUsername
        _isUsernameValid.value = newUsername.isNotEmpty()
    }

    fun onPasswordChanged(newPassword: String) {
        _password.value = newPassword
        _isPasswordValid.value = newPassword.isNotEmpty()
    }

    fun onPasswordVisibilityChanged(isVisible: Boolean) {
        // Toggles the current boolean value for password visibility
        _passwordVisibility.value = isVisible
    }

    fun onDeviceIdChanged(newDeviceId: String) {
        _deviceId.value = newDeviceId
        _isDeviceIdValid.value = newDeviceId.isNotEmpty()
    }

    fun onDeviceIdEnabledChanged(isEnabled: Boolean) {
        _isDeviceIdEnabled.value = isEnabled
        if (!isEnabled) {
            _deviceId.value = ""
            _isDeviceIdValid.value = true
        }
    }

    fun onSignInClicked() {
        viewModelScope.launch {
            // Add your sign-in logic here, and update the UI state accordingly.
            // This could include validating credentials, communicating with a server, etc.

            // Example:
            if (validateCredentials(_username.value, _password.value, _deviceId.value)) {
                _signInUiState.value = SignInUiState.Success
            } else {
                _signInUiState.value = SignInUiState.Error("Invalid credentials")
            }
        }
    }

    private fun validateCredentials(username: String?, password: String?, deviceId: String?): Boolean {
        // Replace this with real validation logic
        return username == "user" && password == "password" && (deviceId?.isNotEmpty() ?: true)
    }

}

sealed interface SignInUiState {
    object Success: SignInUiState
    data class Error(val message: String): SignInUiState
}