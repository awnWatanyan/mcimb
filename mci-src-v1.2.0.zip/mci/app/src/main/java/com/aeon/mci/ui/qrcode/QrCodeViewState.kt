package com.aeon.mci.ui.qrcode

import java.math.BigDecimal

data class QrCodeViewState(
        val customerId: String,
        val agreementNo: String,
        val description: String,
        val amount: BigDecimal,
        val collectorId: String,
        val token: String
)