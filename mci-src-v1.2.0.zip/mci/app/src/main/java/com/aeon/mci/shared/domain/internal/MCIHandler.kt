package com.aeon.mci.shared.domain.internal

import android.os.Handler
import android.os.Looper

interface MCIHandler {
    fun post(runnable: Runnable): Boolean

    fun postDelayed(runnable: Runnable, millis: Long): Boolean

    fun removeCallbacks(runnable: Runnable)
}

class MCIMainHandler : MCIHandler {
    private val handler = Handler(Looper.getMainLooper())

    override fun post(runnable: Runnable) = handler.post(runnable)

    override fun postDelayed(runnable: Runnable, millis: Long) =
            handler.postDelayed(runnable, millis)

    override fun removeCallbacks(runnable: Runnable) = handler.removeCallbacks(runnable)
}