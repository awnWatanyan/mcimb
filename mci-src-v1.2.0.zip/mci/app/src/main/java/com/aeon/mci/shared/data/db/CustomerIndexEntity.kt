package com.aeon.mci.shared.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
        tableName = "customers_indices",
        indices = [Index(value = arrayOf("customers_indices_customer_id"), unique = true)]
)
data class CustomerIndexEntity(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "customers_indice_id")
        val customerIndexId: Int,

        @ColumnInfo(name = "customers_indices_customer_id")
        val idCardNo: String,

        @ColumnInfo(name = "customers_indices_no")
        val index: Int
)