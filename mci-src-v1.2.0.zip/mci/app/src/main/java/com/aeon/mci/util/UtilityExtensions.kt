package com.aeon.mci.util

import android.os.Build
import com.aeon.mci.BuildConfig

inline fun supportLollipop(func: () -> Unit) {
    supportVersion(Build.VERSION_CODES.LOLLIPOP, func)
}

inline fun supportVersion(version: Int, func: () -> Unit) {
    if (Build.VERSION.SDK_INT >= version) {
        func.invoke()
    }
}

inline fun inReleaseMode(func: () -> Unit) {
    if(BuildConfig.BUILD_TYPE.equals("release")) {
        func()
    }
}

inline fun inDebugMode(func: () -> Unit) {
    if (BuildConfig.BUILD_TYPE.equals("debug")) {
        func()
    }
}