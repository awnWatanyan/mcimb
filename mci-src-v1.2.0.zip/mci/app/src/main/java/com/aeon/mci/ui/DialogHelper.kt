package com.aeon.mci.ui

import android.app.Activity
import android.app.ProgressDialog
import androidx.appcompat.app.AlertDialog

class DialogHelper(private val mActivity: Activity?) {

    private var mProgressDialog: ProgressDialog? = null

    val isDialogIsShowing: Boolean
        get() = mProgressDialog?.isShowing ?: false

    fun showLoadingDialog(message: String?) {
        mActivity?.runOnUiThread {
            mProgressDialog = ProgressDialog.show(mActivity, "", message, true, false)
        }
    }

    fun updateLoadingDialog(message: String?) {
        mActivity?.runOnUiThread { mProgressDialog!!.setMessage(message) }
    }

    fun dismissLoadingDialog() {
        if (mActivity != null && mProgressDialog != null) {
            mActivity.runOnUiThread(Runnable { mProgressDialog!!.dismiss() })
        }
    }

    fun showErrorDialogOnUiThread(errorMessage: String?) {
        mActivity?.runOnUiThread {
            val dialog = AlertDialog.Builder(mActivity)
                    .setMessage(errorMessage)
                    .setPositiveButton("OK") { dialog, _ ->
                        dialog.dismiss()
                        dismissLoadingDialog()
                    }
            dialog.show()
//            AlertDialog.Builder(mActivity)
//                    .setMessage(errorMessage)
//                    .setPositiveButton("OK") { dialog: DialogInterface, which: Int ->
//                        dialog.dismiss()
//                        dismissLoadingDialog()
//                    }.show()
        }
    }

}