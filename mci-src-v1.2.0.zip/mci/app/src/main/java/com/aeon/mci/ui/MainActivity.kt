package com.aeon.mci.ui

import android.Manifest
import android.accounts.AccountManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import com.aeon.mci.BuildConfig
import com.aeon.mci.R
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.receiver.BluetoothPrinterReceiver
import com.aeon.mci.ui.customer.CustomerFragment
import com.aeon.mci.ui.settings.PrinterPreferenceFragment
import com.aeon.mci.ui.signin.SignInActivity
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.inReleaseMode
import com.aeon.mci.util.setBackgroundColor
import com.aeon.mci.util.setStatusBarColor
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    companion object {
        private const val UNDONE_CUSTOMER_TAG = "undone_customer"
        private const val DONE_CUSTOMER_TAG = "done_customer"
        private const val KEY_LAST_ORIENTATION = "last_orientation"
    }

    @Inject
    lateinit var accountManager: AccountManager

    private lateinit var content: FrameLayout
    private lateinit var navigation: BottomNavigationView

    private var lastOrientation = 0

    private val isMobileDataEnabled: Boolean
        get() {
            return Settings.Global.getInt(contentResolver, "mobile_data", 1) == 1
        }

    private val loginResultLauncher =
        registerForActivityResult(StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                // Set action bar subtitle
                supportActionBar?.apply {
                    val empName = AccountUtils.getEmployeeName(this@MainActivity)
                    val empSurname = AccountUtils.getEmployeeSurname(this@MainActivity)
                    val empCode = AccountUtils.getEmployeeCode(this@MainActivity)
                    subtitle = "$empName $empSurname ($empCode)"
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        //val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inReleaseMode {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        handleSavedInstanceState(savedInstanceState)
        setupToolbar()
        setupContentFrame()
        setupNavigation()
    }

    private fun setupToolbar() {
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        toolbar.run {
            background = ColorDrawable(ContextCompat.getColor(context, R.color.assign))
            setStatusBarColor(R.color.assign_dark)
            setSupportActionBar(this)
        }
    }

    private fun setupContentFrame() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.content_base_frame, CustomerFragment.newInstance(true))
            .commit()

        content = findViewById(R.id.content_base_frame)
    }

    private fun setupNavigation() {
        navigation = findViewById(R.id.bottom_navigation)
        setupOnItemSelectedListener()
    }

    private fun setupOnItemSelectedListener() {
        navigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.action_new -> {
                    changeActionBarAndStatusBarColors(R.color.assign, R.color.assign_dark)
                    //replaceFragment(AssignedWorkOrderFragment.newInstance())
                    replaceFragment(CustomerFragment.newInstance(true), UNDONE_CUSTOMER_TAG)
                    true
                }
                R.id.action_done -> {
                    changeActionBarAndStatusBarColors(R.color.complete, R.color.complete_dark)
                    replaceFragment(CustomerFragment.newInstance(false), DONE_CUSTOMER_TAG)
                    true
                }
                R.id.action_settings -> {
                    changeActionBarAndStatusBarColors(R.color.brown, R.color.brown_dark)
                    replaceFragment(PrinterPreferenceFragment.newInstance())
                    true
                }
                R.id.action_logout -> {
                    displayLogoutDialog()
                    false
                }
                else -> false
            }
        }
    }

    private fun changeActionBarColor(colorResId: Int) {
        supportActionBar?.setBackgroundColor(colorResId)
    }

    private fun changeStatusBarColor(colorResId: Int) {
        setStatusBarColor(colorResId)
    }

    private fun changeActionBarAndStatusBarColors(actionBarColor: Int, statusBarColor: Int) {
        changeActionBarColor(actionBarColor)
        changeStatusBarColor(statusBarColor)
    }

    private fun replaceFragment(fragment: Fragment, tag: String? = null) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.content_base_frame, fragment, tag)
            .commit()
    }

    private fun handleSavedInstanceState(savedInstanceState: Bundle?) {
        if (savedInstanceState != null) {
            lastOrientation = resources.configuration.orientation
        }
    }

    override fun onStart() {
        super.onStart()

        enableBluetoothPairingRequest()
        checkOrientationChange()
    }

    private fun enableBluetoothPairingRequest() {
        val receiver = ComponentName(this, BluetoothPrinterReceiver::class.java)
        packageManager.setComponentEnabledSetting(receiver,
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP)
    }

    private fun checkOrientationChange() {
        val currentOrientation = resources.configuration.orientation
        if (currentOrientation != lastOrientation) {
            lastOrientation = currentOrientation
        }
    }

    override fun onResume() {
        super.onResume()

        checkUserLogin()
        enableAutoSync()
        enableBluetooth()
        checkMobileDataAvailability()
        clearOldData()
    }

    private fun checkUserLogin() {
        val accounts = accountManager.getAccountsByType(BuildConfig.MCI_ACCOUNT_TYPE)
        if (accounts.isEmpty()) {
            displayLoginActivity()
        }
    }

    private fun enableAutoSync() {
        if (!ContentResolver.getMasterSyncAutomatically()) {
            ContentResolver.setMasterSyncAutomatically(true)
        }
    }

    private fun enableBluetooth() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            return
        }

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter = bluetoothManager.adapter
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBtIntent)
        }
    }

    private fun checkMobileDataAvailability() {
        if (!isMobileDataEnabled) {
            Snackbar.make(content, R.string.base_no_connection, Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        lastOrientation = savedInstanceState.getInt(KEY_LAST_ORIENTATION)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_LAST_ORIENTATION, lastOrientation)
    }

    private fun clearOldData() {
        val deleteJobsCount = deleteOrdersData()
        val deleteCustomersCount = deleteCustomersData()
        val deleteReceiptsCount = deleteReceiptsData()
        val deleteLocationsCount = deleteLocationsData()

        sendNotification(deleteJobsCount, "Delete orders data: ")
        sendNotification(deleteCustomersCount, "Delete customers data: ")
        sendNotification(deleteReceiptsCount, "Delete receipts data: ")
        sendNotification(deleteLocationsCount, "Delete locations data: ")
    }

    private fun deleteOrdersData(): Int {
        return contentResolver.delete(
            OrderContract.Orders.CONTENT_URI,
            OrderContract.Orders.ORDER_OLD_RECORD_SELECTION,
            null
        )
    }

    private fun deleteCustomersData(): Int {
        return contentResolver.delete(
            OrderContract.Customers.CONTENT_URI,
            OrderContract.Customers.CUSTOMER_OLD_RECORD_SELECTION,
            null
        )
    }

    private fun deleteReceiptsData(): Int {
        return contentResolver.delete(
            OrderContract.Receipts.CONTENT_URI,
            OrderContract.Receipts.RECEIPT_OLD_RECORD_SELECTION,
            null
        )
    }

    private fun deleteLocationsData(): Int {
        return contentResolver.delete(
            OrderContract.Locations.CONTENT_URI,
            OrderContract.Locations.LOCATION_OLD_RECORD_SELECTION,
            null
        )
    }

    private fun sendNotification(count: Int, message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            return
        }

        if (count > 0) {
            val nmc = NotificationManagerCompat.from(this)
            val notifyID = 1
            val notification = NotificationCompat.Builder(this, "mci")
                .setContentTitle("MCI Delete Old Records Information")
                .setSmallIcon(R.drawable.ic_notification_motorcycle)
                .setContentText(message + count)
            //.setNumber(++notificationCount)
            nmc.notify(notifyID, notification.build())
        }
    }

    private fun displayLoginActivity() {
        navigation.selectedItemId = R.id.action_new

        val intent = SignInActivity.starterIntent(this)
        loginResultLauncher.launch(intent)
    }

    private fun displayLogoutDialog() {
        val dialog = AlertDialog.Builder(this).run {
            setTheme(R.style.AppTheme_AlertDialog)
            setMessage(R.string.navigation_logout_message)
            setCancelable(false)
            setNegativeButton(R.string.navigation_logout_no, null)
            setPositiveButton(R.string.navigation_logout_yes) { _, _ ->
                finishLogout()
            }
            show()
        }
        dialog.apply {
            val messageView: TextView? = findViewById(android.R.id.message)
            messageView?.run {
                val font = ResourcesCompat.getFont(applicationContext, R.font.sarabun)
                typeface = font
                includeFontPadding = false
                textSize = 16f
                setTextColor(ContextCompat.getColor(context, R.color.gray700))
                setPadding(24, 8, 24, 8)
            }
        }
    }

    private fun finishLogout() {
        val account = AccountUtils.getActiveAccount(applicationContext)
        if (accountManager.removeAccountExplicitly(account)) {
            cleanActiveAccount()
            displayLoginActivity()
        }
    }

    private fun cleanActiveAccount() {
        AccountUtils.setUserNotSignedIn(this, true)
        AccountUtils.clearActiveAccount(this)
        AccountUtils.clearAccountInfo(this)
    }
}
