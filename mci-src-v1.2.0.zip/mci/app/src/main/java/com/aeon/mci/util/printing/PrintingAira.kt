package com.aeon.mci.util.printing

import com.aeon.mci.util.dateFormat
import com.aeon.mci.util.timeFormat
import java.util.*

object PrintingAira {

    /*
     * The horizontal offset for the entire label.
     * This value causes all fields to be offset horizontally by the specified number of UNITS.
     */
    private const val OFFSET = 0

    /*
     * The maximum height of the label.
     */
    private const val HEIGHT = 1650

    /*
     * Contrast level.
     * 0 = Default
     * 1 = Medium
     * 2 = Dark
     * 3 = Very Dark
     */
    private const val CONTRAST = 1

    /*
     * The COUNTRY control command substitutes
     * the appropriate character set for the specified country.
     */
    private const val COUNTRY = "CP874"

    private const val FONT_NAME = "ANGSANA.FNT"

    /*
     * Font width (point size).
     */
    private const val FONT_WIDTH = 10

    fun createLetterContent(
            collectorName: String,
            customerName: String,
            clientName: String,
            contactNo: String
    ): String {
        val sb = StringBuilder()
        sb.run {
            val th = Locale.Builder()
                    .setLanguage("th")
                    .setRegion("th")
                    .build()
            var line = 0
            val now = Date()
            val date = dateFormat().format(now)
            val time = timeFormat().format(now)

            val pageWidth = 280
            val centerPosition = (pageWidth - collectorName.graphemeLength())/2

            append(String.format("! $OFFSET 200 200 $HEIGHT 1%n"))
            append(String.format("JOURNAL%n"))
            append(String.format("CONTRAST $CONTRAST%n"))
            append(String.format("COUNTRY $COUNTRY%n"))

            append(String.format(th, "ST ANGSANA.FNT 10 12 0 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line))
            line += 35
            append(String.format(th, "T TAH06PT.CPF 0 0 %d ACS Servicing (Thailand) Company Limited %n", line))
            line += 20
            append(String.format(th, "ST ANGSANA.FNT 6 6 0 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 11 ถนนศรีนครินทร์ แขวงพัฒนาการ เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line))
            line += 16
            append(String.format(th, "ST ANGSANA.FNT 6 6 0 %d 699 Modernform Tower, 11%n", line))
            append(String.format(th, "ST ANGSANA.FNT 5 5 120 %d th%n", line - 3))
            append(String.format(th, "ST ANGSANA.FNT 6 6 130 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line))
            line += 16
            append(String.format(th, "ST ANGSANA.FNT 6 6 0 %d ทะเบียนเลขที่ 0105550028122%n", line))
            line += 60

            append(String.format(th, "ST ANGSANA.FNT 12 12 410 %d วันที่ %s%n", line, date))
            line += 48

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "เรื่อง    ขอให้ชำระหนี้ค้างชำระ%n"))
            append(String.format(th, "เรียน    คุณ %s%n", customerName))
            append(String.format("ENDML%n"))
            line += 96

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "            ตามที่ท่านมีหนี้ค้างชำระอยู่กับ%n"))
            append(String.format("ENDML%n"))
            line += 48
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d %s%n", line, clientName))
            line += 48
            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "ความดังแจ้งแล้วนั้น%n"))
            append(String.format("ENDML%n"))
            line += 48

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "            บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n"))
            append(String.format(th, "(\"บริษัทฯ\") ขอเรียนให้ท่านทราบว่าบริษัทฯ ได้รับมอบหมาย%n"))
            append(String.format(th, "ให้ดำเนินการติดต่อประสานงานกับท่านเกี่ยวกับการชำระหนี้%n"))
            append(String.format(th, "ดังกล่าวโดยบริษัทฯ ได้มอบหมายให้%n"))
            append(String.format("ENDML%n"))
            line += 188

            append(String.format(th, "ST ANGSANA.FNT 13 13 %d %d คุณ %s%n", centerPosition, line, collectorName))
            line += 48

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "ซึ่งเป็นพนักงานของบริษัทฯ ไปพบท่านในวันที่ %s%n", date))
            append(String.format(th, "เวลา %s น. เพื่อชี้แจงรายละเอียดการชำระหนี้ของท่านแต่%n", time))
            append(String.format(th, "ไม่พบท่านในวันและเวลาดังกล่าว%n"))
            append(String.format("ENDML%n"))
            line += 144

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "            ดังนั้น โดยหนังสือฉบับนี้ บริษัทฯ ขอให้ท่านชำระ%n"))
            append(String.format(th, "หนี้ค้างชำระที่ท่านมีอยู่กับ%n"))
            append(String.format("ENDML%n"))
            line += 96

            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d %s%n", line, clientName))
            line += 48

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "จนครบถ้วนเพื่อให้ภาระหนี้ของท่านระงับสิ้นไป%n"))
            append(String.format("ENDML%n"))
            line += 48

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "            จึงเรียนมาเพื่อโปรดดำเนินการ%n"))
            append(String.format("ENDML%n"))
            line += 48

            append(String.format("%n"))
            line += 16

            append(String.format(th, "ST ANGSANA.FNT 13 13 250 %d ขอแสดงความนับถือ%n", line))
            line += 48

            append(String.format(th, "ST ANGSANA.FNT 13 13 120 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line))
            line += 48

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "หมายเหตุ : หากมีข้อสงสัยประการใด กรุณาติดต่อที่หมายเลข%n"))
            append(String.format(th, "โทรศัพท์ %s%n", if (contactNo.isEmpty()) "" else contactNo))
            append(String.format(th, "ระหว่างวันจันทร์ถึงวันศุกร์เวลา 8:30 - 17:30 น.%n"))
            append(String.format("ENDML%n"))
            line += 144

            append(String.format("%n"))
            line += 16

            append(String.format("ML 47%n"))
            append(String.format(th, "ST ANGSANA.FNT 13 13 0 %d%n", line))
            append(String.format(th, "            บริษัทฯ ต้องขออภัยเป็นอย่างยิ่ง หากท่านได้ชำระเงิน%n"))
            append(String.format(th, "จำนวนดังกล่าวแล้ว ก่อนได้รับหนังสือฉบับนี้%n"))
            append(String.format("ENDML%n"))

            append(String.format("PRINT%n"))
        }
        return sb.toString()
    }

}