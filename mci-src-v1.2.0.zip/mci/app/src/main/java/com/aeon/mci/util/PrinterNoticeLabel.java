package com.aeon.mci.util;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;

import com.aeon.mci.Config;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PrinterNoticeLabel {

    private static final String TAG = PrinterNoticeLabel.class.getSimpleName();

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForAeon(Bundle data) {
        String collectorName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String customerNameTh = !TextUtils.isEmpty(customerName) ? customerName.split("/", -1)[0] : "";

        Date printDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.US);

        int pageWidth = 280;
        int collectorNameCenterPosition = (pageWidth - collectorName.length())/2;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("! 0 200 200 1600 1%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("CONTRAST 1%n"));
        sb.append(String.format("PCX 0 20 !<AEON017.PCX%n"));
        sb.append(String.format("COUNTRY CP874%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 100 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 100 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 11 ถนนศรีนครินทร์ แขวงพัฒนาการ เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 Modernform Tower, 11%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 4 5 195 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 200 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 410 %d วันที่ %s%n", line, dateFormat.format(printDate)));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "เรื่อง    ขอให้ชำระหนี้ค้างชำระ%n"));
        sb.append(String.format(locale, "เรียน    คุณ %s%n", customerNameTh));
        sb.append(String.format("ENDML%n"));
        line += 96;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            ตามที่ท่านมีหนี้ค้างชำระอยู่กับบริษัท อิออน ธนสิน-%n"));
        sb.append(String.format(locale, "ทรัพย์ (ไทยแลนด์) จำกัด (มหาชน) ความดังแจ้งแล้วนั้น%n"));
        sb.append(String.format("ENDML%n"));
        line += 96;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n"));
        sb.append(String.format(locale, "(\"บริษัทฯ\") ขอเรียนให้ท่านทราบว่าบริษัทฯ ได้รับมอบหมาย%n"));
        sb.append(String.format(locale, "ให้ดำเนินการติดต่อประสานงานกับท่านเกี่ยวกับการชำระหนี้%n"));
        sb.append(String.format(locale, "ดังกล่าวโดยบริษัทฯ ได้มอบหมายให้%n"));
        sb.append(String.format("ENDML%n"));
        line += 188;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 %d %d คุณ %s%n", collectorNameCenterPosition, line, collectorName));
        line += 48;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "ซึ่งเป็นพนักงานของบริษัทฯ ไปพบท่านในวันที่ %s%n", dateFormat.format(printDate)));
        sb.append(String.format(locale, "เวลา %s น. เพื่อชี้แจงรายละเอียดการชำระหนี้ของท่านแต่%n", timeFormat.format(printDate)));
        sb.append(String.format(locale, "ไม่พบท่านในวันและเวลาดังกล่าว%n"));
        sb.append(String.format("ENDML%n"));
        line += 144;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            ดังนั้น โดยหนังสือฉบับนี้ บริษัทฯ ขอให้ท่านชำระ%n"));
        sb.append(String.format(locale, "หนี้ค้างชำระที่ท่านมีอยู่กับบริษัท อิออน ธนสินทรัพย์ (ไทย-%n"));
        sb.append(String.format(locale, "แลนด์) จำกัด (มหาชน) จนครบถ้วนเพื่อให้ภาระหนี้ของท่าน%n"));
        sb.append(String.format(locale, "ระงับสิ้นไป%n"));
        sb.append(String.format("ENDML%n"));
        line += 188;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            จึงเรียนมาเพื่อโปรดดำเนินการ%n"));
        sb.append(String.format("ENDML%n"));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 250 %d ขอแสดงความนับถือ%n", line));
        line += 48;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 120 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "หมายเหตุ : หากมีข้อสงสัยประการใด กรุณาติดต่อที่หมายเลข%n"));
        sb.append(String.format(locale, "โทรศัพท์ 02-769-1777%n"));
        sb.append(String.format(locale, "ระหว่างวันจันทร์ถึงวันศุกร์เวลา 9:00 - 18:00 น.%n"));
        sb.append(String.format("ENDML%n"));
        line += 144;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            บริษัทฯ ต้องขออภัยเป็นอย่างยิ่ง หากท่านได้ชำระเงิน%n"));
        sb.append(String.format(locale, "จำนวนดังกล่าวแล้ว ก่อนได้รับหนังสือฉบับนี้%n"));
        sb.append(String.format("ENDML%n"));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForOtherClient(Bundle data) {
        String collectorName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String customerNameTh = !TextUtils.isEmpty(customerName) ? customerName.split("/", -1)[0] : "";
        String clientNameTh = data.getString(Config.EXTRAS_CLIENT_NAME_TH);
        String clientContactNo = data.getString(Config.EXTRAS_CLIENT_CONTACT_NO);
//        Log.d(TAG, "Client name calculation: size=" + clientNameTh.length());
        if (TextUtils.isEmpty(clientNameTh) || TextUtils.equals(clientNameTh.toLowerCase(), "null")) {
            clientNameTh = "-";
        }

        Date printDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.US);

        int pageWidth = 280;
        int collectorNameCenterPosition = (pageWidth - collectorName.length())/2;
        int clientNameCenterPosition = (pageWidth - clientNameTh.length())/2;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("! 0 200 200 1650 1%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("CONTRAST 1%n"));
        sb.append(String.format("COUNTRY CP874%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 0 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 0 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 11 ถนนศรีนครินทร์ แขวงพัฒนาการ เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d 699 Modernform Tower, 11%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 5 120 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 130 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 410 %d วันที่ %s%n", line, dateFormat.format(printDate)));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "เรื่อง    ขอให้ชำระหนี้ค้างชำระ%n"));
        sb.append(String.format(locale, "เรียน    คุณ %s%n", customerNameTh));
        sb.append(String.format("ENDML%n"));
        line += 96;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            ตามที่ท่านมีหนี้ค้างชำระอยู่กับ%n"));
        sb.append(String.format("ENDML%n"));
        line += 48;
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d %s%n", line, clientNameTh));
        line += 48;
        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "ความดังแจ้งแล้วนั้น%n"));
        sb.append(String.format("ENDML%n"));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n"));
        sb.append(String.format(locale, "(\"บริษัทฯ\") ขอเรียนให้ท่านทราบว่าบริษัทฯ ได้รับมอบหมาย%n"));
        sb.append(String.format(locale, "ให้ดำเนินการติดต่อประสานงานกับท่านเกี่ยวกับการชำระหนี้%n"));
        sb.append(String.format(locale, "ดังกล่าวโดยบริษัทฯ ได้มอบหมายให้%n"));
        sb.append(String.format("ENDML%n"));
        line += 188;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 %d %d คุณ %s%n", collectorNameCenterPosition, line, collectorName));
        line += 48;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "ซึ่งเป็นพนักงานของบริษัทฯ ไปพบท่านในวันที่ %s%n", dateFormat.format(printDate)));
        sb.append(String.format(locale, "เวลา %s น. เพื่อชี้แจงรายละเอียดการชำระหนี้ของท่านแต่%n", timeFormat.format(printDate)));
        sb.append(String.format(locale, "ไม่พบท่านในวันและเวลาดังกล่าว%n"));
        sb.append(String.format("ENDML%n"));
        line += 144;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            ดังนั้น โดยหนังสือฉบับนี้ บริษัทฯ ขอให้ท่านชำระ%n"));
        sb.append(String.format(locale, "หนี้ค้างชำระที่ท่านมีอยู่กับ%n"));
        sb.append(String.format("ENDML%n"));
        line += 96;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d %s%n", line, clientNameTh));
        line += 48;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "จนครบถ้วนเพื่อให้ภาระหนี้ของท่านระงับสิ้นไป%n"));
        sb.append(String.format("ENDML%n"));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            จึงเรียนมาเพื่อโปรดดำเนินการ%n"));
        sb.append(String.format("ENDML%n"));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 250 %d ขอแสดงความนับถือ%n", line));
        line += 48;

        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 120 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 48;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "หมายเหตุ : หากมีข้อสงสัยประการใด กรุณาติดต่อที่หมายเลข%n"));
        sb.append(String.format(locale, "โทรศัพท์ 02-769-1700%s %n", TextUtils.isEmpty(clientContactNo) ? "" : ", " + clientContactNo));
        sb.append(String.format(locale, "ระหว่างวันจันทร์ถึงวันศุกร์เวลา 9:00 - 18:00 น.%n"));
        sb.append(String.format("ENDML%n"));
        line += 144;

        sb.append(String.format("%n"));
        line += 16;

        sb.append(String.format("ML 47%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 13 13 0 %d%n", line));
        sb.append(String.format(locale, "            บริษัทฯ ต้องขออภัยเป็นอย่างยิ่ง หากท่านได้ชำระเงิน%n"));
        sb.append(String.format(locale, "จำนวนดังกล่าวแล้ว ก่อนได้รับหนังสือฉบับนี้%n"));
        sb.append(String.format("ENDML%n"));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }
}
