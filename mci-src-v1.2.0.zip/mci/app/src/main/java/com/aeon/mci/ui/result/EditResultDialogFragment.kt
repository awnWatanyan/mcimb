package com.aeon.mci.ui.result

import android.accounts.AccountManager
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Looper
import android.provider.BaseColumns
import android.text.InputFilter
import android.text.TextUtils
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.appcompat.widget.AppCompatAutoCompleteTextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.aeon.mci.BuildConfig
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.databinding.FragmentEditResultBinding
import com.aeon.mci.model.CollectorResult
import com.aeon.mci.model.Order
import com.aeon.mci.model.Result
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.provider.OrderContract.CollectorResults
import com.aeon.mci.receiver.BluetoothPrinterReceiver
import com.aeon.mci.syncadapter.BackendVolley
import com.aeon.mci.ui.DialogHelper
import com.aeon.mci.ui.qrcode.QRCodeDialogFragment
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.LocationUtils
import com.aeon.mci.util.Sleeper
import com.aeon.mci.util.SpecialCharacterInputFilter
import com.aeon.mci.util.WhitespaceInputFilter
import com.aeon.mci.util.applyTitleStyle
import com.aeon.mci.util.dateFormat
import com.aeon.mci.util.decimalFormatWithCommas
import com.aeon.mci.util.decimalFormatWithoutCommas
import com.aeon.mci.util.enableResetErrorAfterTyped
import com.aeon.mci.util.hideSoftInput
import com.aeon.mci.util.hideSoftInputOnFocus
import com.aeon.mci.util.resetError
import com.aeon.mci.util.setError
import com.aeon.mci.util.showSoftInput
import com.aeon.mci.util.timeFormat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.zebra.sdk.comm.BluetoothConnectionInsecure
import com.zebra.sdk.comm.Connection
import com.zebra.sdk.comm.ConnectionException
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import timber.log.Timber
import java.text.DecimalFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

@AndroidEntryPoint
class EditResultDialogFragment : DialogFragment(), LocationUtils.OnLocationUpdateListener {

    private var mCollectorResult: CollectorResult? = null
    private var mOrder: Order? = null
    private var mIsMultipleSelected: Boolean = false
    private var mIncompleteTask: Boolean = false
    private var mConnected = false
    private var mLocationUtils: LocationUtils? = null
    private var mLocation: Location? = null
    private var mPrinterConnection: Connection? = null
    private var mBluetoothPrinterReceiver: BluetoothPrinterReceiver? = null
    private var mSelectedOrders: ArrayList<Order>? = null
    private var mHelper: DialogHelper? = null
    private var mListener: EditResultDialogListener? = null

    private var isEdit = false
    private var selectedCollectorResultItemPosition: Int = -1
    private var selectedCollectorResult: CollectorResult? = null
    private var selectedBankItemPosition: Int = -1
    private var selectedBank: String = ""

    private val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { ifilter ->
        context?.registerReceiver(null, ifilter)
    }

    val batteryPct: Float? = batteryStatus?.let { intent ->
        val level: Int = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale: Int = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        level * 100 / scale.toFloat()
    }

    // Error checking that probably isn't needed but I added just in case.
    private val batteryLevel: Int
        get() {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryIntent = requireActivity().applicationContext.registerReceiver(null, intentFilter)
            val level = batteryIntent!!.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level == -1 || scale == -1) {
                return 50
            }

            val batteryPct = (level / scale.toFloat()) * 100
            return batteryPct.roundToInt()
        }

    private lateinit var binding: FragmentEditResultBinding

    fun setEditResultDialogListener(listener: EditResultDialogListener) {
        mListener = listener
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true

        requireNotNull(arguments).apply {
            mIncompleteTask = getBoolean(Config.EXTRAS_INCOMPLETE_TASK)
            if (!mIncompleteTask) {
                mCollectorResult = getParcelable(Config.EXTRAS_COLLECTOR_RESULT)
                selectedCollectorResult = getParcelable(Config.EXTRAS_COLLECTOR_RESULT)
            }
            mSelectedOrders = getParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS)
            requireNotNull(mSelectedOrders).apply {
                if (size > 1) mIsMultipleSelected = true
                mOrder = this[0]
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentEditResultBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (mIsMultipleSelected) {
            binding.collectedAmountContainer.visibility = View.GONE
        }

        // Set up collector result spinner items
//        binding.collectorResults.run {
//            val selection = if (mIsMultipleSelected) {
//                CollectorResults.COLLECTOR_RESULT_IS_USED_EXCLUDE_GET_MONEY_SELECTION
//            } else {
//                CollectorResults.COLLECTOR_RESULT_IS_USED_SELECTION
//            }
//
//            val cursor = context.applicationContext.contentResolver.query(
//                    CollectorResults.CONTENT_URI,
//                    CollectorResultQuery.NORMAL_PROJECTION,
//                    selection,
//                    null,
//                    CollectorResults.COLLECTOR_RESULT_ORDER_BY_GROUPING_ORDER)
//
//            val adapter = ArrayAdapter<CollectorResult>(context, R.layout.spinner_item)
//            adapter.add(CollectorResult.createPromptItem(context))
//            cursor?.let {
//                while (it.moveToNext()) {
//                    val collectorResultItem = CollectorResult.fromCursorRow(it)
//                    if (mIsMultipleSelected) {
//                        adapter.add(collectorResultItem)
//                    } else {
//                        val isGetMoney = collectorResultItem.money == 0
//                        val isNoReceipt = collectorResultItem.receipt == 1
//                        val isQrCode = isGetMoney && isNoReceipt
//                        if (isQrCode) {
//                            val sourceRegion = mOrder!!.guid.slice(IntRange(0, 1))
//                            if (sourceRegion in AEON_SOURCE_REGION)
//                                adapter.add(collectorResultItem)
//                        } else {
//                            adapter.add(collectorResultItem)
//                        }
//                    }
//                }
//            }
//            cursor?.close()
//            this.adapter = adapter
//        }

        //val spinner: Spinner = view.findViewById(R.id.form_spinner_collection_result)

        // Create an array with the data you want to show in the dropdown list
        //val items = arrayOf("Option1", "Option2", "Option3", "Option4", "Option5")

        // Create an ArrayAdapter with the array
        //val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, items)

        // Specify the layout to use when the list of choices appears
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Apply the adapter to the spinner
        //spinner.adapter = adapter

        //setupCollectionResultSpinner()

        //val collectorResultAutoCompleteTextView = binding.collectorResult.editText as? AutoCompleteTextView
        //val collectorResultAutoCompleteTextView = binding.collectorResult.editText as? AppCompatAutoCompleteTextView
        val collectorResultAutoCompleteTextView = binding.collectorResult.editText as? MaterialAutoCompleteTextView
        collectorResultAutoCompleteTextView?.run {
            val selection = if (mIsMultipleSelected) {
                CollectorResults.COLLECTOR_RESULT_IS_USED_EXCLUDE_GET_MONEY_SELECTION
            } else {
                CollectorResults.COLLECTOR_RESULT_IS_USED_SELECTION
            }

            val cursor = context.applicationContext.contentResolver.query(
                    CollectorResults.CONTENT_URI,
                    CollectorResultQuery.NORMAL_PROJECTION,
                    selection,
                    null,
                    CollectorResults.COLLECTOR_RESULT_ORDER_BY_GROUPING_ORDER)

            val adapter = ArrayAdapter<CollectorResult>(context, R.layout.item_dropdown)
            cursor?.let {
                while (it.moveToNext()) {
                    val collectorResultItem = CollectorResult.fromCursorRow(it)
                    if (mIsMultipleSelected) {
                        adapter.add(collectorResultItem)
                    } else {
                        val isGetMoney = collectorResultItem.money == 0
                        val isNoReceipt = collectorResultItem.receipt == 1
                        val isQrCode = isGetMoney && isNoReceipt
                        if (isQrCode) {
                            val sourceRegion = mOrder!!.guid.slice(IntRange(0, 1))
                            if (sourceRegion in AEON_SOURCE_REGION)
                                adapter.add(collectorResultItem)
                        } else {
                            adapter.add(collectorResultItem)
                        }
                    }
                }
            }
            cursor?.close()
            setAdapter(adapter)

            hideSoftInputOnFocus()

            onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
                // Reset error.
                resetErrorInputFields()

                selectedCollectorResultItemPosition = position
                val collectorResult = parent.getItemAtPosition(position) as CollectorResult
                selectedCollectorResult = collectorResult
                mCollectorResult = collectorResult
                val isGetMoney = collectorResult.money == 0
                if (isGetMoney) {
                    setEnableGetMoneyInputs(true)

                    val isQrCode = collectorResult.receipt == 1
                    if (isQrCode) {
                        setEnableQrCode(true)
                    } else {
                        setEnableQrCode(false)
                        requestFullPanAgreement()
                    }

                    val isForceInputCollectAmount = collectorResult.min == collectorResult.max
                    if (isForceInputCollectAmount) {
                        when (collectorResult.min) {
                            2 -> {
                                setDisablePresetCollectedAmount()
                                binding.radioMinimumBill.run {
                                    isEnabled = true
                                    isChecked = true
                                }
                            } // Minimum bill
                            3 -> {
                                setDisablePresetCollectedAmount()
                                binding.radioFullBill.run {
                                    isEnabled = true
                                    isChecked = true
                                }
                            } // Full bill
                            4 -> {
                                setDisablePresetCollectedAmount()
                                binding.radioCurrentBill.run {
                                    isEnabled = true
                                    isChecked = true
                                }
                            } // Current bill
                        }
                    }
                } else {
                    setEnableGetMoneyInputs(false)
                    setEnableQrCode(false)
                }

                val isLoop = collectorResult.type == 0
                if (isLoop) {
                    setEnableNextAppointmentInputs(true)
                } else {
                    setEnableNextAppointmentInputs(false)
                }
            }
        }

//        binding.collectorResults.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//            override fun onNothingSelected(parent: AdapterView<*>) {
//                // No operation
//            }
//
//            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
//                // Reset error.
//                resetErrorInputFields()
//
//                if (position == 0) {
//                    setEnableGetMoneyInputs(false)
//                    setEnableQrCode(false)
//                    setEnableNextAppointmentInputs(false)
//                    return
//                }
//
//                val collectorResult = parent.getItemAtPosition(position) as CollectorResult
//                mCollectorResult = collectorResult
//                val isGetMoney = collectorResult.money == 0
//                if (isGetMoney) {
//                    setEnableGetMoneyInputs(true)
//
//                    val isQrCode = collectorResult.receipt == 1
//                    if (isQrCode) {
//                        setEnableQrCode(true)
//                    } else {
//                        setEnableQrCode(false)
//                        requestFullPanAgreement()
//                    }
//
//                    val isForceInputCollectAmount = collectorResult.min == collectorResult.max
//                    if (isForceInputCollectAmount) {
//                        when (collectorResult.min) {
//                            2 -> {
//                                setDisablePresetCollectedAmount()
//                                binding.radioMinimumBill.run {
//                                    isEnabled = true
//                                    isChecked = true
//                                }
//                            } // Minimum bill
//                            3 -> {
//                                setDisablePresetCollectedAmount()
//                                binding.radioFullBill.run {
//                                    isEnabled = true
//                                    isChecked = true
//                                }
//                            } // Full bill
//                            4 -> {
//                                setDisablePresetCollectedAmount()
//                                binding.radioCurrentBill.run {
//                                    isEnabled = true
//                                    isChecked = true
//                                }
//                            } // Current bill
//                        }
//                    }
//                } else {
//                    setEnableGetMoneyInputs(false)
//                    setEnableQrCode(false)
//                }
//
//                val isLoop = collectorResult.type == 0
//                if (isLoop) {
//                    setEnableNextAppointmentInputs(true)
//                } else {
//                    setEnableNextAppointmentInputs(false)
//                }
//            }
//        }

        val mobileBankingAutoCompleteTextView = binding.mobileBanking.editText as? AutoCompleteTextView
        mobileBankingAutoCompleteTextView?.run {
            val adapter = ArrayAdapter.createFromResource(context, R.array.mobile_banking_app, R.layout.item_dropdown)
            setAdapter(adapter)

            hideSoftInputOnFocus()

            onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
                binding.mobileBanking.resetError()
                selectedBankItemPosition = position
                selectedBank = parent.getItemAtPosition(position) as String
                val isOtherMobileBanking = position == parent.count - 1
                setEnableOtherMobileBankingAppInput(isOtherMobileBanking)
            }
        }

        val decimalFormat = decimalFormatWithCommas()
        val currentBill = mOrder!!.currentBill.toFloat() / 100
        val minimumBill = mOrder!!.minimumBill.toFloat() / 100
        val fullBill = mOrder!!.fullBill.toFloat() / 100
        binding.radioCurrentBill.text =
                getString(R.string.label_preset_current_bill, decimalFormat.format(currentBill))
        binding.radioMinimumBill.text =
                getString(R.string.label_preset_minimum_bill, decimalFormat.format(minimumBill))
        binding.radioFullBill.text =
                getString(R.string.label_preset_full_bill, decimalFormat.format(fullBill))

        val inputCollectedAmount: TextInputEditText = binding.editResultCollectedAmount
        
        binding.radioGroupCollectedAmount.setOnCheckedChangeListener { _, checkedId ->
            val amountInputFormat = DecimalFormat("#######0.00")
            when (checkedId) {
                R.id.radio_input_bill -> {
                    inputCollectedAmount.text = null
                    inputCollectedAmount.isEnabled = true
                    inputCollectedAmount.requestFocus()
                    inputCollectedAmount.showSoftInput()
                }
                R.id.radio_current_bill -> {
                    inputCollectedAmount.setText(amountInputFormat.format(currentBill))
                    inputCollectedAmount.isEnabled = false
                    inputCollectedAmount.clearFocus()
                    inputCollectedAmount.hideSoftInput()
                }
                R.id.radio_minimum_bill -> {
                    inputCollectedAmount.setText(amountInputFormat.format(minimumBill))
                    inputCollectedAmount.isEnabled = false
                    inputCollectedAmount.clearFocus()
                    inputCollectedAmount.hideSoftInput()
                }
                R.id.radio_full_bill -> {
                    inputCollectedAmount.setText(amountInputFormat.format(fullBill))
                    inputCollectedAmount.isEnabled = false
                    inputCollectedAmount.clearFocus()
                    inputCollectedAmount.hideSoftInput()
                }
            }
        }

        binding.collectedAmount.enableResetErrorAfterTyped()

        binding.buttonGenerateQrcode.setOnClickListener {
            val collectorId: String = AccountUtils.getEmployeeCode(requireContext().applicationContext)
            val wo = mOrder!!
            val inputAmount: Float? = binding.editResultCollectedAmount.text.toString().toFloatOrNull()
            val collectedAmount: Int = if (inputAmount == null) 0 else (inputAmount * 100).toInt()

            val qrcodeDialog = QRCodeDialogFragment.newInstance(
                    token = wo.token,
                    collectorId = collectorId,
                    customerId = wo.customerId,
                    agreementNo = wo.agreementNo,
                    agreementDesc = wo.description,
                    amount = collectedAmount
            )
            qrcodeDialog.isCancelable = false
            qrcodeDialog.show(requireActivity().supportFragmentManager, "qrcode_fragment")
        }

        binding.otherApplication.enableResetErrorAfterTyped()
        binding.inputMobileBankingApp.run {
            filters = arrayOf(SpecialCharacterInputFilter(), WhitespaceInputFilter())
        }

        binding.editResultInputLayoutRemark.run {
            enableResetErrorAfterTyped()
            editText?.filters = arrayOf(SpecialCharacterInputFilter())
        }

        binding.editResultLayoutPhone.run {
            enableResetErrorAfterTyped()
            editText?.filters = arrayOf(SpecialCharacterInputFilter(), WhitespaceInputFilter())
        }

        binding.editResultInputLayoutPromisedDate.enableResetErrorAfterTyped()
        binding.editResultInputLayoutPromisedDate.editText?.run {
            disableSoftInputMethod()
            setOnClickListener {
                val calendar = Calendar.getInstance()
                val text = (it as TextInputEditText).text.toString()
                if (text.isNotEmpty()) {
                    calendar.time = dateFormat().parse(text)
                }
                showDatePickerDialog(
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                )
            }
        }

        binding.editResultInputLayoutPromisedTime.enableResetErrorAfterTyped()
        binding.editResultInputLayoutPromisedTime.editText?.run {
            disableSoftInputMethod()
            setOnClickListener {
                val calendar = Calendar.getInstance()
                val text = (it as TextInputEditText).text.toString()
                if (text.isNotEmpty()) {
                    calendar.time = timeFormat().parse(text)
                }
                showTimePickerDialog(
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE)
                )
            }
        }

        binding.editResultNegativeButton.setOnClickListener { dismiss() }
        binding.editResultPositiveButton.setOnClickListener {
            val imm = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(it.windowToken, 0)
            attemptSendCollectorResult()
        }
    }

    //private fun setupCollectionResultSpinner() {
    //    // Get a ContentResolver instance
    //    val contentResolver = requireActivity().contentResolver
    //
    //    val projection = arrayOf(
    //        BaseColumns._ID,
    //        CollectorResults.COLLECTOR_RESULT_CODE,
    //        CollectorResults.COLLECTOR_RESULT_NAME,
    //        CollectorResults.COLLECTOR_RESULT_TYPE,
    //        CollectorResults.COLLECTOR_RESULT_GET_MONEY,
    //        CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT,
    //        CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT,
    //        CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT,
    //        CollectorResults.COLLECTOR_RESULT_GROUPING_ORDER
    //    )
    //
    //    val selection: String? = null
    //    val selectionArgs: Array<String>? = null
    //
    //    // Query the content provider
    //    val cursor = contentResolver.query(
    //        CollectorResults.CONTENT_URI, // The content URI of the table
    //        projection, // The columns to return for each row
    //        selection, // Selection criteria
    //        selectionArgs, // Selection criteria
    //        null // The sort order for the returned rows
    //    )
    //
    //    cursor?.use {
    //        while (it.moveToNext()) {
    //            val id = cursor.getLong(cursor.getColumnIndexOrThrow(BaseColumns._ID))
    //            val code = cursor.getString(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_CODE))
    //            val name = cursor.getString(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_NAME))
    //            val type = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_TYPE))
    //            val getMoney = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_GET_MONEY))
    //            val printReceipt = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT))
    //            val minPayment = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT))
    //            val maxPayment = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT))
    //            val groupingOrder = cursor.getInt(cursor.getColumnIndexOrThrow(CollectorResults.COLLECTOR_RESULT_GROUPING_ORDER))
    //
    //            Log.d("TAG", "setupCollectionResultSpinner: $id")
    //            Log.d("TAG", "setupCollectionResultSpinner: $code")
    //            Log.d("TAG", "setupCollectionResultSpinner: $name")
    //            Log.d("TAG", "setupCollectionResultSpinner: $type")
    //            Log.d("TAG", "setupCollectionResultSpinner: $getMoney")
    //            Log.d("TAG", "setupCollectionResultSpinner: $printReceipt")
    //            Log.d("TAG", "setupCollectionResultSpinner: $minPayment")
    //            Log.d("TAG", "setupCollectionResultSpinner: $maxPayment")
    //            Log.d("TAG", "setupCollectionResultSpinner: $groupingOrder")
    //        }
    //    }
    //
    //    val collectionResultsContentUri = if (mIsMultipleSelected) {
    //        CollectorResults.CONTENT_URI_ACTIVE
    //    } else {
    //        CollectorResults.CONTENT_URI_ACTIVE_EXCLUDE_GET_MONEY
    //    }
    //
    //    val collectionResultsQuerySelection = if (mIsMultipleSelected) {
    //        CollectorResults.COLLECTOR_RESULT_IS_USED_EXCLUDE_GET_MONEY_SELECTION
    //    } else {
    //        CollectorResults.COLLECTOR_RESULT_IS_ACTIVE_SELECTION
    //    }
    //    val collectionResultsQuerySelectionArgs = if (mIsMultipleSelected) {
    //        arrayOf("1", "1")
    //    } else {
    //        arrayOf("1")
    //    }
    //    Log.d("setupCollectionResultSpinner", "collectionResultsQuerySelection: $collectionResultsQuerySelection")
    //
    //    val collectionResultsArray = mutableListOf<CollectorResult>()
    //    try {
    //        val cursor = requireContext().applicationContext.contentResolver.query(
    //            collectionResultsContentUri,
    //            CollectorResultQuery.NORMAL_PROJECTION,
    //            null,
    //            null,
    //            null)
    //
    //
    //        Log.d("setupCollectionResultSpinner", "cursor status: ${cursor != null}")
    //
    //        if (cursor != null) {
    //            Log.d("setupCollectionResultSpinner", "cursor count: ${cursor.count}")
    //            while (cursor.moveToNext()) {
    //                Log.d("setupCollectionResultSpinner", "start reading next cursor")
    //                val cr = CollectorResult.fromCursorRow(cursor)
    //                Log.d("setupCollectionResultSpinner", "collection result from cursor: ${cr.name}")
    //
    //                if (mIsMultipleSelected) {
    //                    collectionResultsArray.add(cr)
    //                    continue
    //                }
    //
    //                val isGetMoney = cr.money == 0
    //                val isPrintReceipt = cr.receipt == 0
    //                val isQrCodePayment = isGetMoney && !isPrintReceipt
    //                val requesterSource = mOrder!!.guid.slice(IntRange(0, 1))
    //
    //                Log.d("TAG", "setupCollectionResultSpinner: $requesterSource")
    //                Log.d("TAG", "setupCollectionResultSpinner: $isQrCodePayment")
    //
    //                if (isQrCodePayment) {
    //                    if (requesterSource in AEON_SOURCE_REGION)
    //                        collectionResultsArray.add(cr)
    //                } else {
    //                    collectionResultsArray.add(cr)
    //                }
    //            }
    //
    //            cursor.close()
    //        }
    //    } catch (e: Exception) {
    //        e.printStackTrace()
    //    }
    //
    //    Log.d("setupCollectionResultSpinner", "collectionResultsArray: ${collectionResultsArray.size}")
    //
    //    val collectionResultsAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, collectionResultsArray)
    //    collectionResultsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    //
    //    val formSpinnerCollectionResult = binding.formSpinnerCollectionResult
    //    formSpinnerCollectionResult.adapter = collectionResultsAdapter
    //    collectionResultsAdapter.notifyDataSetChanged()
    //    Log.d("setupCollectionResultSpinner", "collectionResultsAdapter: ${collectionResultsAdapter.count}")
    //    //formSpinnerCollectionResult.setOnFocusChangeListener { view, hasFocus ->
    //    //    if (hasFocus) {
    //    //        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    //    //        imm.hideSoftInputFromWindow(view.windowToken, 0)
    //    //    }
    //    //}
    //
    //    //formSpinnerCollectionResult.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
    //    //    override fun onNothingSelected(parent: AdapterView<*>) {
    //    //        // No operation
    //    //    }
    //    //
    //    //    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
    //    //        // Reset error.
    //    //        resetErrorInputFields()
    //    //
    //    //        if (position == 0) {
    //    //            setEnableGetMoneyInputs(false)
    //    //            setEnableQrCode(false)
    //    //            setEnableNextAppointmentInputs(false)
    //    //            return
    //    //        }
    //    //
    //    //        val cr = parent.getItemAtPosition(position) as CollectorResult
    //    //        mCollectorResult = cr
    //    //        selectedCollectorResult = cr
    //    //        selectedCollectorResultItemPosition = position
    //    //
    //    //        val isGetMoney = cr.money == 0
    //    //        val isPrintReceipt = cr.receipt == 0
    //    //        val isQrCodePayment = isGetMoney && !isPrintReceipt
    //    //
    //    //        if (isGetMoney) {
    //    //            setEnableGetMoneyInputs(true)
    //    //
    //    //            if (isQrCodePayment) {
    //    //                setEnableQrCode(true)
    //    //            } else {
    //    //                setEnableQrCode(false)
    //    //                requestFullPanAgreement()
    //    //            }
    //    //
    //    //            val preInputCollectAmount = cr.min == cr.max
    //    //            if (preInputCollectAmount) {
    //    //                when (cr.min) {
    //    //                    2 -> {
    //    //                        setDisablePresetCollectedAmount()
    //    //                        binding.radioMinimumBill.run {
    //    //                            isEnabled = true
    //    //                            isChecked = true
    //    //                        }
    //    //                    } // Minimum bill
    //    //                    3 -> {
    //    //                        setDisablePresetCollectedAmount()
    //    //                        binding.radioFullBill.run {
    //    //                            isEnabled = true
    //    //                            isChecked = true
    //    //                        }
    //    //                    } // Full bill
    //    //                    4 -> {
    //    //                        setDisablePresetCollectedAmount()
    //    //                        binding.radioCurrentBill.run {
    //    //                            isEnabled = true
    //    //                            isChecked = true
    //    //                        }
    //    //                    } // Current bill
    //    //                }
    //    //            }
    //    //        } else {
    //    //            setEnableGetMoneyInputs(false)
    //    //            setEnableQrCode(false)
    //    //        }
    //    //
    //    //        val loopJobType = cr.type == 0
    //    //        if (loopJobType) {
    //    //            setEnableNextAppointmentInputs(true)
    //    //        } else {
    //    //            setEnableNextAppointmentInputs(false)
    //    //        }
    //    //    }
    //    //}
    //
    //    //formSpinnerCollectionResult.setOnItemClickListener { adapterView, view, index, l ->
    //    //    val cr = adapterView.getItemAtPosition(index) as CollectorResult
    //    //
    //    //    mCollectorResult = cr
    //    //    selectedCollectorResult = cr
    //    //    selectedCollectorResultItemPosition = index
    //    //
    //    //    val isGetMoney = cr.money == 0
    //    //    val isPrintReceipt = cr.receipt == 0
    //    //    val isQrCodePayment = isGetMoney && !isPrintReceipt
    //    //
    //    //    if (isGetMoney) {
    //    //        setEnableGetMoneyInputs(true)
    //    //
    //    //        if (isQrCodePayment) {
    //    //            setEnableQrCode(true)
    //    //        } else {
    //    //            setEnableQrCode(false)
    //    //            requestFullPanAgreement()
    //    //        }
    //    //
    //    //        val preInputCollectAmount = cr.min == cr.max
    //    //        if (preInputCollectAmount) {
    //    //            when (cr.min) {
    //    //                2 -> {
    //    //                    setDisablePresetCollectedAmount()
    //    //                    binding.radioMinimumBill.run {
    //    //                        isEnabled = true
    //    //                        isChecked = true
    //    //                    }
    //    //                } // Minimum bill
    //    //                3 -> {
    //    //                    setDisablePresetCollectedAmount()
    //    //                    binding.radioFullBill.run {
    //    //                        isEnabled = true
    //    //                        isChecked = true
    //    //                    }
    //    //                } // Full bill
    //    //                4 -> {
    //    //                    setDisablePresetCollectedAmount()
    //    //                    binding.radioCurrentBill.run {
    //    //                        isEnabled = true
    //    //                        isChecked = true
    //    //                    }
    //    //                } // Current bill
    //    //            }
    //    //        }
    //    //    } else {
    //    //        setEnableGetMoneyInputs(false)
    //    //        setEnableQrCode(false)
    //    //    }
    //    //
    //    //    val loopJobType = cr.type == 0
    //    //    if (loopJobType) {
    //    //        setEnableNextAppointmentInputs(true)
    //    //    } else {
    //    //        setEnableNextAppointmentInputs(false)
    //    //    }
    //    //}
    //}

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        selectedCollectorResult?.apply {
            val collectorResultAutoCompleteTextView = binding.collectorResult.editText as AutoCompleteTextView
            collectorResultAutoCompleteTextView.run {
                for (position in 0 until adapter.count) {
                    val collectorResult = adapter.getItem(position) as CollectorResult
                    if (collectorResult.code == code) {
                        selectedCollectorResultItemPosition = position
                        setText(adapter.getItem(position).toString(), false)
                        listSelection = position
                        performCompletion()

                        collectorResult.run {
                            if (money == 0) {
                                binding.radioInputBill.isChecked = true
                                binding.collectedAmount.clearFocus()
                                setEnableGetMoneyInputs(true)

                                if (receipt == 1) {
                                    setEnableQrCode(true)
                                }
                            }

                            if (type == 0) {
                                setEnableNextAppointmentInputs(true)
                            }
                        }
                    }
                }
            }

            mOrder?.apply {
                binding.collectedAmount.run {
                    val currencyFormat = decimalFormatWithoutCommas()
                    val amount = resultCollectedAmount.toFloat() / 100
                    editText?.setText(currencyFormat.format(amount))
                }

                if (remark == 0) {
                    val collectorRemark = resultRemark.split(" ")
                    if (collectorRemark.size >= 3) {
                        binding.editResultInputLayoutRemark.editText
                                ?.setText(collectorRemark.subList(2, collectorRemark.size).joinToString(" "))
                        binding.editResultLayoutPhone.editText?.setText(collectorRemark[0])

                        if (money == 0) {
                            if (receipt == 1) {
                                selectedBank = collectorRemark[1]
                                val bankAutoCompleteTextView = binding.mobileBanking.editText as AutoCompleteTextView
                                bankAutoCompleteTextView.run {
                                    var isOtherBank = true
                                    for (position in 0 until adapter.count) {
                                        val bank = adapter.getItem(position) as String
                                        if (bank == selectedBank) {
                                            selectedBankItemPosition = position
                                            isOtherBank = false
                                            setText(selectedBank, false)
                                            listSelection = position
                                            performCompletion()
                                        }
                                    }

                                    if (isOtherBank) {
                                        val otherBank = adapter.getItem(adapter.count - 1) as String
                                        setText(otherBank, false)
                                        setEnableOtherMobileBankingAppInput(true)
                                        binding.otherApplication.editText?.setText(selectedBank)
                                    }
                                }
//                                bankAutoCompleteTextView.setText(collectorRemark[1], false)
                            }
                        }
                    }
                } else {
                    binding.editResultInputLayoutRemark.editText?.setText(resultRemark)
                }
//                binding.editResultInputLayoutRemark.editText?.setText(resultRemark)

                if (type == 0) {
                    val promisedDate = Date(resultPromisedDate * 1000L)
                    binding.editResultInputLayoutPromisedDate.editText?.run {
                        setText(dateFormat().format(promisedDate))
                        isEnabled = true
                    }
                    binding.editResultInputLayoutPromisedTime.editText?.run {
                        setText(timeFormat().format(promisedDate))
                        isEnabled = true
                    }
                }
            }
        }

//        mCollectorResult?.apply {
//            binding.collectorResults.run {
//                for (i in 0 until count) {
//                    val collectorResult = getItemAtPosition(i) as CollectorResult
//                    if (collectorResult.code == this@apply.code) {
//                        setSelection(i)
//                    }
//                }
//            }
//
//            mOrder?.apply {
//                binding.collectedAmount.run {
//                    val currencyFormat = DecimalFormat("#######0.00")
//                    val amount = resultCollectedAmount.toFloat() / 100
//                    editText?.setText(currencyFormat.format(amount))
//                }
//                binding.editResultInputLayoutRemark.editText?.setText(resultRemark)
////                binding.editResultRemark.setText(resultRemark)
//
//                val isLoop = type == 0
//                if (isLoop) {
//                    val promisedDate = Date(resultPromisedDate * 1000L)
//                    binding.editResultPromisedDate.run {
//                        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)
//                        setText(dateFormat.format(promisedDate))
//                        isEnabled = true
//                    }
//                    binding.editResultPromisedTime.run {
//                        val timeFormat = SimpleDateFormat("HH:mm", Locale.US)
//                        setText(timeFormat.format(promisedDate))
//                        isEnabled = true
//                    }
//                }
//            }
//        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        retainInstance = true
        return super.onCreateDialog(savedInstanceState).apply {
            if (mIncompleteTask) {
                setTitle(R.string.edit_result_title_new)
            } else {
                setTitle(R.string.edit_result_title_edit)
            }
            applyTitleStyle()

            window?.apply {
                val width = ViewGroup.LayoutParams.MATCH_PARENT
                val height = ViewGroup.LayoutParams.WRAP_CONTENT
                setLayout(width, height)
                setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }

            setOnKeyListener(DialogInterface.OnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP && !event.isCanceled) {
                    dialog.cancel()
                    return@OnKeyListener true
                }
                false
            })
        }
    }

    override fun onStart() {
        super.onStart()
        Timber.d("Target code: $targetRequestCode")

        // Request location updates.
        mLocationUtils = LocationUtils(requireContext().applicationContext, this)
        mLocationUtils!!.startLocationUpdates()

        // Register auto accept bluetooth pairing request.
        mBluetoothPrinterReceiver = BluetoothPrinterReceiver()
        val filter = IntentFilter(BluetoothDevice.ACTION_PAIRING_REQUEST)
        requireActivity().registerReceiver(mBluetoothPrinterReceiver, filter)

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter.isEnabled.not()) {
            bluetoothAdapter.enable()
        }
    }

    override fun onStop() {
        mLocationUtils?.stopLocationUpdates()
        
        mBluetoothPrinterReceiver?.apply {
            // Unregister auto accept bluetooth pairing request.
            requireActivity().unregisterReceiver(this)
        }
        super.onStop()
    }

    override fun onDestroyView() {
        val dialog = dialog
        if (dialog != null && retainInstance) {
            dialog.setDismissMessage(null)
        }
        super.onDestroyView()
    }

    override fun onDismiss(dialogInterface: DialogInterface) {
        mCollectorResult = null
        dismiss()
        super.onDismiss(dialogInterface)
    }

    private fun attemptSendCollectorResult() {
        // Reset errors.
        resetErrorInputFields()

        // Store values at the time of the result send.
//        val cr = binding.collectorResults.selectedItem as CollectorResult

        var cancel = false
        var isPrinterNotSelected = false
        var focusView: View? = null

        val printer = AccountUtils.getInUsedPrinterMacAddress(context?.applicationContext)

        binding.collectorResult.run {
            val editText = editText as AutoCompleteTextView
            if (editText.text.isNullOrEmpty()) {
                setError(R.string.edit_result_result_code_picker_error)
                focusView = this
                cancel = true
            }
        }

        selectedCollectorResult?.run {
            if (type == 0) {
                binding.editResultInputLayoutPromisedDate.run {
                    val nextAppointmentDate = editText?.text.toString()
                    if (nextAppointmentDate.isEmpty()) {
                        setError(R.string.edit_result_date_picker_error)
                        focusView = this
                        cancel = true
                    }
                }

                binding.editResultInputLayoutPromisedTime.run {
                    val nextAppointmentTime = editText?.text.toString()
                    if (nextAppointmentTime.isEmpty()) {
                        setError(R.string.edit_result_time_picker_error)
                        focusView = this
                        cancel = true
                    }
                }
            }

            if (this.remark == 0) {
                binding.editResultLayoutPhone.run {
                    val phoneNo = editText?.text.toString()
                    if (phoneNo.isEmpty()) {
                        setError(R.string.edit_result_required_phone)
                        focusView = this
                        cancel = true
                    }
                }

                binding.editResultInputLayoutRemark.run {
                    // Check for a valid remark, if collector result required remark.
                    val collectorRemark = editText?.text.toString()
                    if (collectorRemark.isEmpty()) {
                        setError(R.string.edit_result_remark_error)
                        focusView = this
                        cancel = true
                    }

                    if (isCounterEnabled) {
                        if (collectorRemark.length > counterMaxLength) {
                            setError(R.string.edit_result_remark_too_long)
                            focusView = this
                            cancel = true
                        }
                    }
                }
            }

            // Get Money
            if (money == 0) {
                // Pay via QR Code
                if (receipt == 1) {
                    binding.mobileBanking.run {
                        if (selectedBank.isEmpty()) {
                            setError(R.string.error_spinner_mobile_banking_app)
                            focusView = this
                            cancel = true
                        }
                    }
                    binding.otherApplication.run {
                        val bankAutoCompleteTextView = binding.mobileBanking.editText as AutoCompleteTextView
                        val lastBankItemPosition = bankAutoCompleteTextView.adapter.count - 1
                        if (selectedBankItemPosition == lastBankItemPosition) {
                            val bank = editText?.text.toString()
                            if (bank.isEmpty()) {
                                setError(R.string.error_other_mobile_banking_app)
                                focusView = this
                                cancel = true
                            }
                        }
                    }
                }

                binding.collectedAmount.run {
                    val collectedAmount = editText?.text.toString()
                    if (collectedAmount.isEmpty()) {
                        setError(R.string.edit_result_collected_amount_error_empty)
                        focusView = this
                        cancel = true
                    } else {
                        val minimumCollectedAmount: Int = when (min) {
                            2 -> mOrder?.minimumBill ?: 0
                            3 -> mOrder?.fullBill ?: 0
                            4 -> mOrder?.currentBill ?: 0
                            5 -> 0
                            6 -> 100
                            else -> 0
                        }
                        if ((collectedAmount.toFloat() * 100).toInt() < minimumCollectedAmount) {
                            hasError(getString(R.string.edit_result_collected_amount_error_min, (minimumCollectedAmount.toFloat() / 100)))
                            focusView = this
                            cancel = true
                        }

                        val maximumCollectedAmount: Int = when (max) {
                            2 -> mOrder?.minimumBill ?: 0
                            3 -> mOrder?.fullBill ?: 0
                            4 -> mOrder?.currentBill ?: 0
                            5 -> 0
                            6 -> 100
                            else -> 0
                        }
                        if ((collectedAmount.toFloat() * 100).toInt() > maximumCollectedAmount) {
                            hasError(getString(R.string.edit_result_collected_amount_error_max, (maximumCollectedAmount.toFloat() / 100)))
                            focusView = this
                            cancel = true
                        }
                    }
                }
            }

            if (receipt == 0 || letter == 0) {
                val printerRegex = Regex("^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\$")
                if (printer.isNullOrEmpty() || !printerRegex.matches(printer)) {
                    isPrinterNotSelected = true
//                    cancel = true
                }
            }

            val collectedAmount = binding.collectedAmount.editText?.text.toString()
            val collectorRemark = binding.editResultInputLayoutRemark.editText?.text.toString()
            val promisedDate = binding.editResultInputLayoutPromisedDate.editText?.text.toString()
            val promisedTime = binding.editResultInputLayoutPromisedTime.editText?.text.toString()
            Timber.d("""
                Attempt send collector result (name=$name, 
                totalAmount=$collectedAmount, 
                remark=$collectorRemark, 
                promised date=$promisedDate, 
                promised time=$promisedTime)
            """.trimIndent())
        }

//        val isLoop = selectedCollectorResult.type == 0
//        if (isLoop) {
//            // Check for a valid promised date and time,
//            // if collector result required promised date and time.
//            binding.editResultInputLayoutPromisedDate.run {
//                val nextAppointmentDate = editText?.text.toString()
//                if (nextAppointmentDate.isEmpty()) {
//                    setError(R.string.edit_result_date_picker_error)
//                    focusView = this
//                    cancel = true
//                }
//            }
//
//            binding.editResultInputLayoutPromisedTime.run {
//                val nextAppointmentTime = editText?.text.toString()
//                if (nextAppointmentTime.isEmpty()) {
//                    setError(R.string.edit_result_time_picker_error)
//                    focusView = this
//                    cancel = true
//                }
//            }
//        }

//        val isRemarkRequired = selectedCollectorResult.remark == 0
//        binding.editResultInputLayoutRemark.run {
//            // Check for a valid remark, if collector result required remark.
//            val inputRemark = editText?.text.toString()
//            if (isRemarkRequired) {
//                if (inputRemark.isEmpty()) {
//                    setError(R.string.edit_result_remark_error)
//                    focusView = this
//                    cancel = true
//                }
//            }
//
//            if (isCounterEnabled) {
//                if (inputRemark.length > counterMaxLength) {
//                    setError(R.string.edit_result_remark_too_long)
//                    focusView = this
//                    cancel = true
//                }
//            }
//        }
//        binding.editResultLayoutPhone.run {
//            if (isRemarkRequired) {
//                val inputPhone = editText?.text.toString()
//                if (inputPhone.isEmpty()) {
//                    setError(R.string.edit_result_required_phone)
//                    focusView = this
//                    cancel = true
//                }
//            }
//        }

//        val isGetMoney = selectedCollectorResult.money == 0
//        val isQrCode = selectedCollectorResult.receipt == 1

        // Check for a valid collected totalAmount, if collector result required money.
//        val getMoney = cr.money == 0
//        if (getMoney) {
//            if (collectedAmountString.isEmpty()) {
//                binding.collectedAmount.hasError(getString(R.string.edit_result_collected_amount_error_empty))
//                focusView = binding.editResultCollectedAmount
//                cancel = true
//            } else {
//                var collectedAmount: Int
//                var fullBill: Int
//                try {
//                    var number = NumberFormat.getInstance(Locale.US).parse(collectedAmountString)
//                    collectedAmount = (number.toFloat() * 100).toInt()
//                    val fFullBill = mOrder!!.fullBill.toFloat() / 100
//                    val dFullBill = Math.floor(java.lang.Double.valueOf(java.lang.Float.toString(fFullBill))!!)
//                    number = NumberFormat.getInstance(Locale.US).parse(dFullBill.toString())
//                    fullBill = number.toInt()
//                } catch (e: ParseException) {
//                    collectedAmount = -1
//                    fullBill = -1
//                    focusView = binding.editResultCollectedAmount
//                    cancel = true
//                }
//
//                var invalidGetMinimumMoney = false
//                var minimumRequiredAmount = 0f
//                when (cr.min) {
//                    2 -> {
//                        if (collectedAmount < mOrder!!.minimumBill) {
//                            minimumRequiredAmount = mOrder!!.minimumBill.toFloat() / 100
//                            invalidGetMinimumMoney = true
//                        }
//                    }
//                    3 -> {
//                        if (collectedAmount < fullBill) {
//                            minimumRequiredAmount = mOrder!!.fullBill.toFloat() / 100
//                            invalidGetMinimumMoney = true
//                        }
//                    }
//                    4 -> {
//
//                        if (collectedAmount < mOrder!!.currentBill) {
//                            minimumRequiredAmount = mOrder!!.currentBill.toFloat() / 100
//                            invalidGetMinimumMoney = true
//                        }
//                    }
//                    1, 5 -> {
//                        if (collectedAmount < 0) {
//                            minimumRequiredAmount = 0f
//                            invalidGetMinimumMoney = true
//                        }
//                    }
//                    6 -> {
//                        if (collectedAmount < 1) {
//                            minimumRequiredAmount = 1f
//                            invalidGetMinimumMoney = true
//                        }
//                    }
//                }
//                if (invalidGetMinimumMoney) {
//                    binding.collectedAmount.hasError(getString(R.string.edit_result_collected_amount_error_min, minimumRequiredAmount))
//                    focusView = binding.editResultCollectedAmount
//                    cancel = true
//                }
//
//                var invalidGetMaximumMoney = false
//                var maximumRequiredAmount = 0f
//                when (cr.max) {
//                    2 -> {
//                        if (collectedAmount > mOrder!!.minimumBill) {
//                            maximumRequiredAmount = mOrder!!.minimumBill.toFloat() / 100
//                            invalidGetMaximumMoney = true
//                        }
//                    }
//                    3 -> {
//                        if (collectedAmount > mOrder!!.fullBill) {
//                            maximumRequiredAmount = mOrder!!.fullBill.toFloat() / 100
//                            invalidGetMaximumMoney = true
//                        }
//                    }
//                    4 -> {
//                        if (collectedAmount > mOrder!!.currentBill) {
//                            maximumRequiredAmount = mOrder!!.currentBill.toFloat() / 100
//                            invalidGetMaximumMoney = true
//                        }
//                    }
//                    1, 5 -> {
//                        if (collectedAmount > 0) {
//                            maximumRequiredAmount = 0f
//                            invalidGetMaximumMoney = true
//                        }
//                    }
//                    6 -> {
//                        if (collectedAmount > 1) {
//                            maximumRequiredAmount = 1f
//                            invalidGetMaximumMoney = true
//                        }
//                    }
//                }
//                if (invalidGetMaximumMoney) {
//                    binding.collectedAmount.hasError(getString(R.string.edit_result_collected_amount_error_max, maximumRequiredAmount))
//                    focusView = binding.editResultCollectedAmount
//                    cancel = true
//                }
//            }
//        }

        // TODO: Check bluetooth support.
        // Check for printer mac address, if collector result is required printing.
//        val requiredPrinting = (cr.receipt == 0 || cr.letter == 0)
//        var isPrinterMacAddressEmpty = false
//        val printerMacAddress = AccountUtils.getInUsedPrinterMacAddress(activity!!.applicationContext)
        //        printerMacAddress = "AC:3F:A4:13:06:AF"; // MZ320
        //        printerMacAddress = "AC:3F:A4:16:BA:19"; // iMZ320
        //        AccountUtils.setInUsedPrinterMacAddress(getContext(), printerMacAddress);
//        if (requiredPrinting) {
//            if (printerMacAddress.isNullOrEmpty() || Regex("^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\$").matches(printerMacAddress).not()) {
//                isPrinterMacAddressEmpty = true
//                cancel = true
//            }
//        }

        if (cancel) {
            // There was an error; don't attempt send result and focus the first
            // form field with an error.
            focusView?.requestFocus()

//            if (isPrinterNotSelected) {
//                showSettingsDialog()
//            }
        } else {
//            mCollectorResult = cr
            if (isPrinterNotSelected) {
                showSettingsDialog()
            } else {
                val isPrint = selectedCollectorResult?.let { it.receipt == 0 || it.letter == 0 }
                        ?: false
                if (isPrint) {
                    mHelper = DialogHelper(activity)
                    doConnectionTest(printer)
                } else {
                    prepareResult()
                }
            }
        }
    }

    private fun TextInputLayout.hasError(message: String) = let {
        error = message
        isErrorEnabled = true
    }

    private fun EditText.disableSoftInputMethod() = run {
        showSoftInputOnFocus = false
        setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Disable soft keyboard when user touch on promised date.
                val imm = context.applicationContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                requireActivity().window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
                view.requestFocus()
            }
            false
        }
    }

    private fun specialCharacterInputFilter() = InputFilter { source, _, _, _, _, _ ->
        source.filterNot { BLOCKED_CHARACTERS.contains(it.toString()) }
    }

    private fun whitespaceInputFilter() = InputFilter { source, _, _, _, _, _ ->
        source.filterNot { it.isWhitespace() }
    }

    private fun setDisablePresetCollectedAmount() {
        binding.radioGroupCollectedAmount.run {
            for (x in 0 until this.childCount) this.getChildAt(x).isEnabled = false
        }
    }

    private fun setEnableGetMoneyInputs(isEnabled: Boolean) {
        if (!isEnabled) {
            binding.radioGroupCollectedAmount.clearCheck()
            binding.collectedAmount.editText?.text = null
        }

        binding.radioGroupCollectedAmount.run {
            for (x in 0 until this.childCount) this.getChildAt(x).isEnabled = isEnabled
        }
        binding.collectedAmount.isEnabled = isEnabled
    }

    private fun setEnableQrCode(isEnabled: Boolean) {
        val isVisible = if (isEnabled) View.VISIBLE else View.GONE
        binding.mobileBankingAppContainer.visibility = isVisible
        binding.mobileBanking.visibility = isVisible
        binding.buttonGenerateQrcode.visibility = isVisible

        if (!isEnabled) {
            selectedBank = ""
            selectedBankItemPosition = -1
            binding.mobileBanking.editText?.text = null
            binding.otherApplication.editText?.text = null
        }
    }

    private fun setEnableOtherMobileBankingAppInput(isEnabled: Boolean) {
        if (!isEnabled) {
            binding.otherApplication.editText?.text = null
        }

        val isVisible = if (isEnabled) View.VISIBLE else View.GONE
        binding.otherApplication.visibility = isVisible
        binding.otherApplication.isEnabled = isEnabled
    }

    private fun setEnableNextAppointmentInputs(isEnabled: Boolean) {
        if (!isEnabled) {
            binding.editResultPromisedDate.text = null
            binding.editResultPromisedTime.text = null
        }

        val isVisible = if (isEnabled) View.VISIBLE else View.GONE
        binding.editResultPromisedDatetime.visibility = isVisible
//        binding.editResultInputLayoutPromisedDate.visibility = isVisible
//        binding.editResultInputLayoutPromisedTime.visibility = isVisible
        binding.editResultInputLayoutPromisedDate.isEnabled = isEnabled
        binding.editResultInputLayoutPromisedTime.isEnabled = isEnabled
    }

    private fun resetErrorInputFields() {
        binding.apply {
            collectorResult.resetError()
            collectedAmount.resetError()
            otherApplication.resetError()
            editResultInputLayoutRemark.resetError()
            editResultLayoutPhone.resetError()
            editResultInputLayoutPromisedDate.resetError()
            editResultInputLayoutPromisedTime.resetError()
        }
    }

    private fun requestFullPanAgreement() {
        val order: Order = mOrder!!
        val isCreditCard = order.agreementNo.length == 16
        val isAeon = order.guid.substring(0, 2) != "AE"
        if (isCreditCard && isAeon) {
            mHelper = DialogHelper(activity)
            mHelper!!.showLoadingDialog("Retrieve agreement no.")
            if (order.token.isEmpty()) {
                requestAccessToken(RequestTokenOps.FROM_WORK_ORDER_ID, order.id)
            } else {
                requestAccessToken(RequestTokenOps.FROM_TOKEN, order.token)
            }
        }
    }

    private fun doConnectionTest(macAddress: String) {
        val r = Thread(Runnable {
            Looper.prepare()
            connect(macAddress)
            Looper.loop()
            Looper.myLooper()!!.quit()
        })
        val pool = Executors.newSingleThreadExecutor()
        pool.submit(r)
        pool.shutdown()
    }

    private fun connect(macAddress: String) {
        mPrinterConnection = BluetoothConnectionInsecure(macAddress)
        try {
            mHelper!!.showLoadingDialog(getString(R.string.edit_result_printer_connection_test))
            mPrinterConnection!!.open()
            mConnected = mPrinterConnection!!.isConnected
            Timber.d("connect=$mConnected")
            mPrinterConnection!!.close()
            Sleeper.sleep(4000)
        } catch (e: ConnectionException) {
            Timber.d("ConnectionException when test printer connection. Disconnecting")
            e.printStackTrace()
            mConnected = false
            disconnect()
        } finally {
            Timber.d("Closing loading dialog")
            mHelper!!.dismissLoadingDialog()
        }
        if (mConnected) {
            requireActivity().runOnUiThread {
                prepareResult()
                //                    finishSendResult();
                //                    getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, getActivity().getIntent());
                //                    dismiss();
            }
        } else {
            requireActivity().runOnUiThread { Snackbar.make(binding.root, R.string.edit_result_printer_not_connect, Snackbar.LENGTH_LONG).show() }
        }
    }

    private fun disconnect() {
        try {
            mPrinterConnection?.close()
        } catch (e: ConnectionException) {
            Timber.e("ConnectionException when disconnect printer connection")
        }

    }

    private fun prepareResult() {
        val datetimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
        val result = Result()
        val promisedDateString = binding.editResultPromisedDate.text.toString()
        val promisedTimeString = binding.editResultPromisedTime.text.toString()
        if (!TextUtils.isEmpty(promisedDateString) && !TextUtils.isEmpty(promisedTimeString)) {
            try {
                result.promisedDate = (datetimeFormat.parse("$promisedDateString $promisedTimeString").time / 1000L).toInt()
            } catch (e: ParseException) {
                result.promisedDate = 0
                Timber.e("ParseException while prepare result.")
            }

        }

        val bankAutoCompleteTextView = binding.mobileBanking.editText as AutoCompleteTextView
        val lastBankItemPosition = bankAutoCompleteTextView.adapter.count - 1
        val isOtherBank = selectedBankItemPosition == lastBankItemPosition
        val otherBank = binding.otherApplication.editText?.text.toString()
        val bank = if (isOtherBank) otherBank else selectedBank

        val phone: String = binding.editResultPhone.text.toString()
        val remark: String = binding.editResultInputLayoutRemark.editText?.text.toString()
//        val remark: String = binding.editResultRemark.text.toString()
        result.remark = "$phone $bank $remark"
//        result.remark = binding.editResultRemark.text.toString()

//        val collectedAmountString = parseInputCurrencyToString(binding.editResultCollectedAmount.text.toString())
//        result.collectedAmount = (java.lang.Float.parseFloat(collectedAmountString) * 100).toInt()
//        val amount: Float = edit_result_collected_amount.text.toString().toFloatOrNull() ?: 0f
        val amount: Float = binding.editResultCollectedAmount.text.toString().toFloatOrNull() ?: 0f
        Timber.d("Collected amount: $amount")
        result.collectedAmount = (amount * 100).toInt()
        Timber.d("Collected amount (After): ${result.collectedAmount}")
        result.collectedDate = (System.currentTimeMillis() / 1000L).toInt()
        result.battery = batteryLevel

        if (mLocation != null) {
            result.provider = mLocation!!.provider
            result.locationTime = (mLocation!!.time / 1000L).toInt()
            result.latitude = mLocation!!.latitude
            result.longitude = mLocation!!.longitude
            result.speed = mLocation!!.speed
        } else {
            val empCode = AccountUtils.getEmployeeCode(requireActivity().applicationContext)
            val cursor = requireActivity().applicationContext.contentResolver.query(
                    OrderContract.Locations.CONTENT_URI_LATEST,
                    OrderContract.Locations.LATEST_PROJECTION,
                    OrderContract.Locations.LOCATION_LATEST_SELECTION,
                    arrayOf(empCode), null)

            if (cursor != null && cursor.moveToFirst()) {
                result.provider = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_PROVIDER))
                result.locationTime = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_TIME))
                result.latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_LATITUDE))
                result.longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_LONGITUDE))
                result.speed = cursor.getFloat(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_SPEED))
                cursor.close()
            } else {
                // TODO: Alert message
                return
            }
        }
        when (result.provider) {
            LocationManager.GPS_PROVIDER -> result.signal = 1
            LocationManager.NETWORK_PROVIDER -> result.signal = 2
            else -> result.signal = 0
        }

        val extras = Bundle()
        extras.putParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS, mSelectedOrders)
        extras.putParcelable(Config.EXTRA_EDIT_RESULT_COLLECTOR_RESULT, mCollectorResult)
        extras.putParcelable(Config.EXTRA_EDIT_RESULT_INPUT_RESULT, result)

        val intent = Intent()
        intent.putExtras(extras)
        mListener!!.onFinishEditResult(intent)
        dismiss()
    }

//    private fun initFieldsFromSelectedCollectorResult(cr: CollectorResult) {
//        Timber.d("result(code=${cr.code}, name=${cr.name}")
//
//        // Reset error.
//        resetErrorInputFields()
//
//        // Set collected totalAmount.
//        val currencyFormat = DecimalFormat("##,###,##0.00")
//        if (cr.money == 0) {
//            if (cr.min == 3 && cr.max == 3) {
//                val fullBill = mOrder!!.fullBill.toFloat() / 100
//                val floorFullBill = Math.floor(java.lang.Double.valueOf(java.lang.Float.toString(fullBill))!!)
//                binding.collectedAmount.apply {
//                    editText?.setText(currencyFormat.format(floorFullBill))
//                    isEnabled = false
//                }
//            } else {
//                binding.collectedAmount.apply {
//                    editText?.text = null
//                    isEnabled = true
//                }
//            }
//        } else {
//            // Disable collected totalAmount, if collector result is not get money.
//            binding.collectedAmount.apply {
//                editText?.setText(currencyFormat.format(0))
//                isEnabled = false
//            }
//        }
//
//        // Set promised date and time.
//        if (cr.type == 0) {
//            binding.editResultPromisedDatetime.visibility = View.VISIBLE
//            binding.editResultInputLayoutPromisedDate.isEnabled = true
//            binding.editResultInputLayoutPromisedTime.isEnabled = true
//        } else {
//            // Disable promised date and time, if collector result is not loop.
//            binding.editResultInputLayoutPromisedDate.apply {
//                editText?.text = null
//                isEnabled = false
//            }
//            binding.editResultInputLayoutPromisedTime.apply {
//                editText?.text = null
//                isEnabled = false
//            }
//            binding.editResultPromisedDatetime.visibility = View.GONE
//        }
//    }

    private fun DatePickerDialog.setCustomTitle(@StringRes resId: Int) = run {
        val title = TextView(context)
        title.run {
            setPadding(16, 16, 16, 16)
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setBackgroundColor(ContextCompat.getColor(context, R.color.aeon))
            setTextAppearance(context, R.style.DateTimePickerDialogTextTitle)
            setText(resId)
        }
        setCustomTitle(title)
    }

    private fun TimePickerDialog.setCustomTitle(@StringRes resId: Int) = run {
        val title = TextView(context)
        title.run {
            setPadding(16, 16, 16, 16)
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setBackgroundColor(ContextCompat.getColor(context, R.color.aeon))
            setTextAppearance(context, R.style.DateTimePickerDialogTextTitle)
            setText(resId)
        }
        setCustomTitle(title)
    }

    private fun showDatePickerDialog(year: Int, month: Int, dayOfMonth: Int) {
        val calendar = Calendar.getInstance()
        val dialog = DatePickerDialog(
                requireContext(),
                DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                    calendar.set(selectedYear, selectedMonth, selectedDayOfMonth)
                    binding.editResultInputLayoutPromisedDate.run {
                        editText?.setText(dateFormat().format(calendar.time))
                        if (isErrorEnabled) resetError()
                    }
                },
                year,
                month,
                dayOfMonth
        )
        dialog.run {
            setCustomTitle(R.string.edit_result_date_picker_title)
            setCanceledOnTouchOutside(false)
            datePicker.minDate = System.currentTimeMillis() - 1000L
        }
        dialog.show()
    }

    private fun showTimePickerDialog(hourOfDay: Int, minute: Int) {
        val calendar = Calendar.getInstance()
        val dialog = TimePickerDialog(activity,
                TimePickerDialog.OnTimeSetListener { _, selectedHourOfDay, selectedMinute ->
                    calendar.set(Calendar.HOUR_OF_DAY, selectedHourOfDay)
                    calendar.set(Calendar.MINUTE, selectedMinute)
                    binding.editResultInputLayoutPromisedTime.run {
                        editText?.setText(timeFormat().format(calendar.time))
                        if (isErrorEnabled) resetError()
                    }
                },
                hourOfDay,
                minute,
                true
        )
        dialog.run {
            setCustomTitle(R.string.edit_result_time_picker_title)
            setCanceledOnTouchOutside(false)
        }
        dialog.show()
    }

    private fun showSettingsDialog() {
        AlertDialog.Builder(activity).apply {
            setMessage(R.string.edit_result_printer_mac_address_not_found)
            setPositiveButton("OK") { _, _ ->
            }
//            setPositiveButton(R.string.edit_result_printer_settings) { _, _ ->
//                val intent = Intent(activity!!.applicationContext, SettingsActivity::class.java)
//                intent.putExtra(PreferenceActivity.EXTRA_SHOW_FRAGMENT,
//                        SettingsActivity.DefaultPreferenceFragment::class.java.name)
//                intent.putExtra(PreferenceActivity.EXTRA_NO_HEADERS, true)
//                startActivity(intent)
//            }
        }.show()
    }

    override fun onLocationUpdate(location: Location) {
        Timber.d("location(provider=${location.provider}, lat=${location.latitude}, lon=${location.longitude}")
        mLocation = location
    }

    interface EditResultDialogListener {
        fun onFinishEditResult(data: Intent)
    }

    private interface CollectorResultQuery {
        companion object {
            val NORMAL_PROJECTION = arrayOf(
                    BaseColumns._ID,
                    CollectorResults.COLLECTOR_RESULT_CODE,
                    CollectorResults.COLLECTOR_RESULT_NAME,
                    CollectorResults.COLLECTOR_RESULT_TYPE,
                    CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT,
                    CollectorResults.COLLECTOR_RESULT_PRINT_LETTER,
                    CollectorResults.COLLECTOR_RESULT_GET_MONEY,
                    CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT,
                    CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT,
                    CollectorResults.COLLECTOR_RESULT_REQUIRED_REMARK)
        }
    }

    object RequestTokenOps {
        const val FROM_TOKEN = 0
        const val FROM_WORK_ORDER_ID = 1
    }

    private fun requestAccessToken(ops: Int, param: String) {
        Timber.d("Request access token.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("auth")
                .appendPath("token")
        val url = builder.build().toString()
        val accountManager = AccountManager.get(requireActivity().applicationContext)
        val account = AccountUtils.getActiveAccount(requireActivity().applicationContext)
        val refreshToken = accountManager.peekAuthToken(account, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN)
        val imei = accountManager.getUserData(account, Config.BUNDLE_ARG_AUTH_DEVICE_IMEI)
        val params = JSONObject()
        params.put("grant_type", "refresh_token")
        params.put("client_id", imei)
        params.put("refresh_token", refreshToken)
        val request = JsonObjectRequest(Request.Method.POST, url, params,
                Response.Listener { response ->
                    val accessToken = response.getString("access_token")
                    if (accessToken.isNotBlank()) {
                        when (ops) {
                            RequestTokenOps.FROM_TOKEN -> detokenFullPan(ops, accessToken, param)
                            RequestTokenOps.FROM_WORK_ORDER_ID -> detokenFullPan(ops, accessToken, param)
                        }
                    }
                },
                Response.ErrorListener {
                    mHelper?.dismissLoadingDialog()
                    binding.agreementFullPan.apply {
                        setText(R.string.edit_result_detoken_failed)
                        visibility = View.VISIBLE
                    }
                })
        BackendVolley.init(requireActivity().applicationContext)
        BackendVolley.addToRequestQueue(request)
    }

    private fun detokenFullPan(ops: Int, accessToken: String, param: String) {
        Timber.d("Request full-pan from param: $param")
        if (param.isEmpty()) {
            return
        }

        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("pci-gateway")
                .appendPath("de-token")
                .appendPath(
                        when (ops) {
                            RequestTokenOps.FROM_TOKEN -> "token"
                            RequestTokenOps.FROM_WORK_ORDER_ID -> "work-order"
                            else -> ""
                        }
                )
                .appendPath(param)
                .appendPath("full-pan")
        val url = builder.build().toString()

        val request = object : JsonObjectRequest(Request.Method.GET, url, null,
                Response.Listener {
                    if (it.getString("RespCode") == "00" && it.getString("RespDesp") == "Success") {
                        val agreementNo = it.getString("PlnTxt")
                        mOrder!!.agreementNoFullPan = agreementNo
                        Timber.d("Successfully get agreement no full-pan: $agreementNo")
                        mHelper?.dismissLoadingDialog()
                    } else {
                        mHelper?.showErrorDialogOnUiThread(getString(R.string.error_agreement_decryption))
                    }
                },
                Response.ErrorListener {
                    Timber.d("Error when detoken full-pan from token: response=${it.networkResponse}")
                    mHelper?.dismissLoadingDialog()
                    binding.agreementFullPan.apply {
                        setText(R.string.edit_result_detoken_failed)
                        visibility = View.VISIBLE
                    }
                }) {

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }
        }
        BackendVolley.init(requireActivity().applicationContext)
        BackendVolley.addToRequestQueue(request)
    }

    companion object {

        private const val BLOCKED_CHARACTERS =
                "~!@#�$%^&*()-_=+×÷<>:;,?/|\\[]{}€£฿¥₩`¤♡♥_|《》¡¿°•○●□■◇◆♧♣♤▲▼▶◀⨀⊙◉↑↓←→☆★▪:-);-):-D:-(:'(:O'\"\n\r\t"

        private val AEON_SOURCE_REGION = arrayOf("BK", "CM", "HY", "KK", "SC")

        fun newInstance(listener: EditResultDialogListener): EditResultDialogFragment {
            val fragment = EditResultDialogFragment()
            fragment.setEditResultDialogListener(listener)
            return fragment
        }

        fun newInstance(order: Order, cr: CollectorResult?): EditResultDialogFragment {
            val f = EditResultDialogFragment()
            val args = Bundle()
            args.putParcelable(Config.EXTRAS_ORDER, order)
            args.putParcelable(Config.EXTRAS_COLLECTOR_RESULT, cr)
            f.arguments = args
            return f
        }

        fun newInstance(orders: ArrayList<Order>): EditResultDialogFragment {
            val f = EditResultDialogFragment()
            val args = Bundle()
            args.putParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS, orders)
            f.arguments = args
            return f
        }
    }
}
