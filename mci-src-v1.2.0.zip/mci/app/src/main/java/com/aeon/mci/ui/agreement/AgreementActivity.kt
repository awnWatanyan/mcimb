package com.aeon.mci.ui.agreement

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.WindowManager
import androidx.appcompat.widget.Toolbar
import com.aeon.mci.BuildConfig
import com.aeon.mci.R
import com.aeon.mci.persistence.Customer
import com.aeon.mci.ui.PrintActivity
import com.aeon.mci.ui.customerinfo.CustomerInfoFragment
import com.aeon.mci.util.CommonIntentUtils
import com.aeon.mci.util.setBackgroundColor
import com.aeon.mci.util.setStatusBarColor
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AgreementActivity : PrintActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEBUG) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        setContentView(R.layout.activity_agreement)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

//        val isComplete = intent.getBooleanExtra(EXTRA_COMPLETE, false)
//        val customer: Customer = intent.getParcelableExtra(EXTRA_CUSTOMER)

        if (isNewTask) {
            supportActionBar?.setBackgroundColor(R.color.assign)
            setStatusBarColor(R.color.assign_dark)
        } else {
            supportActionBar?.setBackgroundColor(R.color.complete)
            setStatusBarColor(R.color.complete_dark)
        }
        setActionBar()

        val customerInfoFragment = CustomerInfoFragment.newInstance(customer, isNewTask)
        val agreementFragment = AgreementFragment.newInstance(customer, isNewTask)
        val ft = supportFragmentManager.beginTransaction()
        ft.replace(R.id.content_customer_info, customerInfoFragment)
        ft.replace(R.id.content_agreement, agreementFragment)
        ft.commit()
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        if (isNewTask) {
            if (menu != null) {
                if (customer.mobile.isNotEmpty() && customer.mobile.length == 10) {
                    menu.findItem(R.id.action_dial_customer_mobile).isVisible = true
                }
                if (customer.phone.isNotEmpty() && customer.phone.length == 9) {
                    menu.findItem(R.id.action_dial_customer_phone).isVisible = true
                }
            }
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (isNewTask) {
            if (menu != null) {
                menuInflater.inflate(R.menu.customer_info, menu)
            }
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> supportFinishAfterTransition()
            R.id.action_google_maps_navigation -> {
                CommonIntentUtils(applicationContext).openNavigationInGoogleMaps(customer.address)
            }
            R.id.action_google_maps_navigation_with_location -> {
                CommonIntentUtils(applicationContext).openNavigationInGoogleMaps(customer.address, customer.lat.toString(), customer.lon.toString())
            }
            R.id.action_dial_customer_mobile -> { openDialer(customer.mobile) }
            R.id.action_dial_customer_phone -> { openDialer(customer.phone) }
            else -> {}
        }
        return super.onOptionsItemSelected(item)
    }

    private fun openDialer(phoneNo: String) {
//        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.CALL_PHONE)
//            != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 0)
//        } else {
//            CommonIntentUtils(applicationContext).openDialer(phoneNo)
//        }
        CommonIntentUtils(applicationContext).openDialer(phoneNo)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        supportFinishAfterTransition()
    }

    companion object {
        private const val EXTRA_CUSTOMER = "CUSTOMER"
        private const val EXTRA_IS_COMPLETE = "IS_COMPLETE"

        fun starterIntent(context: Context, customer: Customer, isComplete: Boolean): Intent {
            return Intent(context, AgreementActivity::class.java).apply {
                putExtra(EXTRA_IS_COMPLETE, isComplete)
                putExtra(EXTRA_CUSTOMER, customer)
            }
        }
    }
}