package com.aeon.mci.util.printing

import java.text.BreakIterator

fun isMark(ch: Char): Boolean {
    val type = ch.toByte()
    return type == Character.NON_SPACING_MARK ||
            type == Character.ENCLOSING_MARK ||
            type == Character.COMBINING_SPACING_MARK
}

fun String.graphemeLength(): Int {
    val iter = BreakIterator.getCharacterInstance()
    iter.setText(this)

    var count = 0
    while (iter.next() != BreakIterator.DONE) count++
    return count
}

fun String.countWhitespace(): Int {
    var count = 0
    forEach { c -> if (c.isWhitespace()) count++ }
    return count
}