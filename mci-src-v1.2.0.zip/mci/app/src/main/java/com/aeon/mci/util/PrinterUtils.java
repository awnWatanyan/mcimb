package com.aeon.mci.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;

import com.aeon.mci.Config;
import com.aeon.mci.R;
import com.aeon.mci.ui.DialogHelper;
import com.aeon.mci.ui.order.OrderActivity;
import com.aeon.mci.util.printing.PrintingAira;
import com.aeon.mci.util.printing.PrintingPromise;
import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.Connection;
import com.zebra.sdk.comm.ConnectionException;
import com.zebra.sdk.printer.PrinterLanguage;
import com.zebra.sdk.printer.ZebraPrinter;
import com.zebra.sdk.printer.ZebraPrinterFactory;
import com.zebra.sdk.printer.ZebraPrinterLanguageUnknownException;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import timber.log.Timber;

public class PrinterUtils {

    public static void printReceipt(final Activity activity, final Bundle data,
                                    final boolean copy) {
        Runnable r = new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                connectAndSendReceiptLabel(activity, data, copy);
                Looper.loop();
                Looper.myLooper().quit();
            }
        });
        ExecutorService pool = Executors.newSingleThreadExecutor();
        pool.submit(r);
        pool.shutdown();
    }

    public static void printNotice(final Activity activity, final Bundle data,
                                   final boolean incompleteTask) {
        Runnable r = new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                connectAndSendNoticeLabel(activity, data, incompleteTask);
                Looper.loop();
                Looper.myLooper().quit();
            }
        });
        ExecutorService pool = Executors.newSingleThreadExecutor();
        pool.submit(r);
        pool.shutdown();
    }

    private static void connectAndSendNoticeLabel(
            Activity activity,
            Bundle data,
            boolean incompleteTask
    ) {
        DialogHelper mDialogHelper = new DialogHelper(activity);
        String mPrinterMacAddress = AccountUtils.getInUsedPrinterMacAddress(activity);
        if (mPrinterMacAddress == null) {
            mDialogHelper.showErrorDialogOnUiThread("No saved printer");
            return;
        }

        String guid = data.getString(Config.EXTRAS_GUID);
        String region = TextUtils.isEmpty(guid) ? "" : guid.subSequence(0, 2).toString();
        boolean isOtherClient = TextUtils.equals(region, "AE");

        Connection connection = new BluetoothConnection(mPrinterMacAddress);
        try {
            mDialogHelper.showLoadingDialog(activity.getString(R.string.printer_connecting));
            connection.open();

            ZebraPrinter printer;
            if (connection.isConnected()) {
                printer = ZebraPrinterFactory.getInstance(connection);
                PrinterLanguage pl = printer.getPrinterControlLanguage();
                if (pl == PrinterLanguage.CPCL || pl == PrinterLanguage.LINE_PRINT) {
                    mDialogHelper.updateLoadingDialog(activity.getString(R.string.printer_printing_notice));

//                    byte[] label = isOtherClient
//                            ? PrinterNoticeLabel.createLabelForOtherClient(data).getBytes("TIS-620")
//                            : PrinterNoticeLabel.createLabelForAeon(data).getBytes("TIS-620");
//                    connection.write(label);

                    String letterLabel;
                    if (isOtherClient) {
                        letterLabel = PrinterNoticeLabel.createLabelForOtherClient(data);

                        String collectorName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME, "");
                        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME, "");
                        String customerNameTh = customerName.isEmpty() ? "" : customerName.split("/", -1)[0];
                        String clientNameEn = data.getString(Config.EXTRAS_CLIENT_NAME_EN, "");
                        String clientNameTh = data.getString(Config.EXTRAS_CLIENT_NAME_TH, "");
                        String contactNo = data.getString(Config.EXTRAS_CLIENT_CONTACT_NO, "");

                        boolean isPromise = clientNameEn.matches(".*PROMISE.*");
                        if (isPromise) {
                            String memberNo = data.getString(Config.EXTRAS_AGREEMENT_NO, "");
                            letterLabel = PrintingPromise.INSTANCE.createLetterContent(
                                    collectorName,
                                    memberNo,
                                    customerNameTh,
                                    contactNo
                            );
                        }

                        boolean isAira = clientNameEn.matches(".*AIRA.*");
                        if (isAira) {
                            if (contactNo.length() == 9) {
                                MessageFormat phoneFormat = new MessageFormat("{0}-{1}-{2}");
                                String[] phoneArgs = {
                                        contactNo.substring(0, 2),
                                        contactNo.substring(2, 5),
                                        contactNo.substring(5)
                                };
                                contactNo = phoneFormat.format(phoneArgs);
                            }
                            letterLabel = PrintingAira.INSTANCE.createLetterContent(
                                    collectorName,
                                    customerNameTh,
                                    clientNameTh,
                                    contactNo
                            );
                        }
                    } else {
                        letterLabel = PrinterNoticeLabel.createLabelForAeon(data);
                    }
                    connection.write(letterLabel.getBytes("TIS-620"));

                    Sleeper.sleep(2500);
                }
                connection.close();
                mDialogHelper.updateLoadingDialog(
                        activity.getString(R.string.printer_waiting_blue_light_disappear));
                Sleeper.sleep(5500);
            }
        } catch (ConnectionException e) {
            Timber.e("ConnectionException encountered: %s", e.getMessage());
        } catch (ZebraPrinterLanguageUnknownException e) {
            Timber.e("ZebraPrinterLanguageUnknownException encountered: %s", e.getMessage());
        } catch (UnsupportedEncodingException e) {
            Timber.e("UnsupportedEncodingException encountered: %s", e.getMessage());
        } finally {
            mDialogHelper.dismissLoadingDialog();
            if (activity instanceof OrderActivity) {
                if (incompleteTask) {
                    activity.finish();
                }
            }
        }
    }

    private static void connectAndSendReceiptLabel(
            final Activity activity,
            final Bundle data,
            boolean isCopyPart
    ) {
        DialogHelper mDialogHelper = new DialogHelper(activity);

        String mPrinterMacAddress = AccountUtils.getInUsedPrinterMacAddress(activity);
        if (mPrinterMacAddress == null) {
            mDialogHelper.showErrorDialogOnUiThread("No saved printer");
            return;
        }

        String guid = data.getString(Config.EXTRAS_GUID);
        boolean incompleteTask = data.getBoolean(Config.EXTRAS_INCOMPLETE_TASK);

        String region = TextUtils.isEmpty(guid) ? "" : guid.substring(0, 2);
        boolean isForOtherClient = TextUtils.equals(region, "AE");

        Connection connection = new BluetoothConnection(mPrinterMacAddress);

        try {
            mDialogHelper.showLoadingDialog(activity.getString(R.string.printer_connecting));
            connection.open();

            ZebraPrinter printer;

            if (connection.isConnected()) {
                printer = ZebraPrinterFactory.getInstance(connection);
                PrinterLanguage pl = printer.getPrinterControlLanguage();
                if (pl == PrinterLanguage.CPCL || pl == PrinterLanguage.LINE_PRINT) {
                    mDialogHelper.updateLoadingDialog(
                            activity.getString(R.string.printer_printing_receipt));
                    byte[] label = isForOtherClient
                            ? PrinterReceiptLabel.createLabelForOtherClient3(data, isCopyPart).getBytes("TIS-620")
                            : PrinterReceiptLabel.createLabelForAeon3(data, isCopyPart).getBytes("TIS-620");

                    connection.write(label);
                    Sleeper.sleep(2500);
                }
                connection.close();
                mDialogHelper.updateLoadingDialog(
                        activity.getString(R.string.printer_waiting_blue_light_disappear));
                Sleeper.sleep(5500);
            }
        } catch (ConnectionException e) {
            Timber.e("ConnectionException encountered: %s", e.getMessage());
        } catch (ZebraPrinterLanguageUnknownException e) {
            Timber.e("ZebraPrinterLanguageUnknownException encountered: %s", e.getMessage());
        } catch (UnsupportedEncodingException e) {
            Timber.e("UnsupportedEncodingException encountered: %s", e.getMessage());
        } finally {
            mDialogHelper.dismissLoadingDialog();
            if (!isCopyPart) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        new AlertDialog.Builder(activity)
                                .setMessage(R.string.order_print_copy_receipt_dialog_content)
                                .setCancelable(false)
                        .setPositiveButton(R.string.positive_button_ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                printReceipt(activity, data, true);
                            }
                        }).show();
                    }
                });
            } else {
                if (activity instanceof OrderActivity) {
                    if (incompleteTask) {
                        activity.finish();
                    }
                }
            }
        }

    }
}
