package com.aeon.mci.util

import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.appcompat.app.ActionBar
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.aeon.mci.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

inline fun <T : ViewDataBinding> T.executeAfter(block: T.() -> Unit) {
    block()
    executePendingBindings()
}

fun Dialog.applyTitleStyle() = apply {
    val title: TextView? = findViewById(android.R.id.title)
    title?.run {
        setPadding(16, 16, 16, 16)
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        setBackgroundColor(ContextCompat.getColor(context, R.color.aeon))
        setTextColor(Color.WHITE)
        val typeface = ResourcesCompat.getFont(context, R.font.sarabun)
        setTypeface(typeface)
        includeFontPadding = false
    }
}

fun Spinner.setError(@StringRes resId: Int) = apply {
    val errorText: TextView = this.selectedView as TextView
    errorText.error = null
    errorText.setTextColor(Color.RED)
    errorText.setText(resId)
}

fun TextInputLayout.setError(@StringRes resId: Int) {
    isErrorEnabled = true
    error = context.getString(resId)
}

fun TextInputLayout.resetError() = apply {
    error = null
    isErrorEnabled = false
}

fun TextInputLayout.enableResetErrorAfterTyped() = apply {
    editText?.run {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                this@apply.error = null
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No operation
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // No operation
            }
        })
    }
}

fun TextInputEditText.showSoftInput() = apply {
    val imm = context.applicationContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
}

fun TextInputEditText.hideSoftInput() = apply {
    val imm = context.applicationContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(this.windowToken, 0)
}

fun AutoCompleteTextView.hideSoftInputOnFocus() = apply {
    setOnFocusChangeListener { view, hasFocus ->
        if (hasFocus) {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }
}

fun BottomNavigationView.hide() = apply {
    animate().translationY(height.toFloat())
}

fun BottomNavigationView.show() = apply {
    animate().translationY(0f)
}

fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
            afterTextChanged.invoke(s.toString())
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

        override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    })
}

fun EditText.validate(message: String, validator: (String) -> Boolean): Boolean {
    this.afterTextChanged {
        this.error = if (validator(it)) null else message
    }
    this.error = if (validator(this.text.toString())) null else message
    return validator(this.text.toString())
}

fun FragmentActivity.setTaskDescription() {
    val taskDescription = ActivityManager.TaskDescription(
            getString(R.string.title_activity_base),
            null,
            ContextCompat.getColor(applicationContext, R.color.purple))
    setTaskDescription(taskDescription)
}

fun FragmentActivity.setStatusBarColor(colorResId: Int) {
    supportLollipop {
        with(window) {
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarColor = ContextCompat.getColor(context, colorResId)
        }
    }
}

fun Fragment.setStatusBarColor(colorResId: Int) = activity?.setStatusBarColor(colorResId)

fun ActionBar.setBackgroundColor(colorResId: Int) {
    val background = ColorDrawable(ContextCompat.getColor(themedContext, colorResId))
    setBackgroundDrawable(background)
}