package com.aeon.mci.ui.customerinfo

import androidx.databinding.BindingAdapter
import android.widget.TextView
import com.aeon.mci.R

@BindingAdapter("text")
fun text(textView: TextView, text: String) {
    textView.text = if (text.isEmpty()) "-" else text
}

@BindingAdapter("customerAge")
fun customerAge(textView: TextView, age: Int) {
    textView.text = if (age == 0) "-" else age.toString()
}

@BindingAdapter("customerGender")
fun customerGender(textView: TextView, gender: Int) {
    textView.text = when (gender) {
        1 -> textView.context.getString(R.string.gender_male)
        2 -> textView.context.getString(R.string.gender_female)
        3 -> textView.context.getString(R.string.gender_other)
        4 -> textView.context.getString(R.string.gender_corporate)
        else -> "-"
    }
}

@BindingAdapter("customerPhone")
fun customerPhone(textView: TextView, number: String) {
    textView.text = when {
        number.isEmpty() -> "-"
        number.length > 3 -> number.substring(0, number.length - 3).plus("XXX")
        else -> number
    }
}