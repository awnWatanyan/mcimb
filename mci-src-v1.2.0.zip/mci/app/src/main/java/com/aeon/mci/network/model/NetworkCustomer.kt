package com.aeon.mci.network.model

import kotlinx.datetime.Instant
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class NetworkCustomer(
    @SerialName("plan_id")
    val planId: String,
    @SerialName("plan_assigned_date")
    val planAssignedDate: Instant,
    @SerialName("plan_seq_id")
    val planSeqId: Int,
    @SerialName("job_status")
    val jobStatus: Int,
    @SerialName("request_date")
    val requestDate: Instant,
    @SerialName("task_type")
    val taskType: String,
    val priority: String,
    @SerialName("operator_name")
    val operatorName: String,
    @SerialName("survey_type")
    val surveyType: String,
    val sex: String,
    val age: Int,
    val zipcode: String,
    @SerialName("customer_address")
    val customerAddress: String = "",
    val section: String = "",
    val mobile: String = "",
    val phone: String = "",
    @SerialName("phone_ext")
    val phoneExt: String = "",
    @SerialName("total_collect_amount")
    val totalCollectAmount: Double,
    @SerialName("collect_date")
    val collectDate: Instant,
    @SerialName("collect_time")
    val collectTime: String = "",
    @SerialName("id_max_delinquent_status")
    val idMaxDelinquentStatus: String = "",
    @SerialName("id_outstanding_balance")
    val idOutstandingBalance: String = "",
    @SerialName("id_total_bill")
    val idTotalBill: String = "",
    @SerialName("client_name_th")
    val clientNameTh: String = "",
    @SerialName("client_name_en")
    val clientNameEn: String = "",
    @SerialName("client_contact_no")
    val clientContactNo: String = "",
    val guid: String = "",
    @SerialName("total_workorder_accounts")
    val totalWorkOrderAccounts: Int,
    val lat: Double = -0.1,
    val lon: Double = -0.1,
    @SerialName("customer_name")
    val customerName: String,
    @SerialName("citizen_id")
    val citizenId: String,
    @SerialName("plan_created_by")
    val planCreatedBy: String,
    @SerialName("plan_created_date")
    val planCreatedDate: Instant,
    @SerialName("plan_updated_by")
    val planUpdatedBy: String,
    @SerialName("plan_updated_date")
    val planUpdatedDate: Instant? = null,
)
