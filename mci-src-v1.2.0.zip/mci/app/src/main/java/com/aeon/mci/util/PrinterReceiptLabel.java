package com.aeon.mci.util;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.aeon.mci.Config;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PrinterReceiptLabel {

    private static final String TAG = PrinterReceiptLabel.class.getSimpleName();

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForAeon(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create notice label for AEON.");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format(locale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("PCX 0 20 !<AEON017.PCX%n"));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 100 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 100 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 12 ถนนศรีนครินทร์ แขวงสวนหลวง เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 Modernform Tower, 12%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 4 5 195 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 200 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(locale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(locale, "บริษัท อิออน ธนสินทรัพย์ (ไทยแลนด์) จำกัด (มหาชน)%n"));
        sb.append(String.format(locale, "AEON Thana Sinsap (Thailand) Public Company Limited%n"));
        sb.append(String.format("ENDML%n"));
        line += 88;

        sb.append(String.format("%n"));
        line += 16;

        if (reprintNo > 0) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 20 15 410 %d Reprint (%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 20 15 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 40;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 20 20 150 %d ใบรับฝากชำระเงิน%n", line));
        line += 35;
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 20 170 %d DEPOSIT SLIP%n", line));
        line += 75;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerName));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 457 %d %s%n", line, customerId));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 495;
                    break;
                case 5:
                    amountPosition = 475;
                    break;
                case 6:
                    amountPosition = 450;
                    break;
                case 7:
                case 8:
                    amountPosition = 410;
                    break;
                case 9:
                    amountPosition = 390;
                    break;
                case 10:
                    amountPosition = 370;
                    break;
                case 11:
                case 12:
                    amountPosition = 330;
                    break;
            }
        }
        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 25 30 %d %d %s%n", amountPosition, line - 60, amount));
        line += 80;

        if (!isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForAeon2(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create notice label for AEON.");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String maskedCustomerId = customerId;
        if (customerId != null && customerId.length() == 13) {
            maskedCustomerId = customerId.substring(0, 4) + "XXXXX" + customerId.substring(9);
        }
        String customerNameTh = "";
        String customerNameEn = "";
        if (customerName != null) {
            String[] customerNames = customerName.split("/");
            customerNameTh = customerNames.length > 0 ? customerNames[0] : "";
            customerNameEn = customerNames.length > 1 ? customerNames[1] : "";
        }

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format(locale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("PCX 0 20 !<AEON017.PCX%n"));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 100 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 100 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 12 ถนนศรีนครินทร์ แขวงสวนหลวง เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 Modernform Tower, 12%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 4 5 195 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 200 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(locale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(locale, "บริษัท อิออน ธนสินทรัพย์ (ไทยแลนด์) จำกัด (มหาชน)%n"));
        sb.append(String.format(locale, "AEON Thana Sinsap (Thailand) Public Company Limited%n"));
        sb.append(String.format("ENDML%n"));
        line += 88;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;

        if (reprintNo > 0) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 480 %d Reprint (%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 25;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 0 %d บริษัท อิออน ธนสินทรัพย์ (ไทยแลนด์)%n", line));
        line += 95;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 220 %d ใบรับฝากชำระเงิน%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 230 %d DEPOSIT SLIP%n", line));
        line += 45;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameTh));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 440 %d %s%n", line, maskedCustomerId));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameEn));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 35;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 475;
                    break;
                case 5:
                    amountPosition = 450;
                    break;
                case 6:
                    amountPosition = 410;
                    break;
                case 7:
                case 8:
                    amountPosition = 390;
                    break;
                case 9:
                    amountPosition = 370;
                    break;
                case 10:
                    amountPosition = 330;
                    break;
                case 11:
                case 12:
                    amountPosition = 310;
                    break;
            }
        }
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 %d %d %s%n", amountPosition + 80, line, amount));
        line += 80;

        if (!isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForAeon3(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create notice label for AEON.");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String maskedCustomerId = customerId;
        if (customerId != null && customerId.length() == 13) {
            maskedCustomerId = customerId.substring(0, 4) + "XXXXX" + customerId.substring(9);
        }
        String customerNameTh = "";
        String customerNameEn = "";
        if (customerName != null) {
            String[] customerNames = customerName.split("/");
            customerNameTh = customerNames.length > 0 ? customerNames[0] : "";
            customerNameEn = customerNames.length > 1 ? customerNames[1] : "";
        }

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format(locale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("PCX 0 20 !<AEON017.PCX%n"));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 100 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 100 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 11 ถนนศรีนครินทร์ แขวงพัฒนาการ เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d 699 Modernform Tower, 11%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 4 5 195 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 200 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 6 100 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(locale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(locale, "บริษัท อิออน ธนสินทรัพย์ (ไทยแลนด์) จำกัด (มหาชน)%n"));
        sb.append(String.format(locale, "AEON Thana Sinsap (Thailand) Public Company Limited%n"));
        sb.append(String.format("ENDML%n"));
        line += 88;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;

        if (reprintNo > 0) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 480 %d Reprint (%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 25;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 220 %d ใบรับฝากชำระเงิน%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 230 %d DEPOSIT SLIP%n", line));
        line += 45;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameTh));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 440 %d %s%n", line, maskedCustomerId));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameEn));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 35;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 0 %d บริษัท อิออน ธนสินทรัพย์ (ไทยแลนด์)%n", line));
        line += 95;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 475;
                    break;
                case 5:
                    amountPosition = 450;
                    break;
                case 6:
                    amountPosition = 410;
                    break;
                case 7:
                case 8:
                    amountPosition = 390;
                    break;
                case 9:
                    amountPosition = 370;
                    break;
                case 10:
                    amountPosition = 330;
                    break;
                case 11:
                case 12:
                    amountPosition = 310;
                    break;
            }
        }
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 25 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 %d %d %s%n", amountPosition + 80, line, amount));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 50;

        if (!isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

//        line += (isCopyPart ? 70 : 50);
        if (isCopyPart) {
            line += 75;
            sb.append(String.format(locale, "LINE 0 %d 580 %d 1%n", line, line));
        }

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForOtherClient(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create receipt label for other client.");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String clientNameTh = data.getString(Config.EXTRAS_CLIENT_NAME_TH);
        String clientNameEn = data.getString(Config.EXTRAS_CLIENT_NAME_EN);
        if (TextUtils.isEmpty(clientNameTh) || TextUtils.equals(clientNameTh.toLowerCase(), "null")) {
            clientNameTh = "-";
        }
        if (TextUtils.isEmpty(clientNameEn) || TextUtils.equals(clientNameEn.toLowerCase(), "null")) {
            clientNameEn = "-";
        }

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;
        Locale locale = new Locale.Builder().setLanguage("th").setRegion("TH").build();
        StringBuilder sb = new StringBuilder();

        sb.append(String.format(locale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 12 0 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(locale, "T TAH06PT.CPF 0 0 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 12 ถนนศรีนครินทร์ แขวงสวนหลวง เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d 699 Modernform Tower, 12%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 5 5 120 %d th%n", line - 3));
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 130 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(locale, "ST ANGSANA.FNT 6 6 0 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(locale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(locale, "%s%n", TextUtils.isEmpty(clientNameTh) ? "-" : clientNameTh));
        sb.append(String.format(locale, "%s%n", TextUtils.isEmpty(clientNameEn) ? "-" : clientNameEn));
        sb.append(String.format("ENDML%n"));
        line += 88;

        if (reprintNo > 0) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 20 15 410 %d Reprint(%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 20 15 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 40;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 20 20 150 %d ใบรับฝากชำระเงิน%n", line));
        line += 35;
        sb.append(String.format(locale, "ST ANGSANA.FNT 20 20 170 %d DEPOSIT SLIP%n", line));
        line += 75;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerName));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 457 %d %s%n", line, customerId));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 495;
                    break;
                case 5:
                    amountPosition = 475;
                    break;
                case 6:
                    amountPosition = 450;
                    break;
                case 7:
                case 8:
                    amountPosition = 410;
                    break;
                case 9:
                    amountPosition = 390;
                    break;
                case 10:
                    amountPosition = 370;
                    break;
                case 11:
                case 12:
                    amountPosition = 330;
                    break;
            }
        }
        sb.append(String.format(locale, "ST ANGSANA.FNT 12 12 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(locale, "ST ANGSANA.FNT 25 30 %d %d %s%n", amountPosition, line - 60, amount));
        line += 80;

        if (!isCopyPart) {
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(locale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForOtherClient2(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create receipt label for other client.");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String clientNameTh = data.getString(Config.EXTRAS_CLIENT_NAME_TH);
        String clientNameEn = data.getString(Config.EXTRAS_CLIENT_NAME_EN);

        String maskedCustomerId = customerId;
        if (customerId != null && customerId.length() == 13) {
            maskedCustomerId = customerId.substring(0, 4) + "XXXXX" + customerId.substring(9);
        }
        String customerNameTh = "";
        String customerNameEn = "";
        if (customerName != null) {
            String[] customerNames = customerName.split("/");
            customerNameTh = customerNames.length > 0 ? customerNames[0] : "";
            customerNameEn = customerNames.length > 1 ? customerNames[1] : "";
        }

        Locale thaiLocale = new Locale.Builder().setLanguage("th").setRegion("TH").build();

        String clientNameHeader;
        if (!TextUtils.isEmpty(clientNameTh) && clientNameTh.length() > 34) {
            String[] splitClientNameTh = clientNameTh.split("\\s+");
            if (splitClientNameTh.length > 3) {
                clientNameHeader = splitClientNameTh[0] + " " + splitClientNameTh[1] + " " + splitClientNameTh[2];
            } else {
                clientNameHeader = splitClientNameTh[0] + " " + splitClientNameTh[1];
            }
        } else {
            clientNameHeader = clientNameTh;
        }

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;

        StringBuilder sb = new StringBuilder();

        sb.append(String.format(thaiLocale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 12 0 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(thaiLocale, "T TAH06PT.CPF 0 0 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 12 ถนนศรีนครินทร์ แขวงสวนหลวง เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d 699 Modernform Tower, 12%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 5 5 120 %d th%n", line - 3));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 130 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(thaiLocale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(thaiLocale, "%s%n", TextUtils.isEmpty(clientNameTh) ? "-" : clientNameTh));
        sb.append(String.format(thaiLocale, "%s%n", TextUtils.isEmpty(clientNameEn) ? "-" : clientNameEn));
        sb.append(String.format("ENDML%n"));
        line += 88;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;

        if (reprintNo > 0) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 480 %d Reprint(%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 25;
        }

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 0 %d %s%n", line, clientNameHeader));
        line += 95;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 220 %d ใบรับฝากชำระเงิน%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 230 %d DEPOSIT SLIP%n", line));
        line += 45;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameTh));

        int startPositionCustomerId = 440;
        if (maskedCustomerId != null) {
            if (maskedCustomerId.length() > 13) {
                startPositionCustomerId = startPositionCustomerId - (int) (maskedCustomerId.length() * 3.0);
            }
            if (maskedCustomerId.length() < 13) {
                startPositionCustomerId = startPositionCustomerId + (int) (maskedCustomerId.length() * 3.0);
            }
        }
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 %d %d %s%n", startPositionCustomerId, line, maskedCustomerId));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameEn));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 35;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 50;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 475;
                    break;
                case 5:
                    amountPosition = 450;
                    break;
                case 6:
                    amountPosition = 410;
                    break;
                case 7:
                case 8:
                    amountPosition = 390;
                    break;
                case 9:
                    amountPosition = 370;
                    break;
                case 10:
                    amountPosition = 330;
                    break;
                case 11:
                case 12:
                    amountPosition = 310;
                    break;
            }
        }
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 %d %d %s%n", amountPosition + 80, line, amount));
        line += 80;

        if (!isCopyPart) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static String createLabelForOtherClient3(Bundle data, boolean isCopyPart) {
        Log.d(TAG, "Create receipt label for other client.");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
        int updatedDate = data.getInt(Config.EXTRAS_UPDATED_DATE);
        String printDate = sdf.format(new Date(updatedDate * 1000L));
        String receiptNo = data.getString(Config.EXTRAS_RECEIPT_NO);
        int reprintNo = data.getInt(Config.EXTRAS_REPRINT_NO);
        String amount = data.getString(Config.EXTRAS_COLLECTED_AMOUNT);
        String orderNo = data.getString(Config.EXTRAS_ORDER_NO);
        String agreementNo = data.getString(Config.EXTRAS_AGREEMENT_NO);
        String customerId = data.getString(Config.EXTRAS_CUSTOMER_ID);
        String customerName = data.getString(Config.EXTRAS_CUSTOMER_NAME);
        String empCode = data.getString(Config.EXTRAS_EMPLOYEE_CODE);
        String empFullName = data.getString(Config.EXTRAS_EMPLOYEE_FULL_NAME);
        String clientNameTh = data.getString(Config.EXTRAS_CLIENT_NAME_TH);
        String clientNameEn = data.getString(Config.EXTRAS_CLIENT_NAME_EN);

        String maskedCustomerId = customerId;
        if (customerId != null && customerId.length() == 13) {
            maskedCustomerId = customerId.substring(0, 4) + "XXXXX" + customerId.substring(9);
        }
        String customerNameTh = "";
        String customerNameEn = "";
        if (customerName != null) {
            String[] customerNames = customerName.split("/");
            customerNameTh = customerNames.length > 0 ? customerNames[0] : "";
            customerNameEn = customerNames.length > 1 ? customerNames[1] : "";
        }

        Locale thaiLocale = new Locale.Builder().setLanguage("th").setRegion("TH").build();

        String clientNameHeader;
        if (!TextUtils.isEmpty(clientNameTh) && clientNameTh.length() > 34) {
            String[] splitClientNameTh = clientNameTh.split("\\s+");
            if (splitClientNameTh.length > 3) {
                clientNameHeader = splitClientNameTh[0] + " " + splitClientNameTh[1] + " " + splitClientNameTh[2];
            } else {
                clientNameHeader = splitClientNameTh[0] + " " + splitClientNameTh[1];
            }
        } else {
            clientNameHeader = clientNameTh;
        }

        int labelHeight = isCopyPart ? 1200 : 1250;
        int line = 0;

        StringBuilder sb = new StringBuilder();

        sb.append(String.format(thaiLocale, "! 0 200 200 %d 1%n", labelHeight));
        sb.append(String.format("ON-FEED IGNORE%n"));
        sb.append(String.format("JOURNAL%n"));
        sb.append(String.format("COUNTRY CP874%n"));
        sb.append(String.format("TONE 25%n"));

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 12 0 %d บริษัท เอซีเอส เซอร์วิสซิ่ง (ประเทศไทย) จำกัด%n", line));
        line += 35;
        sb.append(String.format(thaiLocale, "T TAH06PT.CPF 0 0 %d ACS Servicing (Thailand) Company Limited %n", line));
        line += 20;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d 699 อาคารโมเดอร์นฟอร์มทาวเวอร์ ชั้น 11 ถนนศรีนครินทร์ แขวงพัฒนาการ เขตสวนหลวง กรุงเทพฯ 10250 โทรศัพท์ 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d 699 Modernform Tower, 11%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 5 5 120 %d th%n", line - 3));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 130 %d Floor, Srinakarin Road, Suanluang, Bangkok 10250 Tel. 0-2769-1700%n", line));
        line += 16;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 6 6 0 %d ทะเบียนเลขที่ 0105550028122%n", line));
        line += 60;

        sb.append(String.format("ML 24%n"));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d%n", line));
        sb.append(String.format(thaiLocale, "รับชำระเงินในนาม/RECEIVE FOR%n"));
        sb.append(String.format(thaiLocale, "%s%n", TextUtils.isEmpty(clientNameTh) ? "-" : clientNameTh));
        sb.append(String.format(thaiLocale, "%s%n", TextUtils.isEmpty(clientNameEn) ? "-" : clientNameEn));
        sb.append(String.format("ENDML%n"));
        line += 88;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;

        if (reprintNo > 0) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 480 %d Reprint(%d)%n", line, reprintNo));
        }
        if (isCopyPart) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Copy%n", line));
        }
        if (isCopyPart || reprintNo > 0) {
            line += 25;
        }

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 220 %d ใบรับฝากชำระเงิน%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 230 %d DEPOSIT SLIP%n", line));
        line += 45;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d เลขที่ใบรับเงิน: %s%n", line, receiptNo));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d COLID: %s%n", line, empCode));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 367 %d วันที่/Date: %s%n", line, printDate));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d JOB ID: %s%n", line, orderNo));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ชื่อลูกค้า/Customer Name:%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 340 %d เลขที่บัตรประชาชน/ID Card No.%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameTh));

        int startPositionCustomerId = 440;
        if (maskedCustomerId != null) {
            if (maskedCustomerId.length() > 13) {
                startPositionCustomerId = startPositionCustomerId - (int) (maskedCustomerId.length() * 3.0);
            }
            if (maskedCustomerId.length() < 13) {
                startPositionCustomerId = startPositionCustomerId + (int) (maskedCustomerId.length() * 3.0);
            }
        }
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 %d %d %s%n", startPositionCustomerId, line, maskedCustomerId));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d %s%n", line, customerNameEn));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d วิธีการชำระเงิน/PAYMENT METHOD%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d [   ] เงินสด/CASH%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d [   ] เช็คเลขที่/CHEQUE NO._____________________%n", line));
        line += 35;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ธนาคาร/BANK___________________  ลงวันที่/DATE___________________%n", line));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 30;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 0 %d %s%n", line, clientNameHeader));
        line += 95;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d เลขที่สัญญา/เลขที่อ้างอิง%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 350 %d จำนวนเงิน (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Agreement No./Reference No.%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 350 %d AMOUNT (Included VAT)%n", line));
        line += 25;
        int startDataLine = line;
        line += 50;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 0 %d %s%n", startDataLine, agreementNo));
        line += 25;

        int amountPosition = 330;
        if (!TextUtils.isEmpty(amount)) {
            switch (amount.length()) {
                case 4:
                    amountPosition = 475;
                    break;
                case 5:
                    amountPosition = 450;
                    break;
                case 6:
                    amountPosition = 410;
                    break;
                case 7:
                case 8:
                    amountPosition = 390;
                    break;
                case 9:
                    amountPosition = 370;
                    break;
                case 10:
                    amountPosition = 330;
                    break;
                case 11:
                case 12:
                    amountPosition = 310;
                    break;
            }
        }
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 20 25 %d %d %s%n", amountPosition + 40, startDataLine, amount));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d จำนวนเงินทั้งหมด (รวมภาษีมูลค่าเพิ่ม)%n", line));
        line += 25;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d TOTAL AMOUNT (Included VAT)%n", line));
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 %d %d %s%n", amountPosition + 80, line, amount));
        line += 25;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _%n", line));
        line += 50;

        if (!isCopyPart) {
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ผู้ชำระเงิน ______________________%n", line));
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d โทรศัพท์มือถือ __________________%n", line));
            line += 30;
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d Customer%n", line));
            sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d Mobile%n", line));
            line += 50;
        }

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d ผู้รับเงิน ________________________%n", line));
        line += 30;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 290 %d Collector (%s)%n", line, empFullName));
        line += 50;

        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ใบรับฝากชำระเงินฉบับนี้ จะถูกต้องสมบูรณ์ต่อเมื่อมีการลงลายมือชื่อของ%n", line));
        line += 30;
        sb.append(String.format(thaiLocale, "ST ANGSANA.FNT 10 10 0 %d ผู้รับเงินอย่างครบถ้วน%n", line));

//        line += (isCopyPart ? 70 : 50);
        if (isCopyPart) {
            line += 75;
            sb.append(String.format(thaiLocale, "LINE 0 %d 580 %d 1%n", line, line));
        }

        sb.append(String.format("PRINT%n"));

        return sb.toString();
    }
}
