package com.aeon.mci.ui.order

import android.accounts.AccountManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.database.Cursor
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.text.method.ScrollingMovementMethod
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.loader.app.LoaderManager
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import com.aeon.mci.BuildConfig
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.databinding.ActivityOrderBinding
import com.aeon.mci.model.CollectorResult
import com.aeon.mci.model.Order
import com.aeon.mci.persistence.Customer
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.syncadapter.BackendVolley
import com.aeon.mci.ui.DialogHelper
import com.aeon.mci.ui.PrintActivity
import com.aeon.mci.ui.result.EditResultDialogFragment
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.PrinterUtils
import com.aeon.mci.util.inReleaseMode
import com.aeon.mci.util.setBackgroundColor
import com.aeon.mci.util.setStatusBarColor
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import timber.log.Timber
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@AndroidEntryPoint
class OrderActivity : PrintActivity(),
        LoaderManager.LoaderCallbacks<Cursor>,
        EditResultDialogFragment.EditResultDialogListener {

    private lateinit var mCustomer: Customer
    private lateinit var mOrder: Order
    private var mCollectorResult: CollectorResult? = null

    private val mEmpCode: String
        get() = AccountUtils.getEmployeeCode(this)

    private val mEmpFullName: String
        get() {
            val firstName = AccountUtils.getEmployeeName(this)
            val lastName = AccountUtils.getEmployeeSurname(this)
            return "$firstName $lastName"
        }

    private var mAllowPrint = false
    private var mPrintNotice = false
    private var mPrintReceipt = false
    private var mIncompleteTask: Boolean = false
    private var mHelper: DialogHelper? = null

    private lateinit var binding: ActivityOrderBinding

    private lateinit var observer: OrderObserver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        inReleaseMode {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requireNotNull(intent.extras).apply {
            mIncompleteTask = getBoolean(Config.EXTRAS_INCOMPLETE_TASK, false)
            mCustomer = requireNotNull(getParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER))
            mOrder = requireNotNull(getParcelable(Config.BUNDLE_ARG_MODEL_ORDER))
        }

        setSupportActionBar(binding.toolbar)

        if (mIncompleteTask) {
            supportActionBar?.setBackgroundColor(R.color.assign)
            setStatusBarColor(R.color.assign_dark)
        } else {
            when (mOrder.jobStatus) {
                "89", "97", "98", "99" -> {
                    supportActionBar?.setBackgroundColor(R.color.color_canceled_assignment_primary)
                    setStatusBarColor(R.color.color_canceled_assignment_primary_dark)
                }
                else -> if (mOrder.updatedFlag == 1) {
                    supportActionBar?.setBackgroundColor(R.color.color_issued_assignment_primary)
                    setStatusBarColor(R.color.color_issued_assignment_primary_dark)
                } else {
                    supportActionBar?.setBackgroundColor(R.color.complete)
                    setStatusBarColor(R.color.complete_dark)
                }
            }
        }
        observer = OrderObserver(Handler())
        LoaderManager.getInstance(this).initLoader(0, null, this)
    }

    override fun onResume() {
        super.onResume()
        contentResolver.registerContentObserver(OrderContract.Orders.CONTENT_URI, true, observer)
    }

    override fun onPause() {
        contentResolver.unregisterContentObserver(observer)
        super.onPause()
    }

    override fun onCreateLoader(id: Int, args: Bundle?): Loader<Cursor> {
        return CursorLoader(
                applicationContext,
                OrderContract.Orders.CONTENT_URI,
                OrderContract.Orders.NORMAL_PROJECTION,
                "${OrderContract.Orders.ORDER_NO} = ?",
                arrayOf(mOrder!!.id),
                "CAST (${OrderContract.Orders.ORDER_NO} AS INTEGER) DESC"
        )
    }

    override fun onLoadFinished(loader: Loader<Cursor>, cursor: Cursor?) {
        cursor?.moveToFirst().let {
            mOrder = Order().apply {
                id = cursor!!.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_NO))
                agreementNo = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_AGREEMENT_NO))
                customerId = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.CUSTOMER_IDCARD_NO))
                guid = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_GUID))
                description = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_DESCRIPTION))
                jobStatus = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_STATUS))
                priority = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_PRIORITY))
                surveyName = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_SURVEY_NAME))
                collectDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_COLLECT_DATE))
                collectAmount = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_COLLECT_AMOUNT))
                operatorName = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_OPERATOR_NAME))
                autoCallRemark = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_AUTOCALL_REMARK))
                delinquentStatus = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_DELINQUENT_STATUS))
                outstandingBalance = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_OUTSTANDING_BALANCE))
                penalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_PENALTY))
                currentBill = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_CURRENT_BILL))
                d1 = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D1))
                d1AddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D1_ADD_PENALTY))
                d2 = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D2))
                d2AddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D2_ADD_PENALTY))
                d3 = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D3))
                d3AddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D3_ADD_PENALTY))
                d4 = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D4))
                d4AddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D4_ADD_PENALTY))
                d5 = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D5))
                d5AddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_D5_ADD_PENALTY))
                totalDelinquent = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_TOTAL_DELINQUENT))
                totalAddPenalty = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY))
                minimumBill = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_MINIMUM_BILL))
                fullBill = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_FULL_BILL))
                resultCode = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.COLLECTOR_RESULT_CODE))
                resultCollectedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE))
                resultCollectedAmount = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT))
                resultPromisedDate = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_PROMISED_DATE))
                resultRemark = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_REMARK))
                taskType = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_TASK_TYPE))
                updatedFlag = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.SyncColumns.UPDATED_FLAG))
                resultSendToAutoCallFlag = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG))
                token = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_TOKEN))
                clientNameEn = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_CLIENT_NAME_EN))
                clientNameTh = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_CLIENT_NAME_TH))
                clientContactNo = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Orders.ORDER_CLIENT_CONTACT_NO))
            }
            updateViews(mOrder)
        }
    }

    override fun onLoaderReset(loader: Loader<Cursor>) {
        // Do nothing
    }

    private fun setActionBarBackground() {
        val color: Int = if (mIncompleteTask) {
            R.color.assign
        } else {
            when (mOrder.jobStatus) {
                "89", "97", "98", "99" -> R.color.color_canceled_assignment_primary
                else -> if (mOrder.updatedFlag == 1) {
                    R.color.color_issued_assignment_primary
                } else {
                    R.color.complete
                }
            }
        }
        supportActionBar?.setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this, color)))
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mIncompleteTask) {
            Timber.d("Prepare new assignment option menu.")
            if (TextUtils.equals(mOrder!!.taskType, "C")) {
                menu.findItem(R.id.action_publish_result).isVisible = false
                menu.findItem(R.id.action_canceled_order).isVisible = true
            }
        } else {
            Timber.d("Prepare done assignment option menu.")
            val pending = mOrder!!.updatedFlag == 1
            if (!pending) {
                menu.findItem(R.id.action_edit_result).isVisible = true
                menu.findItem(R.id.action_reprint).isVisible = mAllowPrint
                menu.findItem(R.id.action_pending_send_result).isVisible = false
                menu.findItem(R.id.action_canceled_order).isVisible = false
            } else {
                menu.findItem(R.id.action_pending_send_result).isVisible = true
                menu.findItem(R.id.action_canceled_order).isVisible = false
                menu.findItem(R.id.action_reprint).isVisible = false
                menu.findItem(R.id.action_edit_result).isVisible = false
            }
            when (mOrder!!.jobStatus) {
                "89", "97", "98", "99" -> {
                    menu.findItem(R.id.action_canceled_order).isVisible = true
                    menu.findItem(R.id.action_reprint).isVisible = false
                    menu.findItem(R.id.action_edit_result).isVisible = false
                    menu.findItem(R.id.action_pending_send_result).isVisible = false
                }
                else -> {
                }
            }
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        if (mIncompleteTask) {
            menuInflater.inflate(R.menu.order_new, menu)
        } else {
            menuInflater.inflate(R.menu.order_done, menu)
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_publish_result -> showEditResultDialog(false)
            R.id.action_edit_result -> showEditResultDialog(true)
            R.id.action_reprint -> showReprintConfirmationDialog()
            R.id.action_canceled_order -> Toast.makeText(this, R.string.order_toast_text_cancel, Toast.LENGTH_LONG).show()
            else -> {
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showReprintConfirmationDialog() {
//        var printing = ""
//        if (mPrintReceipt) {
//            printing = getString(R.string.order_reprint_receipt)
//        } else {
//            if (mPrintNotice) {
//                printing = getString(R.string.order_reprint_notice)
//                Timber.d("""
//                    Before print notice: Client(nameEn=${mOrder?.clientNameEn}
//                    nameTh=${mOrder?.clientNameTh}
//                    contactNo=${mOrder?.clientContactNo}
//                """.trimIndent())
//            }
//        }

        val reprintType: String = if (mPrintReceipt) {
            getString(R.string.order_reprint_receipt)
        } else {
            if (mPrintNotice) getString(R.string.order_reprint_notice) else ""
        }

        val dialog = AlertDialog.Builder(this)
                .setCancelable(false)
                .setMessage(getString(R.string.order_reprint_dialog_content, reprintType))
                .setNegativeButton(R.string.order_reprint_dialog_action_cancel, null)
                .setPositiveButton(R.string.order_reprint_dialog_action_ok) { dialogInterface, i ->
                    if (mCollectorResult!!.receipt == 0) {
                        val region = TextUtils.substring(mOrder!!.guid, 0, 2)
                        if (mOrder!!.agreementNo.length == 16 && !TextUtils.equals(region, "AE")) {
                            mHelper = DialogHelper(this@OrderActivity)
                            mHelper!!.showLoadingDialog("Retrieve agreement no.")
                            if (TextUtils.isEmpty(mOrder!!.token)) {
                                requestAccessToken(RequestTokenOps.FROM_WORK_ORDER_ID, mOrder!!.id)
                            } else {
                                requestAccessToken(RequestTokenOps.FROM_TOKEN, mOrder!!.token)
                            }
                        } else {
                            doAfterConfirmPrintReceipt()
                        }
                    } else {
                        if (mPrintNotice) {
                            val data = Bundle().apply {
                                val firstName = AccountUtils.getEmployeeName(applicationContext)
                                val lastName = AccountUtils.getEmployeeSurname(applicationContext)
                                putString(Config.EXTRAS_EMPLOYEE_FULL_NAME, "$firstName $lastName")
                                putString(Config.EXTRAS_CUSTOMER_NAME, mCustomer!!.name)
                                putString(Config.EXTRAS_CLIENT_NAME_EN, mOrder!!.clientNameEn)
                                putString(Config.EXTRAS_CLIENT_NAME_TH, mOrder!!.clientNameTh)
                                putString(Config.EXTRAS_CLIENT_CONTACT_NO, mOrder!!.clientContactNo)
                                putString(Config.EXTRAS_GUID, mOrder!!.guid)
                                putString(Config.EXTRAS_AGREEMENT_NO, mOrder!!.agreementNo)
                            }

                            PrinterUtils.printNotice(this@OrderActivity, data, mIncompleteTask)
                        }
                    }
                }
        dialog.show()
    }

    private fun showEditResultDialog(editable: Boolean) {
        val selected = ArrayList<Order>()
        selected.add(mOrder!!)
        val bundle = Bundle()
        bundle.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, mIncompleteTask)
        bundle.putBoolean(Config.BUNDLE_ARG_MULTIPLE_SELECTED, false)
        bundle.putBoolean(Config.BUNDLE_ARG_ALLOW_EDIT_RESULT, editable)
        bundle.putParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS, selected)
        //        bundle.putParcelable(Config.BUNDLE_ARG_MODEL_ORDER, mOrder);
        bundle.putParcelable(Config.EXTRAS_COLLECTOR_RESULT, mCollectorResult)

        val fragmentManager = supportFragmentManager
        val dialog = EditResultDialogFragment.newInstance(mOrder!!, mCollectorResult)
        dialog.setEditResultDialogListener(this)
        dialog.arguments = bundle
        dialog.isCancelable = false
        dialog.show(fragmentManager, "fragment_edit_result")
    }

    override fun onFinishEditResult(data: Intent) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Timber.d("on UI thread!!")
        }
        data.extras.let {
            Timber.d("Collector result is here!!!")
            saveResult(it!!)
        }
    }

    private fun updateViews(order: Order?) {
        mOrder = order!!
//        when (order!!.jobStatus) {
//            "89", "97", "98", "99" -> {
//                Timber.d("Update views, try to change status bar and action bar color.")
//                setupStatusBar()
//                setupActionBar()
//            }
//            else -> if (order.taskType == "C") {
//                Timber.d("Update views, try to change status bar and action bar color.")
//                setupStatusBar()
//                setupActionBar()
//            }
//        }
//        setupActionBar()
        setActionBar()
        setActionBarBackground()
        invalidateOptionsMenu()

        var agreementNo = order.agreementNo
        if (agreementNo.length == 16) {
            agreementNo = agreementNo.replace(agreementNo.substring(6, 12), "XXXXXX")
        }

        val df = DecimalFormat("##,###,##0.00")
        val outstandingBalance = order.outstandingBalance.toFloat() / 100
        val penalty = order.penalty.toFloat() / 100
        val currentBill = order.currentBill.toFloat() / 100
        val minimumBill = order.minimumBill.toFloat() / 100
        val fullBill = order.fullBill.toFloat() / 100
        val totalDelinquent = order.totalDelinquent.toFloat() / 100
        val totalDelinquentPenalty = order.totalAddPenalty.toFloat() / 100
        val d1 = order.d1.toFloat() / 100
        val d2 = order.d2.toFloat() / 100
        val d3 = order.d3.toFloat() / 100
        val d4 = order.d4.toFloat() / 100
        val d5 = order.d5.toFloat() / 100
        val d1AddPenalty = order.d1AddPenalty.toFloat() / 100
        val d2AddPenalty = order.d2AddPenalty.toFloat() / 100
        val d3AddPenalty = order.d3AddPenalty.toFloat() / 100
        val d4AddPenalty = order.d4AddPenalty.toFloat() / 100
        val d5AddPenalty = order.d5AddPenalty.toFloat() / 100

        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        val sdf2 = SimpleDateFormat("HH:mm", Locale.US)

        val collectDateTimestamp = order.collectDate
        val collectDate = Date(collectDateTimestamp * 1000L)
        val collectAmount = order.collectAmount.toFloat() / 100

        binding.orderContent.apply {
            orderAgreementNo.text = agreementNo
            orderAgreementDescription.text = order.description.ifEmpty { getString(R.string.no_information) }
            orderOperator.text = order.operatorName
            orderOutstandingBalance.text = df.format(outstandingBalance.toDouble())
            orderCurrentBill.text = df.format(currentBill.toDouble())
            orderMinimumBill.text = df.format(minimumBill.toDouble())
            orderFullBill.text = df.format(fullBill.toDouble())
            orderDelinquentStatus.text = order.delinquentStatus.toString()
            orderTotalDelinquent.text = df.format(totalDelinquent.toDouble())
            orderDelinquentPenalty.text = df.format(totalDelinquentPenalty.toDouble())
            orderD1.text = df.format(d1.toDouble())
            orderD1AddPenalty.text = df.format(d1AddPenalty.toDouble())
            orderD2.text = df.format(d2.toDouble())
            orderD2AddPenalty.text = df.format(d2AddPenalty.toDouble())
            orderD3.text = df.format(d3.toDouble())
            orderD3AddPenalty.text = df.format(d3AddPenalty.toDouble())
            orderD4.text = df.format(d4.toDouble())
            orderD4AddPenalty.text = df.format(d4AddPenalty.toDouble())
            orderD5.text = df.format(d5.toDouble())
            orderD5AddPenalty.text = df.format(d5AddPenalty.toDouble())
            orderPenalty.text = df.format(penalty.toDouble())
            orderSurveyName.text = order.surveyName
            orderCollectDate.text = sdf.format(collectDate)
            orderCollectTime.text = sdf2.format(collectDate)
            orderCollectAmount.text = df.format(collectAmount.toDouble())
            orderAutoCallRemark.apply {
                text = if (order.autoCallRemark.isEmpty()) "-" else order.autoCallRemark
                movementMethod = ScrollingMovementMethod.getInstance()
            }

            if (mIncompleteTask.not().and(order.resultCode.isNullOrEmpty().not())) {
                orderLayoutResult.visibility = View.VISIBLE
                orderLayoutCollected.visibility = View.VISIBLE
                orderLayoutResultName.visibility = View.VISIBLE
                orderLayoutResultRemark.visibility = View.VISIBLE

                contentResolver.query(
                        OrderContract.CollectorResults.CONTENT_URI,
                        OrderContract.CollectorResults.NORMAR_PROJECTION,
                        OrderContract.CollectorResults.COLLECTOR_RESULT_CODE + " = ?",
                        arrayOf(order.resultCode), null).let {

                    it!!.moveToFirst().let { _ ->
                        mCollectorResult = CollectorResult().apply {
                            code = it.getString(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_CODE))
                            name = it.getString(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_NAME))
                            type = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_TYPE))
                            receipt = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_RECEIPT))
                            letter = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_PRINT_LETTER))
                            money = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_GET_MONEY))
                            max = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_MAX_PAYMENT))
                            min = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_MIN_PAYMENT))
                            remark = it.getInt(it.getColumnIndexOrThrow(OrderContract.CollectorResults.COLLECTOR_RESULT_REQUIRED_REMARK))
                        }
                        mPrintNotice = mCollectorResult!!.letter == 0
                        mPrintReceipt = mCollectorResult!!.receipt == 0
                        mAllowPrint = mPrintNotice || mPrintReceipt
                    }
                    it.close()
                }

                val collectedDateTimestamp = order.resultCollectedDate
                val collectedDate = Date(collectedDateTimestamp * 1000L)
                val collectedAmount = order.resultCollectedAmount.toFloat() / 100

                orderResultName.text = mCollectorResult!!.name
                orderCollectedDate.text = sdf.format(collectedDate)
                orderCollectedTime.text = sdf2.format(collectedDate)
                if (order.resultPromisedDate != 0) {
                    val promisedDateTimestamp = order.resultPromisedDate
                    val promisedDate = Date(promisedDateTimestamp * 1000L)

                    orderLayoutPromised.visibility = View.VISIBLE
                    orderPromisedDate.text = sdf.format(promisedDate)
                    orderPromisedTime.text = sdf2.format(promisedDate)
                }
                orderCollectedAmount.text = df.format(collectedAmount.toDouble())
                orderResultRemark.apply {
                    text = if (order.resultRemark.isEmpty()) "-" else order.resultRemark
                    movementMethod = ScrollingMovementMethod.getInstance()
                }
            }
        }
    }

    private fun doAfterConfirmPrintReceipt() {
        val updatedDate = (System.currentTimeMillis() / 1000L).toInt()
        val currencyFormat = DecimalFormat("##,###,##0.00")
        val receiptNo = getReceiptNo(true)
        val reprintNo = reprintNo
        val amount = mOrder!!.resultCollectedAmount.toFloat() / 100

        saveReceipt(receiptNo, mOrder!!.resultCollectedAmount, "R",
                mOrder!!.guid, mOrder!!.agreementNo, updatedDate)
        requestManualReceiptDataSync()

        val receiptData = Bundle()
        val collectorName = AccountUtils.getEmployeeName(this)
        val collectorSurname = AccountUtils.getEmployeeSurname(this)
        receiptData.putString(Config.EXTRAS_EMPLOYEE_FULL_NAME, "$collectorName $collectorSurname")
        receiptData.putString(Config.EXTRAS_CUSTOMER_NAME, mCustomer!!.name)
        receiptData.putString(Config.EXTRAS_CLIENT_NAME_EN, mOrder!!.clientNameEn)
        receiptData.putString(Config.EXTRAS_CLIENT_NAME_TH, mOrder!!.clientNameTh)
        receiptData.putString(Config.EXTRAS_GUID, mOrder!!.guid)
        receiptData.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, mIncompleteTask)
        receiptData.putString(Config.EXTRAS_EMPLOYEE_CODE, mEmpCode)
        receiptData.putString(Config.EXTRAS_CUSTOMER_ID, mOrder!!.customerId)
        receiptData.putString(Config.EXTRAS_CUSTOMER_NAME, mCustomer!!.name)
        receiptData.putString(Config.EXTRAS_ORDER_NO, mOrder!!.id)
        if (TextUtils.isEmpty(mOrder!!.agreementNoFullPan)) {
            receiptData.putString(Config.EXTRAS_AGREEMENT_NO, mOrder!!.agreementNo)
        } else {
            receiptData.putString(Config.EXTRAS_AGREEMENT_NO, mOrder!!.agreementNoFullPan)
        }
        receiptData.putString(Config.EXTRAS_RECEIPT_NO, receiptNo)
        receiptData.putString(Config.EXTRAS_COLLECTED_AMOUNT, currencyFormat.format(amount.toDouble()))
        receiptData.putInt(Config.EXTRAS_UPDATED_DATE, updatedDate)
        receiptData.putInt(Config.EXTRAS_REPRINT_NO, reprintNo)
        PrinterUtils.printReceipt(this@OrderActivity, receiptData, false)
    }

    object RequestTokenOps {
        const val FROM_TOKEN = 0
        const val FROM_WORK_ORDER_ID = 1
    }

    private fun requestAccessToken(ops: Int, param: String) {
        Timber.d("Request access token.")
        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("auth")
                .appendPath("token")
        val url = builder.build().toString()
        val accountManager = AccountManager.get(applicationContext)
        val account = AccountUtils.getActiveAccount(applicationContext)
        val refreshToken = accountManager.peekAuthToken(account, Config.AUTHTOKEN_TYPE_REFRESH_TOKEN)
        val imei = accountManager.getUserData(account, Config.BUNDLE_ARG_AUTH_DEVICE_IMEI)
        val params = JSONObject()
        params.put("grant_type", "refresh_token")
        params.put("client_id", imei)
        params.put("refresh_token", refreshToken)
        val request = JsonObjectRequest(Request.Method.POST, url, params,
                Response.Listener { response ->
                    val accessToken = response.getString("access_token")
                    if (accessToken.isNotBlank()) {
                        when (ops) {
                            RequestTokenOps.FROM_TOKEN -> detokenFullPan(ops, accessToken, param)
                            RequestTokenOps.FROM_WORK_ORDER_ID -> detokenFullPan(ops, accessToken, param)
                        }
                    }
                },
                Response.ErrorListener {  })
        BackendVolley.init(applicationContext)
        BackendVolley.addToRequestQueue(request)
    }

    private fun detokenFullPan(ops: Int, accessToken: String, param: String) {
        Timber.d("Request full-pan from param: $param")
        if (param.isEmpty()) {
            return
        }

        val builder = Uri.Builder()
        builder.scheme("https")
                .authority(BuildConfig.SERVER_HOST_NAME)
                .appendPath("mci-core")
                .appendPath("v1")
                .appendPath("pci-gateway")
                .appendPath("de-token")
                .appendPath(
                        when (ops) {
                            RequestTokenOps.FROM_TOKEN -> "token"
                            RequestTokenOps.FROM_WORK_ORDER_ID -> "work-order"
                            else -> ""
                        }
                )
                .appendPath(param)
                .appendPath("full-pan")
        val url = builder.build().toString()

        val request = object : JsonObjectRequest(Request.Method.GET, url, null,
                Response.Listener {
                    if (it.getString("RespCode") == "00" && it.getString("RespDesp") == "Success") {
                        val agreementNo = it.getString("PlnTxt")
                        mOrder!!.agreementNoFullPan = agreementNo
                        Timber.i("Successfully get agreement no full-pan: $agreementNo")
                        mHelper?.dismissLoadingDialog()
                        doAfterConfirmPrintReceipt()
                    }
                },
                Response.ErrorListener {
                    Timber.e("Error when detoken full-pan from token: response=${it.networkResponse}")
                    mHelper?.dismissLoadingDialog()
                    doAfterConfirmPrintReceipt()
                }) {

            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $accessToken"
                return headers
            }
        }
        BackendVolley.init(applicationContext)
        BackendVolley.addToRequestQueue(request)
    }

    inner class OrderObserver(handler: Handler) : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            LoaderManager.getInstance(this@OrderActivity)
                    .restartLoader(0, null, this@OrderActivity)
//            supportLoaderManager.restartLoader(0, null, this@OrderActivity)
//            super.onChange(selfChange, uri)
        }
    }

    companion object {
        private const val EXTRA_ORDER_ID = "ORDER_ID"
        private const val EXTRA_CUSTOMER = "CUSTOMER"
        private const val EXTRA_IS_COMPLETE = "IS_COMPLETE"

        fun starterIntent(
                context: Context,
                orderId: String,
                customer: Customer,
                isComplete: Boolean
        ): Intent {
            return Intent(context, OrderActivity::class.java).apply {
                putExtra(EXTRA_ORDER_ID, orderId)
                putExtra(EXTRA_CUSTOMER, customer)
                putExtra(EXTRA_IS_COMPLETE, isComplete)
            }
        }
    }
}
