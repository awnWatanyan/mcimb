package com.aeon.mci.shared.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
        tableName = "collector_results",
        indices = [Index(value = arrayOf("collector_result_code"), unique = true)]
)
data class CollectorResultEntity(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "collector_result_id")
        val collectorResultId: Int,

        @ColumnInfo(name = "collector_result_code")
        val code: String,

        @ColumnInfo(name = "collector_result_name")
        val name: String,

        /**
         * Flag collector result type (0 loop, 1 end).
         */
        @ColumnInfo(name = "collector_result_type")
        val type: Int,

        /**
         * Flag print receipt (0 print, 1 not print).
         */
        @ColumnInfo(name = "collector_result_print_receipt")
        val printReceipt: Int,

        /**
         * Flag print letter (0 print, 1 not print).
         */
        @ColumnInfo(name = "collector_result_print_letter")
        val printLetter: Int,

        /**
         * Flag require get money (0 get money, 1 not to get money).
         */
        @ColumnInfo(name = "collector_result_get_money")
        val getMoney: Int,

        /**
         * Flag maximum payment status
         * (1 nothing, 2 minimum bill, 3 full bill, 4 amount of bill, 5 = 0, 6 = 1).
         */
        @ColumnInfo(name = "collector_result_max_payment")
        val maxPayment: Int,

        /**
         * Flag minimum payment status
         * (1 nothing, 2 minimum bill, 3 full bill, 4 amount of bill, 5 = 0, 6 = 1).
         */
        @ColumnInfo(name = "collector_result_min_payment")
        val minPayment: Int,

        /**
         * Flag required remark (0 required, 1 not required).
         */
        @ColumnInfo(name = "collector_result_required_remark")
        val requireRemark: Int,

        /**
         * Priority of collector result (1 -> 5 less is more important).
         */
        @ColumnInfo(name = "collector_result_grouping_order")
        val grouping: Int,

        /**
         * Flag status is used (1 is used, 2 not used).
         */
        @ColumnInfo(name = "collector_result_status")
        val status: Int,

        /**
         * The hashcode of the data used to compare with data from webservice.
         */
        @ColumnInfo(name = "collector_result_import_hashcode")
        val hashcode: String,

        @ColumnInfo(name = "collector_result_group_name")
        val groupName: String
)