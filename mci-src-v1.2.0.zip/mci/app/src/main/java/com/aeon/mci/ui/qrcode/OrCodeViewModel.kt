package com.aeon.mci.ui.qrcode

import androidx.lifecycle.ViewModel
import java.math.BigDecimal

class OrCodeViewModel constructor(
        state: QrCodeViewState
) : ViewModel() {

    val customerId: String = state.customerId
    val agreementNo: String = state.agreementNo
    val description: String = state.description
    val amount: BigDecimal = state.amount
    val collectorId: String = state.collectorId
    val token: String = state.token

}