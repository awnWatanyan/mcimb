package com.aeon.mci.network

import com.aeon.mci.network.model.NetworkCustomer
import com.aeon.mci.network.model.User

interface MciNetworkDataSource {

    suspend fun login(username: String, password: String, deviceImei: String): List<User>

    suspend fun getTasks(employeeCode: String, deviceImei: String): List<NetworkCustomer>
}