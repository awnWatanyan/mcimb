package com.aeon.mci.shared.data.db

class CustomerRepository constructor(
        private val customerDao: CustomerDao
) {

    fun getAssignTask() = customerDao.getAssignTask()
}