package com.aeon.mci.ui.settings

import android.bluetooth.BluetoothAdapter
import android.os.Bundle
import android.os.ParcelUuid
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.aeon.mci.R
import com.aeon.mci.util.AccountUtils

class PrinterPreferenceFragment : PreferenceFragmentCompat() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.pref_printer, rootKey)

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter != null) {
            val pairedDevices = bluetoothAdapter.bondedDevices
            if (pairedDevices != null) {
                val entries = arrayListOf<CharSequence>().apply { add("No Devices") }
                val entryValues = arrayListOf<CharSequence>().apply { add("") }
                if (pairedDevices.isNotEmpty()) {
                    entries.clear()
                    entryValues.clear()
                    pairedDevices.forEach { bluetoothDevice ->
                        if (bluetoothDevice.uuids[0] == PRINTER_PARCEL_UUID) {
                            entries.add(bluetoothDevice.name)
                            entryValues.add(bluetoothDevice.address)
                        }
                    }
                }

                val printerListPreference = findPreference<ListPreference>("bluetooth_printer")!!
                printerListPreference.run {
                    this.entries = entries.toTypedArray()
                    this.entryValues = entryValues.toTypedArray()
                    onPreferenceChangeListener = Preference.OnPreferenceChangeListener { preference, newValue ->
                        AccountUtils.setInUsedPrinterMacAddress(preference.context, newValue.toString())
                    }
                }
            }
        }
    }

    companion object {
        private val PRINTER_PARCEL_UUID = ParcelUuid.fromString("00001101-0000-1000-8000-00805f9b34fb")

        fun newInstance(): PrinterPreferenceFragment {
            return PrinterPreferenceFragment()
        }
    }
}