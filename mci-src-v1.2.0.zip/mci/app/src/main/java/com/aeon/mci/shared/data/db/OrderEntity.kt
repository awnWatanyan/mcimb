package com.aeon.mci.shared.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
        tableName = "orders",
        indices = [Index(value = arrayOf("order_no"), unique = true)]
)
data class OrderEntity(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "order_id")
        val orderId: Int,

        @ColumnInfo(name = "customer_idcard_no")
        val idCardNo: String,

        @ColumnInfo(name = "collector_result_code")
        val collectorResultCode: String,

        @ColumnInfo(name = "order_no")
        val orderNo: String,

        @ColumnInfo(name = "order_plan_no")
        val planNo: String,

        @ColumnInfo(name = "order_plan_seq_no")
        val planSeqNo: String,

        @ColumnInfo(name = "order_guid")
        val guid: String,

        @ColumnInfo(name = "order_agreement_no")
        val agreementNo: String,

        @ColumnInfo(name = "order_description")
        val description: String,

        @ColumnInfo(name = "order_survey_name")
        val surveyName: String,

        @ColumnInfo(name = "order_survey_priority")
        val surveyPriority: Int,

        @ColumnInfo(name = "order_plan_sequence")
        val planSeq: Int,

        @ColumnInfo(name = "order_collect_date")
        val collectDate: Int,

        @ColumnInfo(name = "order_collect_amount")
        val collectAmount: Int,

        @ColumnInfo(name = "order_status")
        val taskStatus: String,

        @ColumnInfo(name = "order_task_type")
        val taskType: String,

        @ColumnInfo(name = "order_priority")
        val taskPriority: String,

        @ColumnInfo(name = "order_operator_name")
        val operatorName: String,

        @ColumnInfo(name = "order_autocall_remark")
        val autoCallRemark: String,

        @ColumnInfo(name = "order_delinquent_status")
        val delinquentStatus: Int,

        @ColumnInfo(name = "order_outstanding_balance")
        val outstandingBalance: Int,

        @ColumnInfo(name = "order_penalty")
        val penalty: Int,

        @ColumnInfo(name = "order_current_bill")
        val currentBill: Int,

        @ColumnInfo(name = "order_d1")
        val d1: Int,

        @ColumnInfo(name = "order_d1_add_penalty")
        val d1AddPenalty: Int,

        @ColumnInfo(name = "order_d2")
        val d2: Int,

        @ColumnInfo(name = "order_d2_add_penalty")
        val d2AddPenalty: Int,

        @ColumnInfo(name = "order_d3")
        val d3: Int,

        @ColumnInfo(name = "order_d3_add_penalty")
        val d3AddPenalty: Int,

        @ColumnInfo(name = "order_d4")
        val d4: Int,

        @ColumnInfo(name = "order_d4_add_penalty")
        val d4AddPenalty: Int,

        @ColumnInfo(name = "order_d5")
        val d5: Int,

        @ColumnInfo(name = "order_d5_add_penalty")
        val d5AddPenalty: Int,

        @ColumnInfo(name = "order_total_delinquent")
        val totalDelinquent: Int,

        @ColumnInfo(name = "order_total_add_penalty")
        val totalAddPenalty: Int,

        @ColumnInfo(name = "order_payment_code")
        val paymentCode: Int,

        @ColumnInfo(name = "order_minimum_bill")
        val minimumBill: Int,

        @ColumnInfo(name = "order_full_bill")
        val fullBill: Int,

        @ColumnInfo(name = "order_received_flag")
        val receivedFlag: Int,

        @ColumnInfo(name = "order_update_received_date")
        val receivedUpdatedDate: Int,

        @ColumnInfo(name = "order_import_hashcode")
        val hashcode: String,

        @ColumnInfo(name = "order_result_emp_code")
        val employeeCode: String,

        @ColumnInfo(name = "order_result_collected_date")
        val collectedDate: Int,

        @ColumnInfo(name = "order_result_collected_amount")
        val collectedAmount: Int,

        @ColumnInfo(name = "order_result_promised_date")
        val appointmentDate: Int,

        @ColumnInfo(name = "order_result_remark")
        val collectorRemark: String,

        @ColumnInfo(name = "order_result_lat")
        val latitude: Double,

        @ColumnInfo(name = "order_result_lon")
        val longitude: Double,

        @ColumnInfo(name = "order_result_signal")
        val signal: Int,

        @ColumnInfo(name = "order_result_send_to_autocall_flag")
        val sentToAutoCallFlag: Int,

        @ColumnInfo(name = "order_result_send_to_autocall_date")
        val sentToAutoCallDate: Int,

        @ColumnInfo(name = "order_result_send_tracking_flag")
        val sentLocationFlag: Int,

        @ColumnInfo(name = "order_result_send_tracking_date")
        val sentLocationDate: Int,

        @ColumnInfo(name = "order_token")
        val token: String,

        @ColumnInfo(name = "order_survey_code")
        val surveyCode: String,

        @ColumnInfo(name = "order_client_name_th")
        val clientNameTh: String,

        @ColumnInfo(name = "order_client_name_en")
        val clientNameEn: String,

        @ColumnInfo(name = "order_client_contact_no")
        val clientContactNo: String
)