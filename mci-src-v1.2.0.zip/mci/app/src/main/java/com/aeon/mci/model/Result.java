package com.aeon.mci.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Result implements Parcelable {

    public int collectedDate;
    public int collectedAmount;
    public int promisedDate;
    public int battery;
    public String remark;
    public String provider;
    public int signal;
    public int locationTime;
    public double latitude;
    public double longitude;
    public float speed;

    public Result() {

    }

    protected Result(Parcel source) {
        String[] data = new String[11];

        source.readStringArray(data);
        this.collectedDate = Integer.parseInt(data[0]);
        this.collectedAmount = Integer.parseInt(data[1]);
        this.promisedDate = Integer.parseInt(data[2]);
        this.battery = Integer.parseInt(data[3]);
        this.remark = data[4];
        this.provider = data[5];
        this.signal = Integer.parseInt(data[6]);
        this.locationTime = Integer.parseInt(data[7]);
        this.latitude = Double.parseDouble(data[8]);
        this.longitude = Double.parseDouble(data[9]);
        this.speed = Float.parseFloat(data[10]);
    }

    public static final Creator<Result> CREATOR = new Creator<Result>() {
        @Override
        public Result createFromParcel(Parcel source) {
            return new Result(source);
        }

        @Override
        public Result[] newArray(int size) {
            return new Result[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {
                String.valueOf(this.collectedDate),
                String.valueOf(this.collectedAmount),
                String.valueOf(this.promisedDate),
                String.valueOf(this.battery),
                this.remark,
                this.provider,
                String.valueOf(this.signal),
                String.valueOf(this.locationTime),
                String.valueOf(this.latitude),
                String.valueOf(this.longitude),
                String.valueOf(this.speed)
        });
    }
}
