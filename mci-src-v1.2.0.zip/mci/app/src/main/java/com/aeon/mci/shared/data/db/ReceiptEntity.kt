package com.aeon.mci.shared.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
        tableName = "receipts",
        indices = [Index(
                value = arrayOf("receipt_no", "receipt_status", "receipt_printed_date"),
                unique = true)]
)
data class ReceiptEntity(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "receipt_id")
        val receiptId: Int,

        @ColumnInfo(name = "order_guid")
        val guid: String,

        @ColumnInfo(name = "order_agreement_no")
        val agreementNo: String,

        @ColumnInfo(name = "receipt_no")
        val receiptNo: String,

        @ColumnInfo(name = "receipt_amount")
        val amount: Int,

        @ColumnInfo(name = "receipt_status")
        val status: String,

        @ColumnInfo(name = "receipt_printed_date")
        val printedDate: Int,

        @ColumnInfo(name = "updated_flag")
        val updatedFlag: Int,

        @ColumnInfo(name = "updated_date")
        val updatedDate: Int
)