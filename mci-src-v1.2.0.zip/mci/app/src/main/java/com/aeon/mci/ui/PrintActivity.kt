package com.aeon.mci.ui

import android.content.ContentProviderOperation
import android.content.ContentResolver
import android.content.ContentValues
import android.content.OperationApplicationException
import android.database.DatabaseUtils
import android.os.Bundle
import android.os.RemoteException
import android.provider.BaseColumns
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.aeon.mci.Config
import com.aeon.mci.R
import com.aeon.mci.model.CollectorResult
import com.aeon.mci.model.Order
import com.aeon.mci.model.Result
import com.aeon.mci.persistence.Customer
import com.aeon.mci.persistence.Receipt
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.syncadapter.SyncAdapter
import com.aeon.mci.syncadapter.SyncHelper.Companion.requestManualSync
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.PrinterUtils
import timber.log.Timber
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

abstract class PrintActivity : AppCompatActivity() {

    val employeeCode: String
        get() = AccountUtils.getEmployeeCode(this)

    val employeeFullName: String
        get() {
            val firstName = AccountUtils.getEmployeeName(this)
            val lastName = AccountUtils.getEmployeeSurname(this)
            return "$firstName $lastName"
        }

    lateinit var customer: Customer
    private var mOrder: Order? = null
    var isNewTask = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        val extras = intent.getBundleExtra(Config.EXTRAS_BUNDLE)
//        if (extras != null) {
//            isNewTask = extras.getBoolean(Config.EXTRAS_INCOMPLETE_TASK)
//            mOrder = extras.getParcelable(Config.BUNDLE_ARG_MODEL_ORDER)
//        }

        requireNotNull(intent.extras).apply {
            isNewTask = getBoolean(Config.EXTRAS_INCOMPLETE_TASK)
            customer = requireNotNull(getParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER))
            mOrder = getParcelable(Config.BUNDLE_ARG_MODEL_ORDER)
        }

//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

//        if (mIncompleteTask) {
//            setStatusBarColor(R.color.color_new_assignment_primary_dark);
//            setActionBarBackground(R.color.color_new_assignment_primary);
//        } else {
//            if (mOrder != null) {
//                if (TextUtils.equals(mOrder.taskType, "C")) {
//                    setStatusBarColor(R.color.color_canceled_assignment_primary_dark);
//                    setActionBarBackground(R.color.color_canceled_assignment_primary);
//                } else if (mOrder.updatedFlag == 1) {
//                    setStatusBarColor(R.color.color_issued_assignment_primary_dark);
//                    setActionBarBackground(R.color.color_issued_assignment_primary);
//                }
//            } else {
//                setStatusBarColor(R.color.color_done_assignment_primary_dark);
//                setActionBarBackground(R.color.color_done_assignment_primary);
//            }
//        }
//        setActionBar();
    }

    protected fun setActionBar() {
        supportActionBar?.run {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)

            val names: List<String> = customer.name.split("/")
            title = names[0]

            val gender: String = when (customer.gender) {
                1 -> getString(R.string.gender_male)
                2 -> getString(R.string.gender_female)
                3 -> getString(R.string.gender_other)
                4 -> getString(R.string.gender_corporate)
                else -> getString(R.string.gender_unknown)
            }
            val age: String = when (customer.age) {
                0 -> getString(R.string.age_unknown)
                else -> getString(R.string.age, customer.age)
            }
            subtitle = listOf(customer.id, gender, age).joinToString(separator = " / ")
        }
    }

    fun saveResult(bundle: Bundle) {
        val selectedOrders: ArrayList<Order> = bundle.getParcelableArrayList(Config.BUNDLE_ARG_SELECTED_ORDERS)!!
        val collectorResult: CollectorResult = bundle.getParcelable(Config.EXTRA_EDIT_RESULT_COLLECTOR_RESULT)!!
        val inputResult: Result = bundle.getParcelable(Config.EXTRA_EDIT_RESULT_INPUT_RESULT)!!
        if (collectorResult != null && inputResult != null && selectedOrders != null) {
            val empCode = AccountUtils.getEmployeeCode(this)
            val updatedDate = (System.currentTimeMillis() / 1000L).toInt()
            val orderUpdateBatch = ArrayList<ContentProviderOperation>()
            val locationInsertBatch = ArrayList<ContentProviderOperation>()
            for (order in selectedOrders) {
                orderUpdateBatch.add(ContentProviderOperation
                        .newUpdate(OrderContract.Orders.CONTENT_URI)
                        .withValue(OrderContract.Orders.COLLECTOR_RESULT_CODE, collectorResult.code)
                        .withValue(OrderContract.Orders.ORDER_RESULT_EMP_CODE, empCode)
                        .withValue(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE, inputResult.collectedDate)
                        .withValue(OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT, inputResult.collectedAmount)
                        .withValue(OrderContract.Orders.ORDER_RESULT_REMARK, inputResult.remark)
                        .withValue(OrderContract.Orders.ORDER_RESULT_PROMISED_DATE, inputResult.promisedDate)
                        .withValue(OrderContract.Orders.ORDER_RESULT_LAT, inputResult.latitude)
                        .withValue(OrderContract.Orders.ORDER_RESULT_LON, inputResult.longitude)
                        .withValue(OrderContract.Orders.ORDER_RESULT_SIGNAL, inputResult.signal)
                        .withValue(OrderContract.SyncColumns.UPDATED_FLAG, 1)
                        .withValue(OrderContract.Orders.ORDER_RESULT_SEND_TO_AUTOCALL_FLAG, 1)
                        .withValue(OrderContract.Orders.ORDER_RESULT_SEND_TRACKING_FLAG, 1)
                        .withSelection(OrderContract.Orders.ORDER_NO + "=?", arrayOf(order.id))
                        .build())
                locationInsertBatch.add(ContentProviderOperation
                        .newInsert(OrderContract.Locations.CONTENT_URI)
                        .withValue(OrderContract.SyncColumns.UPDATED_FLAG, 1)
                        .withValue(OrderContract.SyncColumns.UPDATED_DATE, updatedDate)
                        .withValue(OrderContract.Locations.ORDER_NO, order.id)
                        .withValue(OrderContract.Locations.LOCATION_TIME, inputResult.locationTime)
                        .withValue(OrderContract.Locations.LOCATION_LATITUDE, inputResult.latitude)
                        .withValue(OrderContract.Locations.LOCATION_LONGITUDE, inputResult.longitude)
                        .withValue(OrderContract.Locations.LOCATION_BATTERY, inputResult.battery)
                        .withValue(OrderContract.Locations.LOCATION_SPEED, inputResult.speed)
                        .withValue(OrderContract.Locations.LOCATION_PROVIDER, inputResult.provider)
                        .withValue(OrderContract.Locations.LOCATION_EMPLOYEE_CODE, empCode)
                        .build())
            }
            val updateOperations = orderUpdateBatch.size
            if (updateOperations > 0) {
                try {
                    Timber.i("Applying $updateOperations content provider operations for orders.")
                    contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, orderUpdateBatch)
                    Timber.i("Successfully applied $updateOperations content provider operations for orders.")
                    val toastText = resources.getQuantityString(
                            R.plurals.agreement_updated_success_toast_text, updateOperations, updateOperations)
                    Toast.makeText(this, toastText, Toast.LENGTH_LONG).show()
                    val locationOperations = locationInsertBatch.size
                    Timber.i("Applying $locationOperations content provider operations for locations.")
                    if (locationOperations > 0) {
                        contentResolver.applyBatch(OrderContract.CONTENT_AUTHORITY, locationInsertBatch)
                        Timber.i("Successfully applied $locationOperations content provider operations for locations.")
                    }
                    val printNotice = collectorResult.letter == 0
                    val printReceipt = collectorResult.receipt == 0
                    //                    boolean getMoney = collectorResult.money == 0;
                    if (printReceipt) {
                        if (selectedOrders.size == 1) {
                            val currencyFormat = DecimalFormat("##,###,##0.00")
                            val amount = inputResult.collectedAmount.toFloat() / 100
                            val order = selectedOrders[0]
                            val receiptNo = getReceiptNo(false)
                            cancelReceipt(order.guid)
                            saveReceipt(receiptNo, inputResult.collectedAmount, "P",
                                    order.guid, order.agreementNo, updatedDate)
                            val receiptData = Bundle()
                            val collectorFirstName = AccountUtils.getEmployeeName(this)
                            val collectorSurname = AccountUtils.getEmployeeSurname(this)
                            val collectorName = "$collectorFirstName $collectorSurname"
                            receiptData.putString(Config.EXTRAS_EMPLOYEE_FULL_NAME, collectorName)
                            receiptData.putString(Config.EXTRAS_CLIENT_NAME_EN, order.clientNameEn)
                            receiptData.putString(Config.EXTRAS_CLIENT_NAME_TH, order.clientNameTh)
                            receiptData.putBoolean(Config.EXTRAS_INCOMPLETE_TASK, isNewTask)
                            receiptData.putString(Config.EXTRAS_EMPLOYEE_CODE, employeeCode)
                            receiptData.putString(Config.EXTRAS_EMPLOYEE_FULL_NAME, employeeFullName)
                            receiptData.putString(Config.EXTRAS_CUSTOMER_ID, order.customerId)
                            receiptData.putString(Config.EXTRAS_CUSTOMER_NAME, customer!!.name)
                            receiptData.putString(Config.EXTRAS_ORDER_NO, order.id)
                            if (TextUtils.isEmpty(order.agreementNoFullPan)) {
                                receiptData.putString(Config.EXTRAS_AGREEMENT_NO, order.agreementNo)
                            } else {
                                receiptData.putString(Config.EXTRAS_AGREEMENT_NO, order.agreementNoFullPan)
                            }
                            receiptData.putString(Config.EXTRAS_RECEIPT_NO, receiptNo)
                            receiptData.putString(Config.EXTRAS_COLLECTED_AMOUNT, currencyFormat.format(amount.toDouble()))
                            receiptData.putInt(Config.EXTRAS_UPDATED_DATE, updatedDate)
                            receiptData.putInt(Config.EXTRAS_REPRINT_NO, 0)
                            receiptData.putString(Config.EXTRAS_CLIENT_NAME_EN, order.clientNameEn)
                            receiptData.putString(Config.EXTRAS_CLIENT_NAME_TH, order.clientNameTh)
                            receiptData.putString(Config.EXTRAS_CLIENT_CONTACT_NO, order.clientContactNo)
                            receiptData.putString(Config.EXTRAS_GUID, order.guid)
                            PrinterUtils.printReceipt(this, receiptData, false)
                        }
                    } else {
                        if (!isNewTask && selectedOrders.size == 1) {
                            val order = selectedOrders[0]
                            cancelReceipt(order.guid)
                        }
                        if (printNotice) {
                            val order = selectedOrders[0]
                            val noticeData = Bundle()
                            val collectorFirstName = AccountUtils.getEmployeeName(this)
                            val collectorSurname = AccountUtils.getEmployeeSurname(this)
                            val collectorName = "$collectorFirstName $collectorSurname"
                            noticeData.putString(Config.EXTRAS_EMPLOYEE_FULL_NAME, collectorName)
                            noticeData.putString(Config.EXTRAS_CUSTOMER_NAME, customer!!.name)
                            noticeData.putString(Config.EXTRAS_CLIENT_NAME_EN, order.clientNameEn)
                            noticeData.putString(Config.EXTRAS_CLIENT_NAME_TH, order.clientNameTh)
                            noticeData.putString(Config.EXTRAS_CLIENT_CONTACT_NO, order.clientContactNo)
                            noticeData.putString(Config.EXTRAS_GUID, order.guid)
                            noticeData.putString(Config.EXTRAS_AGREEMENT_NO, order.agreementNo)
                            PrinterUtils.printNotice(this, noticeData, isNewTask)
                            //                            PrinterUtils.printNotice(this, mCustomer.getName(), mIncompleteTask);
                        }
                    }
                    requestManualResultDataSync()
                    if (isNewTask && !printReceipt && !printNotice) {
                        finish()
                    }
                } catch (e: RemoteException) {
                    Timber.e("RemoteException while on completed edit result.")
                } catch (e: OperationApplicationException) {
                    Timber.e("OperationApplicationException while on completed edit result.")
                }
            }
        }
    }

    protected fun saveReceipt(
            receiptNo: String?,
            collectedAmount: Int,
            printStatus: String?,
            guid: String?,
            agreementNo: String?,
            dateNow: Int
    ) {
        val values = ContentValues()
        values.put(OrderContract.Receipts.GUID, guid)
        values.put(OrderContract.Receipts.AGREEMENT_NO, agreementNo)
        values.put(OrderContract.Receipts.RECEIPT_NO, receiptNo)
        values.put(OrderContract.Receipts.RECEIPT_AMOUNT, collectedAmount)
        values.put(OrderContract.Receipts.RECEIPT_STATUS, printStatus)
        values.put(OrderContract.Receipts.RECEIPT_PRINTED_DATE, dateNow)
        values.put(OrderContract.SyncColumns.UPDATED_FLAG, 1)
        values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
        contentResolver.insert(OrderContract.Receipts.CONTENT_URI, values)
    }

    protected fun requestManualResultDataSync() {
        val account = AccountUtils.getActiveAccount(this)
        if (ContentResolver.isSyncActive(account, OrderContract.CONTENT_AUTHORITY)) {
            Timber.d("Ignoring manual sync request because a sync is already in progress.")
            return
        }
        Timber.d("Requesting manual result data sync.")
        val extras = Bundle()
        extras.putBoolean(SyncAdapter.EXTRA_SYNC_ORDER_RESULT_DATA, true)
        requestManualSync(account, extras)
    }

    protected fun requestManualReceiptDataSync() {
        val account = AccountUtils.getActiveAccount(this)
        if (ContentResolver.isSyncActive(account, OrderContract.CONTENT_AUTHORITY)) {
            Timber.d("Ignoring manual sync request because a sync is already in progress.")
            return
        }
        Timber.d("Requesting manual receipt data sync.")
        val extras = Bundle()
        extras.putBoolean(SyncAdapter.EXTRA_SYNC_RECEIPT_DATA, true)
        requestManualSync(account, extras)
    }

    //    @Override
    //    public void onCheckPrinterCompleted(boolean isPrinterReady) {
    //        Log.d(TAG, "printer(ready=" + isPrinterReady + ")");
    //        if (isPrinterReady) {
    //            if (mPrint != null) {
    //                mPrint.executePrint();
    //            }
    //        } else {
    //            AlertDialog.Builder builder = new AlertDialog.Builder(this);
    //            builder.setMessage(R.string.printer_checking_retry_text);
    //            builder.setCancelable(false);
    //            builder.setPositiveButton("OK", null);
    //            builder.show();
    //        }
    //    }
    //    @Override
    //    public void onPrintCompleted(int actionId, boolean isPrintCopyOfReceipt) {
    //        if (isPrintCopyOfReceipt) {
    //            AlertDialog.Builder builder = new AlertDialog.Builder(this);
    //            builder.setMessage(getString(R.string.order_print_copy_receipt_dialog_content));
    //            builder.setCancelable(false);
    //            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
    //                @Override
    //                public void onClick(DialogInterface dialogInterface, int i) {
    //                    mPrint.setReceiptCopy(true);
    //                    if (mPrint.isDeviceBluetoothSupport()) {
    //                        mPrint.executePrint();
    //                    }
    //                }
    //            });
    //            builder.show();
    //        } else {
    //            if (actionId != R.id.action_reprint && mCloseActivityAfterPrint) {
    //                finish();
    //            }
    //        }
    //    }
    //    protected void printLetter(int actionId) {
    //        int dateNow = (int) (System.currentTimeMillis() / 1000L);
    //        mPrint = new PrinterUtils(this);
    //        mPrint.setOnPrintCompletedListener(this);
    //        mPrint.setPrintMode(2);
    //        mPrint.setActionId(actionId);
    //        mPrint.setCustomerName(mCustomer.name);
    //        mPrint.setEmployeeFullName(mEmpFullName);
    //        mPrint.setPrintDate(dateNow);
    //        if (mPrint.isDeviceBluetoothSupport()) {
    //            mPrint.checkPrinter();
    //        }
    //    }
    protected fun getReceiptNo(reprint: Boolean): String {
        val df = DecimalFormat("000")
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        val dateNow = (System.currentTimeMillis() / 1000L).toInt()
        val now = Date(dateNow * 1000L)
        val calendar = Calendar.getInstance()
        calendar[Calendar.HOUR_OF_DAY] = 0
        calendar[Calendar.MINUTE] = 0
        calendar[Calendar.SECOND] = 0
        val start = (calendar.time.time / 1000L).toInt()
        calendar.add(Calendar.DATE, 1)
        val end = (calendar.time.time / 1000L).toInt()
        var receiptNo = ""
        if (reprint) {
            val cursor = contentResolver.query(OrderContract.Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    OrderContract.Receipts.RECEIPT_ITEM_SELECTION, arrayOf(mOrder!!.guid, "P", start.toString(), end.toString()),
                    OrderContract.Receipts.RECEIPT_NO + " DESC")
            if (cursor != null && cursor.moveToNext()) {
                DatabaseUtils.dumpCursor(cursor)
                receiptNo = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_NO))
                cursor.close()
            }
        } else {
            val cursor = contentResolver.query(OrderContract.Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    OrderContract.Receipts.RECEIPT_PRINT_SELECTION, arrayOf(start.toString(), end.toString()),
                    OrderContract.Receipts.RECEIPT_NO + " DESC")
            var count = 0
            if (cursor != null) {
//                DatabaseUtils.dumpCursor(cursor);
                count = cursor.count
                cursor.close()
            }
            receiptNo = employeeCode + "_" + sdf.format(now) + "_" + df.format(count + 1.toLong())
        }
        return receiptNo
    }

    //        Cursor cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
//                ReceiptQuery.NORMAL_PROJECTION,
//                OrderContract.Receipts.RECEIPT_ITEM_SELECTION,
//                new String[]{mOrder.guid, "R", String.valueOf(start), String.valueOf(end)},
//                null);
//        if (cursor != null) {
//            reprintCount = cursor.getCount() + 1;
//            cursor.close();
//        }

    protected val reprintNo: Int
        protected get() {
            val calendar = Calendar.getInstance()
            calendar[Calendar.HOUR_OF_DAY] = 0
            calendar[Calendar.MINUTE] = 0
            calendar[Calendar.SECOND] = 0
            val start = (calendar.time.time / 1000L).toInt()
            calendar.add(Calendar.DATE, 1)
            val end = (calendar.time.time / 1000L).toInt()
            val receipts: MutableList<Receipt> = ArrayList()
            val c = contentResolver.query(
                    OrderContract.Receipts.CONTENT_URI,
                    ReceiptQuery.NORMAL_PROJECTION,
                    OrderContract.Receipts.RECEIPT_LATEST_BY_GUID_SELECTION, arrayOf(mOrder!!.guid, mOrder!!.agreementNo, start.toString(), end.toString()),
                    OrderContract.Receipts.RECEIPT_NO + " DESC"
            )
            if (c != null) {
                while (c.moveToNext()) {
                    val receipt = Receipt(
                            c.getString(c.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_NO)),
                            c.getString(c.getColumnIndexOrThrow(OrderContract.Receipts.GUID)),
                            c.getString(c.getColumnIndexOrThrow(OrderContract.Receipts.AGREEMENT_NO)),
                            c.getString(c.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_STATUS)),
                            c.getInt(c.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_AMOUNT)),
                            c.getInt(c.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_PRINTED_DATE))
                    )
                    receipts.add(receipt)
                }
                c.close()
            }
            var currentReceiptNo: Receipt? = null
            if (receipts.size > 0) {
                currentReceiptNo = receipts[0]
            }
            var reprintCount = 0
            if (currentReceiptNo != null) {
                val cursor = contentResolver.query(OrderContract.Receipts.CONTENT_URI,
                        ReceiptQuery.NORMAL_PROJECTION,
                        OrderContract.Receipts.RECEIPT_ITEM_REPRINT_SELECTION, arrayOf(mOrder!!.guid, mOrder!!.agreementNo, currentReceiptNo.no, "R", start.toString(), end.toString()),
                        null)
                if (cursor != null) {
                    reprintCount = cursor.count + 1
                    cursor.close()
                }
            }
            //        Cursor cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
//                ReceiptQuery.NORMAL_PROJECTION,
//                OrderContract.Receipts.RECEIPT_ITEM_SELECTION,
//                new String[]{mOrder.guid, "R", String.valueOf(start), String.valueOf(end)},
//                null);
//        if (cursor != null) {
//            reprintCount = cursor.getCount() + 1;
//            cursor.close();
//        }
            return reprintCount
        }

    //    protected void printReceipt(int collectedAmount, boolean isReprint, int actionId) {
    //        String printStatus = "P";
    //        DecimalFormat df = new DecimalFormat("000");
    //        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.US);
    //        int dateNow = (int) (System.currentTimeMillis() / 1000L);
    //        Date now = new Date(dateNow * 1000L);
    //
    //        Calendar calendar = Calendar.getInstance();
    //        calendar.set(Calendar.HOUR_OF_DAY, 0);
    //        calendar.set(Calendar.MINUTE, 0);
    //        calendar.set(Calendar.SECOND, 0);
    //        int start = (int) (calendar.getTime().getTime() / 1000L);
    //        calendar.add(Calendar.DATE, 1);
    //        int end = (int) (calendar.getTime().getTime() / 1000L);
    //
    //        Cursor cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
    //                ReceiptQuery.NORMAL_PROJECTION,
    //                OrderContract.Receipts.RECEIPT_PRINT_SELECTION,
    //                new String[]{String.valueOf(start), String.valueOf(end)},
    //                OrderContract.Receipts.RECEIPT_NO + " DESC");
    //        int count;
    //        if (cursor != null) {
    //            count = cursor.getCount();
    //            cursor.close();
    //        } else {
    //            count = 0;
    //        }
    //        String receiptNo = mEmpCode + "_" + sdf.format(now) + "_" + df.format(count + 1);
    //
    //        int reprintCount = 0;
    //        if (isReprint) {
    //            cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
    //                    ReceiptQuery.NORMAL_PROJECTION,
    //                    OrderContract.Receipts.RECEIPT_ITEM_SELECTION,
    //                    new String[]{mOrder.guid, printStatus, String.valueOf(start), String.valueOf(end)},
    //                    OrderContract.Receipts.RECEIPT_NO + " DESC");
    //            if (cursor != null && cursor.moveToNext()) {
    //                receiptNo = cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_NO));
    //                cursor.close();
    //            }
    //            printStatus = "R";
    //            cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
    //                    ReceiptQuery.NORMAL_PROJECTION,
    //                    OrderContract.Receipts.RECEIPT_ITEM_SELECTION,
    //                    new String[]{mOrder.guid, printStatus, String.valueOf(start), String.valueOf(end)},
    //                    null);
    //            reprintCount = cursor.getCount() + 1;
    //            cursor.close();
    //        } else {
    //            cancelReceipt();
    //        }
    //
    //        DecimalFormat currencyFormat = new DecimalFormat("##,###,##0.00");
    //        float amount = (float) collectedAmount / 100;
    //
    //        ContentValues values = new ContentValues();
    //        values.put(OrderContract.Receipts.GUID, mOrder.guid);
    //        values.put(OrderContract.Receipts.AGREEMENT_NO, mOrder.agreementNo);
    //        values.put(OrderContract.Receipts.RECEIPT_NO, receiptNo);
    //        values.put(OrderContract.Receipts.RECEIPT_AMOUNT, collectedAmount);
    //        values.put(OrderContract.Receipts.RECEIPT_STATUS, printStatus);
    //        values.put(OrderContract.Receipts.RECEIPT_PRINTED_DATE, dateNow);
    //        values.put(OrderContract.SyncColumns.UPDATED_FLAG, 1);
    //        values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow);
    //        getContentResolver().insert(OrderContract.Receipts.CONTENT_URI, values);
    //
    //        if (isReprint) {
    //            Log.d(TAG, "Starting manual sync for reprint receipt.");
    //            requestManualReceiptDataSync();
    //        }
    //
    //        mPrint = new PrinterUtils(this);
    //        mPrint.setOnPrintCompletedListener(this);
    //        mPrint.setPrintMode(1);
    //        mPrint.setActionId(actionId);
    //        mPrint.setReceiptNo(receiptNo);
    //        mPrint.setAmount(currencyFormat.format(amount));
    //        mPrint.setPrintDate(dateNow);
    //        mPrint.setReprintNo(reprintCount);
    //        mPrint.setReceiptCopy(false);
    //        mPrint.setEmployeeId(mEmpCode);
    //        mPrint.setEmployeeFullName(mEmpFullName);
    //        mPrint.setOrderNo(mOrder.id);
    //        mPrint.setCustomerName(mCustomer.name);
    //        mPrint.setCustomerId(mCustomer.id);
    //        mPrint.setAgreementNo(mOrder.agreementNo);
    //        if (mPrint.isDeviceBluetoothSupport()) {
    //            mPrint.checkPrinter();
    //        }
    //    }
    //    protected void cancelReceipt() {
    //        Calendar calendar = Calendar.getInstance();
    //        calendar.set(Calendar.HOUR_OF_DAY, 0);
    //        calendar.set(Calendar.MINUTE, 0);
    //        calendar.set(Calendar.SECOND, 0);
    //        int start = (int) (calendar.getTime().getTime() / 1000L);
    //        calendar.add(Calendar.DATE, 1);
    //        int end = (int) (calendar.getTime().getTime() / 1000L);
    //
    //        Cursor cursor = getContentResolver().query(OrderContract.Receipts.CONTENT_URI,
    //                ReceiptQuery.NORMAL_PROJECTION,
    //                OrderContract.Receipts.RECEIPT_ITEM_SELECTION,
    //                new String[]{mOrder.guid, "P", String.valueOf(start), String.valueOf(end)},
    //                OrderContract.Receipts.RECEIPT_NO + " DESC");
    //        if (cursor != null && cursor.moveToNext()) {
    //            int dateNow = (int) (System.currentTimeMillis() / 1000L);
    //            ContentValues values = new ContentValues();
    //            values.put(OrderContract.Receipts.GUID,
    //                    cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.GUID)));
    //            values.put(OrderContract.Receipts.AGREEMENT_NO,
    //                    cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.AGREEMENT_NO)));
    //            values.put(OrderContract.Receipts.RECEIPT_NO,
    //                    cursor.getString(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_NO)));
    //            values.put(OrderContract.Receipts.RECEIPT_AMOUNT,
    //                    cursor.getInt(cursor.getColumnIndex(OrderContract.Receipts.RECEIPT_AMOUNT)));
    //            values.put(OrderContract.Receipts.RECEIPT_STATUS, "C");
    //            values.put(OrderContract.Receipts.RECEIPT_PRINTED_DATE, dateNow);
    //            values.put(OrderContract.SyncColumns.UPDATED_FLAG, 1);
    //            values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow);
    //            getContentResolver().insert(OrderContract.Receipts.CONTENT_URI, values);
    //            cursor.close();
    //        }
    //    }
    private fun cancelReceipt(guid: String) {
        val calendar = Calendar.getInstance()
        calendar[Calendar.HOUR_OF_DAY] = 0
        calendar[Calendar.MINUTE] = 0
        calendar[Calendar.SECOND] = 0
        val start = (calendar.time.time / 1000L).toInt()
        calendar.add(Calendar.DATE, 1)
        val end = (calendar.time.time / 1000L).toInt()
        val cursor = contentResolver.query(OrderContract.Receipts.CONTENT_URI,
                ReceiptQuery.NORMAL_PROJECTION,
                OrderContract.Receipts.RECEIPT_ITEM_SELECTION, arrayOf(guid, "P", start.toString(), end.toString()),
                OrderContract.Receipts.RECEIPT_NO + " DESC")
        if (cursor != null && cursor.moveToNext()) {
            val dateNow = (System.currentTimeMillis() / 1000L).toInt()
            val values = ContentValues()
            values.put(OrderContract.Receipts.GUID,
                    cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.GUID)))
            values.put(OrderContract.Receipts.AGREEMENT_NO,
                    cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.AGREEMENT_NO)))
            values.put(OrderContract.Receipts.RECEIPT_NO,
                    cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_NO)))
            values.put(OrderContract.Receipts.RECEIPT_AMOUNT,
                    cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Receipts.RECEIPT_AMOUNT)))
            values.put(OrderContract.Receipts.RECEIPT_STATUS, "C")
            values.put(OrderContract.Receipts.RECEIPT_PRINTED_DATE, dateNow)
            values.put(OrderContract.SyncColumns.UPDATED_FLAG, 1)
            values.put(OrderContract.SyncColumns.UPDATED_DATE, dateNow)
            contentResolver.insert(OrderContract.Receipts.CONTENT_URI, values)
            cursor.close()
        }
    }
}

object ReceiptQuery {
    val NORMAL_PROJECTION = arrayOf(
            BaseColumns._ID,
            OrderContract.Receipts.GUID,
            OrderContract.Receipts.AGREEMENT_NO,
            OrderContract.Receipts.RECEIPT_NO,
            OrderContract.Receipts.RECEIPT_AMOUNT,
            OrderContract.Receipts.RECEIPT_STATUS,
            OrderContract.Receipts.RECEIPT_PRINTED_DATE
    )
}