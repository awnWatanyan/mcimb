package com.aeon.mci.shared.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CollectorResultDao {

    @Query("SELECT * FROM collector_results")
    fun getAll(): List<CollectorResultEntity>

    @Query("""
        SELECT * FROM collector_results WHERE collector_result_status = 1 
        ORDER BY collector_result_grouping_order ASC, collector_result_code ASC
    """)
    fun getOnlyUsed(): List<CollectorResultEntity>

    @Query("""
        SELECT * FROM collector_results 
        WHERE collector_result_status = 1 AND collector_result_get_money = 1 
        ORDER BY collector_result_grouping_order ASC, collector_result_code ASC
    """)
    fun getOnlyUsedExcludeGetMoney(): List<CollectorResultEntity>

    @Query("SELECT * FROM collector_results WHERE collector_result_code = :code")
    fun findByCollectorResultCode(code: String): CollectorResultEntity

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg collectorResults: CollectorResultEntity)
}