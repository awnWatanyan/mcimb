package com.aeon.mci.service.tracking

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TrackingBroadcastReceiver : BroadcastReceiver() {

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != null) {
            if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
                // Start tracking foreground service
                val trackingServiceIntent = Intent(context, TrackingService::class.java)
                context.startForegroundService(trackingServiceIntent)
            }
        }
    }
}