package com.aeon.mci.ui.customer

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.aeon.mci.persistence.Customer
import com.aeon.mci.shared.data.db.CustomerEntity
import com.aeon.mci.shared.data.db.CustomerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class CustomerViewModel @Inject constructor(
        customerRepository: CustomerRepository
) : ViewModel() {

    val assignTasks: LiveData<List<CustomerEntity>> = customerRepository.getAssignTask()

    val swipeRefreshing = MutableLiveData<Boolean>().apply { value = false }

    val isRefreshing = MutableLiveData<Boolean>().apply { value = false }

    val isActionModeEnabled = MutableLiveData<Boolean>().apply { value = false }

    val isNewTask = MutableLiveData<Boolean>().apply { value = true }

    val showReorder = MutableLiveData<Boolean>().apply { value = false }

    val customers = MutableLiveData<MutableList<Customer>>()
}