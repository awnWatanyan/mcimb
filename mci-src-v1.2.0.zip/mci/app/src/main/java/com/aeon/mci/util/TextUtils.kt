package com.aeon.mci.util

import android.os.Build
import android.text.Html
import android.text.Spanned
import java.text.DecimalFormat
import java.text.MessageFormat
import java.text.SimpleDateFormat
import java.util.*

fun dateFormat() = SimpleDateFormat("dd/MM/yyyy", Locale.US)

fun dateFormatYearFirst() = SimpleDateFormat("yyyy/mm/dd", Locale.US)

fun timeFormat() = SimpleDateFormat("HH:mm", Locale.US)

fun datetimeFormat() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

fun decimalFormatWithoutCommas() = DecimalFormat("#######0.00")

fun decimalFormatWithCommas() = DecimalFormat("##,###,##0.00")

fun decimalFormatWithCommasExcludeZeros() = DecimalFormat("##,###,##0.##")

fun fromHtml(html: String): Spanned {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
    } else {
        Html.fromHtml(html)
    }
}

fun formatToPhoneNumber(number: String): String {
    val phoneNumberArgs: Array<String> = when (number.length) {
        9 -> {
            arrayOf(
                    number.substring(0, 2),
                    number.substring(2, 5),
                    number.substring(5)
            )
        }
        10 -> {
            arrayOf(
                    number.substring(0, 3),
                    number.substring(3, 6),
                    number.substring(6)
            )
        }
        else -> arrayOf(number)
    }
    return phoneNumberArgs.joinToString(separator = "-")
}