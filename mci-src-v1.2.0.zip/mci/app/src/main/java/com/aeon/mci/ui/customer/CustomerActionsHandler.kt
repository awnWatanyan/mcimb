package com.aeon.mci.ui.customer

import androidx.recyclerview.widget.RecyclerView
import com.aeon.mci.persistence.Customer

interface CustomerActionsHandler {

    fun openCustomerDetail(customer: Customer)

    fun startActionMode(): Boolean

    fun startDragCustomer(holder: RecyclerView.ViewHolder)
}