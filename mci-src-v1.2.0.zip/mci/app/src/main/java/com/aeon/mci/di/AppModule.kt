package com.aeon.mci.di

import android.accounts.AccountManager
import android.app.AlarmManager
import android.bluetooth.BluetoothManager
import android.content.ClipboardManager
import android.content.ContentResolver
import android.content.Context
import android.location.LocationManager
import android.net.ConnectivityManager
import android.telephony.TelephonyManager
import com.aeon.mci.di.scopes.MainThreadHandler
import com.aeon.mci.shared.data.db.AppDatabase
import com.aeon.mci.shared.data.db.CustomerRepository
import com.aeon.mci.shared.domain.internal.MCIHandler
import com.aeon.mci.shared.domain.internal.MCIMainHandler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class AppModule {

    @Provides
    fun provideAccountManager(@ApplicationContext context: Context): AccountManager =
            AccountManager.get(context.applicationContext)

    @Provides
    fun provideContentResolver(@ApplicationContext context: Context): ContentResolver = context.contentResolver

    @Provides
    fun provideConnectivityManager(@ApplicationContext context: Context): ConnectivityManager =
            context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE)
                    as ConnectivityManager

    @Provides
    fun providesClipboardManager(@ApplicationContext context: Context): ClipboardManager =
            context.applicationContext.getSystemService(Context.CLIPBOARD_SERVICE)
                    as ClipboardManager

    @Provides
    fun provideTelephonyManager(@ApplicationContext context: Context): TelephonyManager =
            context.applicationContext.getSystemService(Context.TELEPHONY_SERVICE)
                    as TelephonyManager

    @Provides
    fun provideAlarmManager(@ApplicationContext context: Context): AlarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    @Provides
    fun provideLocationManager(@ApplicationContext context: Context): LocationManager =
            context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    @Singleton
    @Provides
    @MainThreadHandler
    fun providesMainThreadHandler(): MCIHandler = MCIMainHandler()

    @Singleton
    @Provides
    fun provideCustomerRepository(appDatabase: AppDatabase): CustomerRepository =
            CustomerRepository(appDatabase.customerDao())

    @Singleton
    @Provides
    fun providesAppDatabase(@ApplicationContext context: Context): AppDatabase = AppDatabase.getDatabase(context)

    @Singleton
    @Provides
    fun provideBluetoothManager(@ApplicationContext context: Context): BluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
}