package com.aeon.mci.persistence

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import kotlinx.datetime.Instant
import kotlinx.serialization.SerialName

@Parcelize
data class NewCustomer(
    @SerializedName("plan_id")
    val planId: String,
    @SerializedName("plan_assigned_date")
    val planAssignedDate: String,
    @SerializedName("plan_seq_id")
    val planSeqId: Int,
    @SerializedName("job_status")
    val jobStatus: Int,
    @SerializedName("request_date")
    val requestDate: String,
    @SerializedName("task_type")
    val taskType: String,
    val priority: String,
    @SerializedName("operator_name")
    val operatorName: String,
    @SerializedName("survey_type")
    val surveyType: String,
    val sex: String,
    val age: Int,
    val zipcode: String,
    @SerializedName("customer_address")
    val customerAddress: String = "",
    val section: String = "",
    val mobile: String = "",
    val phone: String = "",
    @SerializedName("phone_ext")
    val phoneExt: String = "",
    @SerializedName("total_collect_amount")
    val totalCollectAmount: Double,
    @SerializedName("collect_date")
    val collectDate: String,
    @SerializedName("collect_time")
    val collectTime: String = "",
    @SerializedName("id_max_delinquent_status")
    val idMaxDelinquentStatus: String = "",
    @SerializedName("id_outstanding_balance")
    val idOutstandingBalance: String = "",
    @SerializedName("id_total_bill")
    val idTotalBill: String = "",
    @SerializedName("client_name_th")
    val clientNameTh: String = "",
    @SerializedName("client_name_en")
    val clientNameEn: String = "",
    @SerializedName("client_contact_no")
    val clientContactNo: String = "",
    val guid: String = "",
    @SerializedName("total_workorder_accounts")
    val totalWorkOrderAccounts: Int,
    val lat: Double = -0.1,
    val lon: Double = -0.1,
    @SerializedName("customer_name")
    val customerName: String,
    @SerializedName("citizen_id")
    val citizenId: String,
    @SerializedName("plan_created_by")
    val planCreatedBy: String,
    @SerializedName("plan_created_date")
    val planCreatedDate: String,
    @SerializedName("plan_updated_by")
    val planUpdatedBy: String,
    @SerializedName("plan_updated_date")
    val planUpdatedDate: String? = null,
) : Parcelable
