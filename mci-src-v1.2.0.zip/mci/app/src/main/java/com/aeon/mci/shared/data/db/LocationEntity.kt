package com.aeon.mci.shared.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
        tableName = "locations",
        indices = [Index(value = arrayOf("location_time", "order_no"))]
)
data class LocationEntity(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "location_id")
        val locationId: Int,

        @ColumnInfo(name = "updated_flag")
        val updatedFlag: Int,

        @ColumnInfo(name = "updated_date")
        val updatedDate: Int,

        @ColumnInfo(name = "order_no")
        val orderNo: String,

        @ColumnInfo(name = "location_time")
        val time: Int,

        @ColumnInfo(name = "location_latitude")
        val latitude: Double,

        @ColumnInfo(name = "location_longitude")
        val longitude: Double,

        @ColumnInfo(name = "location_battery")
        val batteryPct: Int,

        @ColumnInfo(name = "location_speed")
        val speed: Double,

        @ColumnInfo(name = "location_provider")
        val provider: String,

        @ColumnInfo(name = "location_employee_code")
        val employeeCode: String
)