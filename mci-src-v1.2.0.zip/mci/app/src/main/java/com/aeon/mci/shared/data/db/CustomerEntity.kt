package com.aeon.mci.shared.data.db

import androidx.room.*

@Entity(
        tableName = "customers",
        indices = [Index(value = arrayOf("customer_idcard_no"), unique = true)]
)
data class CustomerEntity @Ignore constructor(

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name = "customer_id")
        val customerId: Int,

        @ColumnInfo(name = "customer_idcard_no")
        val idCardNo: String,

        @ColumnInfo(name = "customer_name")
        val name: String,

        @ColumnInfo(name = "customer_gender")
        val gender: String,

        @ColumnInfo(name = "customer_age")
        val age: String,

        @ColumnInfo(name = "customer_address")
        val address: String,

        @ColumnInfo(name = "customer_zipcode")
        val postcode: String,

        @ColumnInfo(name = "customer_section")
        val section: String,

        @ColumnInfo(name = "customer_phone")
        val phone: String,

        @ColumnInfo(name = "customer_phone_ext")
        val phoneExt: String,

        @ColumnInfo(name = "customer_mobile")
        val mobile: String,

        @ColumnInfo(name = "customer_deln")
        val delinquentStatus: String,

        @ColumnInfo(name = "customer_os_balance")
        val outstandingBalance: String,

        @ColumnInfo(name = "customer_total_bill")
        val totalBill: String,

        @ColumnInfo(name = "customer_import_hashcode")
        val hashcode: String,

        @ColumnInfo(name = "updated_date")
        val updatedDate: Int,

        @Ignore
        val totalAgreements: Int,

        @Ignore
        val totalCanceledAgreements: Int,

        @Ignore
        val totalUrgentAgreements: Int,

        @Ignore
        val totalCollectAmount: Int,

        @Ignore
        val totalCollectedAmount: Int,

        @Ignore
        val clientNameEn: String,

        @Ignore
        val clientNameTh: String,

        @Ignore
        val clientContactNo: String,

        @Ignore
        val collectedDate: Int,

        @Ignore
        val autoCallRemark: String
) {
        constructor(
                customerId: Int,
                idCardNo: String,
                name: String,
                gender: String,
                age: String,
                address: String,
                postcode: String,
                section: String,
                phone: String,
                phoneExt: String,
                mobile: String,
                delinquentStatus: String,
                outstandingBalance: String,
                totalBill: String,
                hashcode: String,
                updatedDate: Int
        ) : this(
                customerId,
                idCardNo,
                name,
                gender,
                age,
                address,
                postcode,
                section,
                phone,
                phoneExt,
                mobile,
                delinquentStatus,
                outstandingBalance,
                totalBill,
                hashcode,
                updatedDate,
                0,
                0,
                0,
                0,
                0,
                "",
                "",
                "",
                0,
                ""
        )
}