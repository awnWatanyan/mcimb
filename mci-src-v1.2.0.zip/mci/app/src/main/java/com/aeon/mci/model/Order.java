package com.aeon.mci.model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import com.aeon.mci.provider.OrderContract;

public class Order implements Parcelable {
    public String id;
    public String agreementNo;
    public String customerId;
    public String guid;
    public String description;
    public String surveyCode;
    public String surveyName;
    public int collectDate;
    public int collectAmount;
    public String jobStatus;
    public String operatorName;
    public String autoCallRemark;
    public int delinquentStatus;
    public int outstandingBalance;
    public int penalty;
    public int currentBill;
    public int d1;
    public int d1AddPenalty;
    public int d2;
    public int d2AddPenalty;
    public int d3;
    public int d3AddPenalty;
    public int d4;
    public int d4AddPenalty;
    public int d5;
    public int d5AddPenalty;
    public int totalDelinquent;
    public int totalAddPenalty;
    public int minimumBill;
    public int fullBill;
    public String resultCode;
    public String resultName;
    public int resultCollectedDate;
    public int resultCollectedAmount;
    public int resultPromisedDate;
    public String resultRemark;
    public String taskType;
    public String priority;
    public int updatedFlag;
    public int resultSendToAutoCallFlag;
    public String agreementNoFullPan;
    public String token;
    public String clientNameEn;
    public String clientNameTh;
    public String clientContactNo;

    public Order() {

    }

    protected Order(Parcel in) {
        String[] data = new String[44];

        in.readStringArray(data);
        this.id = data[0];
        this.agreementNo = data[1];
        this.customerId = data[2];
        this.guid = data[3];
        this.description = data[4];
        this.surveyName = data[5];
        this.collectDate = Integer.parseInt(data[6]);
        this.collectAmount = Integer.parseInt(data[7]);
        this.operatorName = data[8];
        this.autoCallRemark = data[9];
        this.delinquentStatus = Integer.parseInt(data[10]);
        this.outstandingBalance = Integer.parseInt(data[11]);
        this.penalty = Integer.parseInt(data[12]);
        this.currentBill = Integer.parseInt(data[13]);
        this.d1 = Integer.parseInt(data[14]);
        this.d1AddPenalty = Integer.parseInt(data[15]);
        this.d2 = Integer.parseInt(data[16]);
        this.d2AddPenalty = Integer.parseInt(data[17]);
        this.d3 = Integer.parseInt(data[18]);
        this.d3AddPenalty = Integer.parseInt(data[19]);
        this.d4 = Integer.parseInt(data[20]);
        this.d4AddPenalty = Integer.parseInt(data[21]);
        this.d5 = Integer.parseInt(data[22]);
        this.d5AddPenalty = Integer.parseInt(data[23]);
        this.totalDelinquent = Integer.parseInt(data[24]);
        this.totalAddPenalty = Integer.parseInt(data[25]);
        this.minimumBill = Integer.parseInt(data[26]);
        this.fullBill = Integer.parseInt(data[27]);
        this.resultCode = data[28];
        this.resultName = data[29];
        this.resultCollectedDate = Integer.parseInt(data[30]);
        this.resultCollectedAmount = Integer.parseInt(data[31]);
        this.resultPromisedDate = Integer.parseInt(data[32]);
        this.resultRemark = data[33];
        this.taskType = data[34];
        this.priority = data[35];
        this.updatedFlag = Integer.parseInt(data[36]);
        this.resultSendToAutoCallFlag = Integer.parseInt(data[37]);
        this.surveyCode = data[38];
        this.token = data[39];
        this.clientNameEn = data[40];
        this.clientNameTh = data[41];
        this.clientContactNo = data[42];
        this.jobStatus = data[43];
    }

    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel in) {
            return new Order(in);
        }

        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringArray(new String[] {
                this.id,
                this.agreementNo,
                this.customerId,
                this.guid,
                this.description,
                this.surveyName,
                String.valueOf(this.collectDate),
                String.valueOf(this.collectAmount),
                this.operatorName,
                this.autoCallRemark,
                String.valueOf(this.delinquentStatus),
                String.valueOf(this.outstandingBalance),
                String.valueOf(this.penalty),
                String.valueOf(this.currentBill),
                String.valueOf(this.d1),
                String.valueOf(this.d1AddPenalty),
                String.valueOf(this.d2),
                String.valueOf(this.d2AddPenalty),
                String.valueOf(this.d3),
                String.valueOf(this.d3AddPenalty),
                String.valueOf(this.d4),
                String.valueOf(this.d4AddPenalty),
                String.valueOf(this.d5),
                String.valueOf(this.d5AddPenalty),
                String.valueOf(this.totalDelinquent),
                String.valueOf(this.totalAddPenalty),
                String.valueOf(this.minimumBill),
                String.valueOf(this.fullBill),
                this.resultCode,
                this.resultName,
                String.valueOf(this.resultCollectedDate),
                String.valueOf(this.resultCollectedAmount),
                String.valueOf(this.resultPromisedDate),
                this.resultRemark,
                this.taskType,
                this.priority,
                String.valueOf(this.updatedFlag),
                String.valueOf(this.resultSendToAutoCallFlag),
                this.surveyCode,
                this.token,
                this.clientNameEn,
                this.clientNameTh,
                this.clientContactNo,
                this.jobStatus
        });
    }

    public static Order fromCursorRow(Cursor cursor) {
        Order order = new Order();
        order.id = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_NO));
        order.agreementNo = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_AGREEMENT_NO));
        order.customerId = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.CUSTOMER_IDCARD_NO));
        order.guid = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_GUID));
        order.description = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_DESCRIPTION));
        order.surveyName = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_SURVEY_NAME));
        order.collectDate = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_COLLECT_DATE));
        order.collectAmount = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_COLLECT_AMOUNT));
        order.jobStatus = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_STATUS));
        order.operatorName = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_OPERATOR_NAME));
        order.autoCallRemark = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_AUTOCALL_REMARK));
        order.delinquentStatus = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_DELINQUENT_STATUS));
        order.outstandingBalance = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_OUTSTANDING_BALANCE));
        order.penalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_PENALTY));
        order.currentBill = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_CURRENT_BILL));
        order.d1 = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D1));
        order.d1AddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D1_ADD_PENALTY));
        order.d2 = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D2));
        order.d2AddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D2_ADD_PENALTY));
        order.d3 = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D3));
        order.d3AddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D3_ADD_PENALTY));
        order.d4 = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D4));
        order.d4AddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D4_ADD_PENALTY));
        order.d5 = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D5));
        order.d5AddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_D5_ADD_PENALTY));
        order.totalDelinquent = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_TOTAL_DELINQUENT));
        order.totalAddPenalty = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_TOTAL_ADD_PENALTY));
        order.minimumBill = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_MINIMUM_BILL));
        order.fullBill = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_FULL_BILL));
        order.resultCode = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.COLLECTOR_RESULT_CODE));
        order.resultName = cursor.getString(cursor.getColumnIndex(OrderContract.CollectorResults.COLLECTOR_RESULT_NAME));
        order.resultCollectedDate = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_RESULT_COLLECTED_DATE));
        order.resultCollectedAmount = cursor.getInt(cursor.getColumnIndex(OrderContract.Orders.ORDER_RESULT_COLLECTED_AMOUNT));
        order.taskType = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_TASK_TYPE));
        order.priority = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_PRIORITY));
        order.surveyCode = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_SURVEY_CODE));
        order.token = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_TOKEN));
        order.clientNameEn = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_CLIENT_NAME_EN));
        order.clientNameTh = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_CLIENT_NAME_TH));
        order.clientContactNo = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_CLIENT_CONTACT_NO));
        order.jobStatus = cursor.getString(cursor.getColumnIndex(OrderContract.Orders.ORDER_STATUS));
        return order;
    }
}
