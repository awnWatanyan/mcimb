package com.aeon.mci.network.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class User(
    @SerialName("employee_name")
    val name: String,
    @SerialName("employee_lastname")
    val lastname: String,
    @SerialName("employee_code")
    val code: String,
    @SerialName("device_name")
    val deviceName: String,
)
