package com.aeon.mci.model

data class Receipt(
        val receiptNo: String,
        val reprintCount: Int = 0,
        val orderId: String,
        val guid: String,
        val agreementNo: String,
        val customerId: String,
        val customerName: String,
        val employeeId: String,
        val employeeName: String,
        val clientNameTh: String = "",
        val clientNameEn: String = "",
        val contactNo: String = "",
        val amount: Double,
        val updatedDate: Int
)