package com.aeon.mci.service.tracking

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.provider.BaseColumns
import androidx.core.app.JobIntentService
import com.aeon.mci.BuildConfig
import com.aeon.mci.provider.OrderContract
import com.aeon.mci.syncadapter.DefaultBackendVolley
import com.aeon.mci.util.AccountUtils
import com.aeon.mci.util.datetimeFormat
import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.HttpHeaderParser
import com.android.volley.toolbox.JsonObjectRequest
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.util.*

@AndroidEntryPoint
class TrackingUpdater : JobIntentService() {

    companion object {
        private const val JOB_ID = 1112
        private const val NETWORK_PROVIDER_DECIMAL_PLACES = 10
        private const val TRACKING_WEBSERVICE_URL = "https://${BuildConfig.SERVER_HOST_NAME}/mci-core/v1/track"

        fun enqueueWork(context: Context, work: Intent) {
            enqueueWork(context, TrackingUpdater::class.java, JOB_ID, work)
        }
    }

    override fun onHandleWork(intent: Intent) {
        val cursor = contentResolver.query(
            OrderContract.Locations.CONTENT_URI,
            OrderContract.Locations.DEFAULT_PROJECTION,
            OrderContract.Locations.LOCATION_UPDATE_SELECTION,
            arrayOf("1"),
            OrderContract.Locations.LOCATION_TIME_SORT
        )
        if (cursor != null) {
            while (cursor.moveToNext()) {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(BaseColumns._ID))
                val workOrderNo = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Locations.ORDER_NO)) ?: "0"
                val speedInMetersPerSec = cursor.getFloat(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_SPEED))
                val speedInKmPerHr = speedInMetersPerSec * 3.6f
                val status: Int = if (workOrderNo.isEmpty()) {
                    if (speedInKmPerHr > 0) 22 else 20
                } else {
                    21
                }
                val provider = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_PROVIDER))
                var latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_LATITUDE))
                var longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_LONGITUDE))
                if (provider == LocationManager.NETWORK_PROVIDER) {
                    latitude += 0.000000009901
                    longitude += 0.000000009901
                    latitude = BigDecimal(latitude)
                        .setScale(NETWORK_PROVIDER_DECIMAL_PLACES, RoundingMode.DOWN)
                        .toDouble()
                    longitude = BigDecimal(longitude)
                        .setScale(NETWORK_PROVIDER_DECIMAL_PLACES, RoundingMode.DOWN)
                        .toDouble()
                }
                val signal: Int = when (provider) {
                    LocationManager.GPS_PROVIDER -> 0
                    LocationManager.NETWORK_PROVIDER -> 1
                    else -> 2
                }
                val employeeCode = cursor.getString(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_EMPLOYEE_CODE)) ?: ""
                val time = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_TIME))
                val batteryPct = cursor.getInt(cursor.getColumnIndexOrThrow(OrderContract.Locations.LOCATION_BATTERY))
                val now = datetimeFormat().format(Date(time* 1000L))
                val deviceId = AccountUtils.getDeviceImei(applicationContext)

                val primaryKey = JSONObject().apply {
                    put("imei", deviceId)
                    put("createdDate", now)
                    put("workOrderId", workOrderNo)
                }
                val params = JSONObject().apply {
                    put("id", primaryKey)
                    put("status", status)
                    put("imei2", deviceId)
                    put("latitude", latitude)
                    put("longitude", longitude)
                    put("createdTime", now)
                    put("speed", speedInKmPerHr)
                    put("value", signal)
                    put("collectorId", employeeCode)
                    put("battery", batteryPct)
                }
                requestToWebService(id.toString(), params)
            }
            cursor.close()
        }
    }

    private fun requestToWebService(id: String, params: JSONObject) {
        val method = Request.Method.POST
        val request: JsonObjectRequest = object : JsonObjectRequest(method, TRACKING_WEBSERVICE_URL, params,
            { updateFlagToDatabase(id) },
            {}
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                return HashMap<String, String>().apply {
                    "Content-Type" to "application/json"
                }
            }

            override fun parseNetworkResponse(response: NetworkResponse?): Response<JSONObject> {
                if (response != null) {
                    if (response.statusCode == HttpURLConnection.HTTP_CREATED) {
                        if (response.data.isEmpty()) {
                            return Response.success(null, HttpHeaderParser.parseCacheHeaders(response))
                        }
                    }
                }
                return super.parseNetworkResponse(response)
            }
        }
        DefaultBackendVolley.getInstance(applicationContext).addToRequestQueue(request)
    }

    private fun updateFlagToDatabase(id: String) {
        val now = (System.currentTimeMillis() / 1000L).toInt()
        val value = ContentValues().apply {
            put(OrderContract.SyncColumns.UPDATED_FLAG, 0)
            put(OrderContract.SyncColumns.UPDATED_DATE, now)
        }
        contentResolver.update(
            OrderContract.Locations.CONTENT_URI,
            value,
            OrderContract.Locations.LOCATION_UPDATED_SELECTION,
            arrayOf(id)
        )
    }
}