package com.aeon.mci.ui.theme

import androidx.compose.ui.graphics.Color
import kotlin.math.abs

val background = hslToComposeColor(0f, 0f, 1f)
val foreground = hslToComposeColor(240f, 0.1f, 0.039f)
val card = hslToComposeColor(0f, 0f, 1f)
val cardForeground = hslToComposeColor(240f, 0.1f, 0.039f)
val popover = hslToComposeColor(0f, 0f, 1f)
val popoverForeground = hslToComposeColor(240f, 0.1f, 0.039f)
val primary = hslToComposeColor(240f, 0.059f, 0.1f)
val primaryForeground = hslToComposeColor(0f, 0f, 0.98f)
val secondary = hslToComposeColor(240f, 0.048f, 0.959f)
val secondaryForeground = hslToComposeColor(240f, 0.059f, 0.1f)
val muted = hslToComposeColor(240f, 0.048f, 0.959f)
val mutedForeground = hslToComposeColor(240f, 0.038f, 0.461f)
val accent = hslToComposeColor(240f, 0.048f, 0.959f)
val accentForeground = hslToComposeColor(240f, 0.059f, 0.1f)
val destructive = hslToComposeColor(0f, 0.842f, 0.602f)
val destructiveForeground = hslToComposeColor(0f, 0f, 0.98f)
val border = hslToComposeColor(240f, 0.059f, 0.9f)
val input = hslToComposeColor(240f, 0.059f, 0.9f)
val ring = hslToComposeColor(240f, 0.059f, 0.1f)
// ... define other light colors

val DarkBackground = Color(0xFF042032)
val DarkForeground = Color(0xFFFAFAFA)
val DarkCard = Color(0xFF042032)
val DarkCardForeground = Color(0xFFFAFAFA)
val DarkPrimary = Color(0xFFFAFAFA)
val DarkPrimaryForeground = Color(0xFF1A1A33)
// ... define other dark colors

// Define additional colors as needed

fun hslToComposeColor(hue: Float, saturation: Float, lightness: Float): Color {
    // Convert HSL to RGB following the algorithm from https://en.wikipedia.org/wiki/HSL_and_HSV#HSL_to_RGB
    // Assumes h, s, and l are contained in the set [0, 1] and
    // returns r, g, and b in the set [0, 1].

    val c = ((1 - abs(2 * lightness - 1)) * saturation).toDouble()
    val x = c * (1 - abs((hue / 60.0 % 2) - 1))
    val m = lightness - c / 2.0

    var rPrim = 0.0
    var gPrim = 0.0
    var bPrim = 0.0

    when {
        hue < 60 -> {
            rPrim = c
            gPrim = x
            bPrim = 0.0
        }
        hue < 120 -> {
            rPrim = x
            gPrim = c
            bPrim = 0.0
        }
        hue < 180 -> {
            rPrim = 0.0
            gPrim = c
            bPrim = x
        }
        hue < 240 -> {
            rPrim = 0.0
            gPrim = x
            bPrim = c
        }
        hue < 300 -> {
            rPrim = x
            gPrim = 0.0
            bPrim = c
        }
        hue < 360 -> {
            rPrim = c
            gPrim = 0.0
            bPrim = x
        }
    }

    val r = ((rPrim + m) * 255).toInt()
    val g = ((gPrim + m) * 255).toInt()
    val b = ((bPrim + m) * 255).toInt()

    return Color(r, g, b)
}