package com.aeon.mci.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat.startActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

open class CommonIntentUtils @Inject constructor(
    @ApplicationContext val context: Context
) {

    fun openNavigationInGoogleMaps(address: String) {
        val gmmIntentUri = Uri.parse("google.navigation:q=${Uri.encode(address)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        mapIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        mapIntent.resolveActivity(context.packageManager).let {
            context.startActivity(mapIntent)
        }
    }

    fun openNavigationInGoogleMaps(address: String, latitude: String, longitude: String) {
        val locationString = "http://maps.google.com/maps?daddr=$latitude,$longitude (${address})"
        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse(locationString))
        mapIntent.setPackage("com.google.android.apps.maps")
        mapIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        mapIntent.resolveActivity(context.packageManager).let {
            context.startActivity(mapIntent)
        }

        //val gmmIntentUri = Uri.parse("google.navigation:addr=${latitude},${longitude} (${address})")
        //val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        //mapIntent.setPackage("com.google.android.apps.maps")
        //mapIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        //mapIntent.resolveActivity(context.packageManager).let {
        //    context.startActivity(mapIntent)
        //}
    }

    fun openDialer(telephoneNo: String) {
        val dialerIntent = Intent(Intent.ACTION_DIAL).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            data = Uri.parse("tel:$telephoneNo")
        }
        context.startActivity(dialerIntent)
    }

    fun startAmiVoiceRecorder() {
        val avrComponentName = ComponentName(
            "com.amivoicethai.amivoicerecorder",
            "com.amivoicethai.amivoicerecorder.BackgroundService.MyBackgroundService"
        )
        val avrIntentExtraNamePrefix = "com.amivoicethai.amivoicerecorder.intent"
        val avrIntent = Intent().apply {
            component = avrComponentName
            action = "amivoicerecorder.RecorderService"
            putExtra("${avrIntentExtraNamePrefix}.IMEI", "")
            putExtra("${avrIntentExtraNamePrefix}.Mobile_Number", "")
            putExtra("${avrIntentExtraNamePrefix}.Emp_Code", "")
            putExtra("${avrIntentExtraNamePrefix}.Emp_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.Customer_ID", "")
            putExtra("${avrIntentExtraNamePrefix}.Customer_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.Agreement_No", "")
            putExtra("${avrIntentExtraNamePrefix}.Collected_Date", "")
            putExtra("${avrIntentExtraNamePrefix}.Collected_Time", "")
            putExtra("${avrIntentExtraNamePrefix}.Collector_Result_Code", "")
            putExtra("${avrIntentExtraNamePrefix}.Collector_Result_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.recording", 1)
        }
        context.startService(avrIntent)
    }

    fun stopAmiVoiceRecorder() {
        val avrComponentName = ComponentName(
            "com.amivoicethai.amivoicerecorder",
            "com.amivoicethai.amivoicerecorder.BackgroundService.MyBackgroundService"
        )
        val avrIntentExtraNamePrefix = "com.amivoicethai.amivoicerecorder.intent"
        val avrIntent = Intent().apply {
            component = avrComponentName
            action = "amivoicerecorder.RecorderService"
            putExtra("${avrIntentExtraNamePrefix}.IMEI", "")
            putExtra("${avrIntentExtraNamePrefix}.Mobile_Number", "")
            putExtra("${avrIntentExtraNamePrefix}.Emp_Code", "")
            putExtra("${avrIntentExtraNamePrefix}.Emp_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.Customer_ID", "")
            putExtra("${avrIntentExtraNamePrefix}.Customer_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.Agreement_No", "")
            putExtra("${avrIntentExtraNamePrefix}.Collected_Date", "")
            putExtra("${avrIntentExtraNamePrefix}.Collected_Time", "")
            putExtra("${avrIntentExtraNamePrefix}.Collector_Result_Code", "")
            putExtra("${avrIntentExtraNamePrefix}.Collector_Result_Name", "")
            putExtra("${avrIntentExtraNamePrefix}.recording", 9)
        }
        context.startService(avrIntent)
    }
}