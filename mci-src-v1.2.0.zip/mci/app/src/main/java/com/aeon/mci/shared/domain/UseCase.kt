package com.aeon.mci.shared.domain

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aeon.mci.shared.domain.internal.DefaultScheduler
import com.aeon.mci.shared.domain.internal.Scheduler
import com.aeon.mci.shared.result.Result
import timber.log.Timber

abstract class UseCase<in P, R> {

    protected var taskScheduler: Scheduler = DefaultScheduler

    operator fun invoke(parameters: P, result: MutableLiveData<Result<R>>) {
        try {
            taskScheduler.execute {
                try {
                    execute(parameters).let { useCaseResult ->
                        result.postValue(Result.Success(useCaseResult))
                    }
                } catch (e: Exception) {
                    Timber.e(e)
                    result.postValue(Result.Error(e))
                }
            }
        } catch (e: Exception) {
            Timber.d(e)
            result.postValue(Result.Error(e))
        }
    }

    operator fun invoke(parameters: P): LiveData<Result<R>> {
        val liveCallback: MutableLiveData<Result<R>> = MutableLiveData()
        this(parameters, liveCallback)
        return liveCallback
    }

    fun executeNow(parameters: P): Result<R> {
        return try {
            Result.Success(execute(parameters))
        } catch (e: Exception) {
            Result.Error(e)
        }
    }

    @Throws(RuntimeException::class)
    protected abstract fun execute(parameters: P): R
}

operator fun <R> UseCase<Unit, R>.invoke(): LiveData<Result<R>> = this(Unit)
operator fun <R> UseCase<Unit, R>.invoke(result: MutableLiveData<Result<R>>) = this(Unit, result)