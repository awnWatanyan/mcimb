package com.aeon.mci.ui.customer

interface CustomerActionModeListener {
    fun onCreateActionMode()
    fun onDestroyActionMode(isRollback: Boolean)
    fun saveReorderCustomerList()
}