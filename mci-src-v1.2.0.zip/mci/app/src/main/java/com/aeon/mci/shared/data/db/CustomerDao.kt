package com.aeon.mci.shared.data.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import androidx.room.RewriteQueriesToDropUnusedColumns

@Dao
interface CustomerDao {

    @RewriteQueriesToDropUnusedColumns
    @Query("""
        SELECT t2.*, 
        COUNT(t1.order_agreement_no) AS totalAgreements,
        SUM(CASE WHEN t1.order_status IN (97, 98, 99) THEN 1 ELSE 0 END) AS totalCanceledAgreements,
        SUM(CASE WHEN t1.order_priority = 'U' THEN 1 ELSE 0 END) AS totalUrgentAgreements,
        IFNULL(SUM(t1.order_collect_amount), 0) as totalCollectAmount,
        IFNULL(SUM(t1.order_result_collected_amount), 0) as totalCollectedAmount,
        t1.order_client_name_en AS clientNameEn,
        t1.order_client_name_th AS clientNameTh,
        t1.order_client_contact_no AS clientContactNo,
        t1.order_result_collected_date AS collectedDate,
        t1.order_autocall_remark AS autoCallRemark
        FROM (SELECT * FROM orders
        GROUP BY order_agreement_no
        ORDER BY CAST(order_no AS INTEGER) DESC) AS t1
        LEFT JOIN customers AS t2 ON t2.customer_idcard_no = t1.customer_idcard_no
        LEFT JOIN customers_indices AS t3 ON t3.customers_indices_customer_id = t2.customer_idcard_no
        WHERE 1=1
        AND t1.order_status = '5'
        AND t1.collector_result_code IS NULL
        AND t1.order_collect_date > (strftime('%s', 'now') - 2678400)
        GROUP BY t2.customer_idcard_no
        ORDER BY CASE WHEN t3.customers_indices_no IS NULL THEN 
        CASE WHEN t1.order_priority IS 'U' THEN 0 ELSE 2 END 
        ELSE 1 END, 
        t3.customers_indices_no ASC,
        CASE t1.order_priority WHEN 'U' THEN 0 WHEN 'N' THEN 1 END,
        t2.updated_date DESC
    """)
    fun getAssignTask(): LiveData<List<CustomerEntity>>

    @RewriteQueriesToDropUnusedColumns
    @Query("""
        SELECT t2.*, 
        COUNT(t1.order_agreement_no) AS totalAgreements,
        SUM(CASE WHEN t1.order_status IN (97, 98, 99) THEN 1 ELSE 0 END) AS totalCanceledAgreements,
        SUM(CASE WHEN t1.order_priority = 'U' THEN 1 ELSE 0 END) AS totalUrgentAgreements,
        IFNULL(SUM(t1.order_collect_amount), 0) as totalCollectAmount,
        IFNULL(SUM(t1.order_result_collected_amount), 0) as totalCollectedAmount,
        t1.order_client_name_en AS clientNameEn,
        t1.order_client_name_th AS clientNameTh,
        t1.order_client_contact_no AS clientContactNo,
        t1.order_result_collected_date AS collectedDate,
        t1.order_autocall_remark AS autoCallRemark
        FROM (SELECT * FROM orders
        GROUP BY order_agreement_no
        ORDER BY CAST(order_no AS INTEGER) DESC) AS t1
        LEFT JOIN customers AS t2 ON t2.customer_idcard_no = t1.customer_idcard_no
        LEFT JOIN customers_indices AS t3 ON t3.customers_indices_customer_id = t2.customer_idcard_no
        WHERE 1=1
        AND t1.order_result_collected_date >= :startTime
        AND t1.order_result_collected_date <= :endTime
        AND (t1.order_status IN (89, 97, 98, 99) AND t1.collector_result_code IS NULL)
        AND (t1.order_status = '5' AND t1.collector_result_code IS NOT NULL)
        GROUP BY t2.customer_idcard_no
        ORDER BY t1.order_result_collected_date DESC
    """)
    fun getCompleteTask(startTime: Int, endTime: Int): LiveData<List<CustomerEntity>>
}