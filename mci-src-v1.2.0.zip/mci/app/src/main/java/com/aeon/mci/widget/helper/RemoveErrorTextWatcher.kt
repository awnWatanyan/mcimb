package com.aeon.mci.widget.helper

import com.google.android.material.textfield.TextInputLayout
import android.text.Editable
import android.text.TextWatcher
import com.aeon.mci.util.resetError

class RemoveErrorTextWatcher(private val textInputLayout: TextInputLayout) : TextWatcher {

    private var afterTextChanged = false

    override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) = Unit

    override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) = Unit

    override fun afterTextChanged(editable: Editable) {
        afterTextChanged = if (afterTextChanged) {
            false
        } else {
            textInputLayout.run {
                if (isErrorEnabled) {
                    resetError()
                }
            }
            true
        }
    }

}