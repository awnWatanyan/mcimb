package com.aeon.mci.ui.customerinfo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.text.method.ScrollingMovementMethod
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.aeon.mci.Config
import com.aeon.mci.databinding.FragmentCustomerInfoBinding
import com.aeon.mci.persistence.Customer
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CustomerInfoFragment : Fragment() {

    private var isEdit: Boolean = false
    private var hideMobileNo = true
    private var hidePhoneNo = true

    private lateinit var customer: Customer
    private lateinit var binding: FragmentCustomerInfoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true

        requireNotNull(arguments).apply {
            customer = getParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER)!!
            isEdit = getBoolean(Config.EXTRAS_INCOMPLETE_TASK).not()
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCustomerInfoBinding.inflate(inflater, container, false)
        binding.customerAddress.movementMethod = ScrollingMovementMethod.getInstance()
        binding.customerAddress.setOnLongClickListener { copyAddressToClipboard() }
        binding.customerMobile.setOnClickListener { hideMobileNo(true) }
        binding.customerMobile.setOnLongClickListener { toggleMobileNoVisible() }
        binding.customerPhone.setOnClickListener { hidePhoneNo(true) }
        binding.customerPhone.setOnLongClickListener { togglePhoneNoVisible() }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        binding.customer = customer
        binding.isEdit = isEdit
    }

    private fun toggleMobileNoVisible(): Boolean {
        hideMobileNo(!hideMobileNo)
        return true
    }

    private fun togglePhoneNoVisible(): Boolean {
        hidePhoneNo(!hidePhoneNo)
        return true
    }

    private fun hideMobileNo(hidden: Boolean) {
        hideMobileNo = hidden
        if (hidden) {
            customerPhone(binding.customerMobile, customer.mobile)
        } else {
            binding.customerMobile.text = customer.mobile
        }
    }

    private fun hidePhoneNo(hidden: Boolean) {
        hidePhoneNo = hidden
        if (hidden) {
            customerPhone(binding.customerPhone, customer.phone)
        } else {
            binding.customerPhone.text = customer.phone
        }
    }

    private fun copyAddressToClipboard(): Boolean {
        val clipData = ClipData.newPlainText("address", customer.address)
        val cm: ClipboardManager = getClipboardManager()
        cm.setPrimaryClip(clipData)
        Toast.makeText(requireContext(), "Address copied", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun getClipboardManager(): ClipboardManager {
        return requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }

    companion object {
        @JvmStatic
        fun newInstance(customer: Customer, incomplete: Boolean): CustomerInfoFragment {
            val arguments = Bundle().apply {
                putBoolean(Config.EXTRAS_INCOMPLETE_TASK, incomplete)
                putParcelable(Config.BUNDLE_ARG_MODEL_CUSTOMER, customer)
            }
            return CustomerInfoFragment().apply { this.arguments = arguments }
        }
    }
}