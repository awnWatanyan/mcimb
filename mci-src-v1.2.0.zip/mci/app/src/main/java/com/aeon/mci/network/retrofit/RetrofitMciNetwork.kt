package com.aeon.mci.network.retrofit

import com.aeon.mci.network.MciNetworkDataSource
import com.aeon.mci.network.model.LoginRequest
import com.aeon.mci.network.model.NetworkCustomer
import com.aeon.mci.network.model.User
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Call
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Retrofit API declaration for MCI Network API
 */
private interface RetrofitMciNetworkApi {

    @POST("login")
    suspend fun login(@Body body: LoginRequest): List<User>

    @GET("tasks")
    suspend fun getTasks(
        @Query("employeeCode") employeeCode: String,
        @Query("deviceImei") deviceImei: String,
    ): NetworkResponse<List<NetworkCustomer>>
}

private const val FLS_MOBILE_BASE_URL = "https://fls-mobile.aeonts.com"

/**
 * Wrapper for data provided from the [FLS_MOBILE_BASE_URL]
 */
@Serializable
private data class NetworkResponse<T>(
    val success: Boolean,
    val data: T,
    val count: Int,
)

/**
 * [Retrofit] backed [MciNetworkDataSource]
 */
@Singleton
class RetrofitNiaNetwork @Inject constructor(
    networkJson: Json,
    okhttpCallFactory: Call.Factory,
): MciNetworkDataSource {

    private val networkApi = Retrofit.Builder()
        .baseUrl(FLS_MOBILE_BASE_URL)
        .callFactory(okhttpCallFactory)
        .build()
        .create(RetrofitMciNetworkApi::class.java)

    override suspend fun login(username: String, password: String, deviceImei: String): List<User> {
        val requestBody = LoginRequest(username, password, deviceImei)
        return networkApi.login(requestBody)
    }

    override suspend fun getTasks(employeeCode: String, deviceImei: String): List<NetworkCustomer> =
        networkApi.getTasks(employeeCode, deviceImei).data
}