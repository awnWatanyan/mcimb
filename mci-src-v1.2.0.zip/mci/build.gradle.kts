// Top-level build file where you can add configuration options common to all sub-projects/modules.
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

buildscript {
    repositories {
        google()
        mavenCentral()

        flatDir {
            dirs("libs")
            dirs("../third_party/zebra/libs/")
        }
    }
    dependencies {
        classpath(libs.android.gradlePlugin)
        classpath(libs.kotlin.gradlePlugin)
        classpath(libs.androidx.benchmark.gradlePlugin)
        classpath(libs.androidx.navigation.safe.args.gradlePlugin)
        classpath(libs.hilt.gradlePlugin)
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.ksp) apply false
}

//allprojects {
//    repositories {
//        google()
//        mavenCentral()
//
//        flatDir {
//            dirs("libs")
//            dirs("../third_party/zebra/libs/")
//        }
//    }
//}

//subprojects {
//    tasks.withType<KotlinCompile>().configureEach {
//        kotlinOptions.freeCompilerArgs += "-Xopt-in=kotlin.RequiresOptIn"
//    }
//}

//tasks.register("clean", Delete::class) {
//    delete(rootProject.buildDir)
//}